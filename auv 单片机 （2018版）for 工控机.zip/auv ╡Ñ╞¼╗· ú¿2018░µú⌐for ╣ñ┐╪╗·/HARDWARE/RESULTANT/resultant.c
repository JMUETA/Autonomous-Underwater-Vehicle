#include "resultant.h"
#include "math.h"




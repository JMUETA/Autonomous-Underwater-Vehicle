#ifndef __PID_H
#define __PID_H 			   
#include "sys.h" 


void PID_init(void);
float PID_realize(float speed,float actualspeed);



#endif


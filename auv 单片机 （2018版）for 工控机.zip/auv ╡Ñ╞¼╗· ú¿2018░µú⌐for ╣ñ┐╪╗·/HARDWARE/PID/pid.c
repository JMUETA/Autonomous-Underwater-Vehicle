#include "stm32f4xx.h"
#include "sys.h"
#include "pid.h"

extern float pidKi;
extern float pidKp;

struct _pid{
    float SetSpeed;
    float ActualSpeed; 
    float err;
    float err_last;
		float err_last2;
    float Kp,Ki,Kd;
    float voltage;
    float integral;           
}pid;

void PID_init(void){
    pid.SetSpeed=0.0;
    pid.ActualSpeed=0.0;
    pid.err=0.0;
    pid.err_last=0.0;
		pid.err_last2=0;
    pid.voltage=0.0;
    pid.integral=0.0;
    pid.Kp=7;
    pid.Ki=0.00;
    pid.Kd=0;
}



float PID_realize(float speed,float actualspeed){
    pid.SetSpeed=speed;
		pid.ActualSpeed=actualspeed;
    pid.err=pid.SetSpeed-pid.ActualSpeed;
    pid.integral+=pid.err;
    pid.voltage=pidKp*pid.err+pidKi*pid.integral+pid.Kd*(pid.err-pid.err_last);//λ��ʽPID
		//pid.voltage=pid.Kp*(pid.err-pid.err_last)+pid.Ki*pid.err+pid.Kd*(pid.err-2*pid.err_last+pid.err_last2);// ����ʽPID
    pid.err_last=pid.err;
		pid.err_last2 = pid.err_last;
    pid.ActualSpeed=pid.voltage*1.0;
    return pid.ActualSpeed;
}




SEARCH_COUNT_FLAG = 0
def search2():
    global SEARCH_COUNT_FLAG
    SEARCH_COUNT_FLAG = SEARCH_COUNT_FLAG + 1
    if SEARCH_COUNT_FLAG == 1 and COUNT('count1'):
        return 'left'
    if SEARCH_COUNT_FLAG == 2 and COUNT('count1'):
        return 'left'
    if SEARCH_COUNT_FLAG == 3 and COUNT('count1'):
        return 'left'
    if SEARCH_COUNT_FLAG == 4 and COUNT('count1'):
        return 'left'
    if SEARCH_COUNT_FLAG == 5 and COUNT('count1'):
        return 'left'
    if SEARCH_COUNT_FLAG == 6 and COUNT('count1'):
        return 'right'
    if SEARCH_COUNT_FLAG == 7 and COUNT('count1'):
        return 'right'
    if SEARCH_COUNT_FLAG == 8 and COUNT('count1'):
        return 'right'
    if SEARCH_COUNT_FLAG == 9 and COUNT('count1'):
        return 'right'
    if SEARCH_COUNT_FLAG == 10 and COUNT('count1'):
        SEARCH_COUNT_FLAG = 0
        return 'right'

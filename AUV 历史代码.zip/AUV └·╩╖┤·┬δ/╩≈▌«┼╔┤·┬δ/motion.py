from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2
import logging
import sys
import numpy as np
import serial
import threading
from collections import deque
from scipy.spatial import distance as dist
from collections import OrderedDict


#串口通信接口
portx = '/dev/ttyUSB0'
bps = 115200
timex = 0.01
ser = serial.Serial(portx, bps, timeout=timex)


#AUV控制，通信协议（2019版）
def PID_controlAUV(od_r,output):
    global model,dl,dr
    global AUV_dx,AUV_dy,AUV_dtheta
    head = [0xaa, 0x55, 0x10]
    depth_lock_bit = [0x01]
    dir_lock_bit = [0x01]
    forword_back_bit = [0x00]
    left_right_bit = [0x00]
    up_down_bit = [0x00]
    rotation_bit = [0x00]
    power_value = [output]
    other_bit = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    start_stop_bit = [0x00]
    # \xaa\x55\x10\x02\x01\x00\x00\x01\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x01

    if od_r == 'go':
        dir_lock_bit = [0x02]
        forword_back_bit = [0x01]
        start_stop_bit = [0x01]
        model = 'diff'
        dl, dr, AUV_dx, AUV_dy, AUV_dtheta = 0.2, 0.2, 0, 0, 0
        print('go')
    if od_r == 'back':
        dir_lock_bit = [0x02]
        forword_back_bit = [0x02]
        start_stop_bit = [0x01]
        dl, dr, AUV_dx, AUV_dy, AUV_dtheta = -0.2, -0.2, 0, 0, 0
        print('back')

    if od_r == 'left_translation':  # 左平移
        dir_lock_bit = [0x02]
        left_right_bit = [0x02]
        start_stop_bit = [0x01]
        model = 'trans'
        dl, dr, AUV_dx, AUV_dy, AUV_dtheta = 0, 0, -0.2, 0, 0
        print('left_translation')
    if od_r == 'right_translation':  # 右平移
        dir_lock_bit = [0x02]
        left_right_bit = [0x01]
        start_stop_bit = [0x01]
        model = 'trans'
        dl, dr, AUV_dx, AUV_dy, AUV_dtheta = 0, 0, 0.2, 0, 0
        print('right_translation')
    if od_r == 'left':  # 左旋转
        dir_lock_bit = [0x02]
        rotation_bit = [0x02]
        start_stop_bit = [0x01]
        model = 'dtheta'
        dl, dr, AUV_dx, AUV_dy, AUV_dtheta = 0, 0, 0, 0, 0.5
        print('left')
    if od_r == 'right':  # 右旋转
        dir_lock_bit = [0x02]
        rotation_bit = [0x01]
        start_stop_bit = [0x01]
        model = 'dtheta'
        dl, dr, AUV_dx, AUV_dy, AUV_dtheta = 0, 0, 0, 0, -0.5
        print('right')
    if od_r == 'up':
        depth_lock_bit = [0x02]
        up_down_bit = [0x02]
        start_stop_bit = [0x01]
        dl, dr, AUV_dx, AUV_dy, AUV_dtheta = 0, 0, 0, 0, 0
        print('up')
    if od_r == 'down':
        depth_lock_bit = [0x02]
        up_down_bit = [0x01]
        start_stop_bit = [0x01]
        dl, dr, AUV_dx, AUV_dy, AUV_dtheta = 0, 0, 0, 0, 0
        print('down')
    if od_r == 'stop':
        start_stop_bit = [0x00]
        dl, dr, AUV_dx, AUV_dy, AUV_dtheta = 0, 0, 0, 0, 0
        print('stop')

    parameter = head + depth_lock_bit + dir_lock_bit + forword_back_bit + left_right_bit + up_down_bit + rotation_bit + power_value + other_bit + start_stop_bit
    check_sum = sum(parameter)
    check_sum = [check_sum & 255]

    msg = parameter + check_sum
    msg = bytearray(msg)
    try:
        ser.write(msg)
    except Exception as e:
        print("--异常--:", e)

    #return model, dl, dr, AUV_dx, AUV_dy, AUV_dtheta



time.sleep(3)
PID_controlAUV('go',20)
time.sleep(2)
PID_controlAUV('stop',0)
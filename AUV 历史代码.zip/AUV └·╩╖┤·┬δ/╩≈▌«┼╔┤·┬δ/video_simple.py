#!/usr/bin/env python

'''
VideoCapture sample showcasing  some features of the Video4Linux2 backend

Sample shows how VideoCapture class can be used to control parameters
of a webcam such as focus or framerate.
Also the sample provides an example how to access raw images delivered
by the hardware to get a grayscale image in a very efficient fashion.

Keys:
    ESC    - exit
    g      - toggle optimized grayscale conversion

'''

# Python 2/3 compatibility
from __future__ import print_function

import cv2
import threading

ball_flag = False

def to_ball():
    #### 修改部分
    global ball_flag
    print('yes!')
    ball_flag = True


if __name__ == '__main__':

    timer = threading.Timer(10, to_ball)  # 设置时钟。根据rush_ball_time变量以判断是否进入撞球部分
    timer.start()

    font = cv2.FONT_HERSHEY_SIMPLEX
    color = (0, 0, 255)

    cap = cv2.VideoCapture(0)

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    cv2.namedWindow("Video", cv2.WINDOW_AUTOSIZE)

    fps = int(cap.get(cv2.CAP_PROP_FPS))

    print(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    print(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    while True:
        status, img = cap.read()

        if ball_flag:
            cv2.putText(img, "ball_flag True", (15, 80), font, 1.0, color)
        else:
            cv2.putText(img, "ball_flag False", (15, 80), font, 1.0, color)
            
        cv2.imshow("Video", img)

        k = cv2.waitKey(1)

        if k == 27:
            break

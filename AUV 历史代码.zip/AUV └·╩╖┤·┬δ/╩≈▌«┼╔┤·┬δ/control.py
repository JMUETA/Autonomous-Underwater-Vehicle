
#串口通信接口
portx = '/dev/ttyUSB0'
bps = 115200
timex = 0.01
ser = serial.Serial(portx, bps, timeout=timex)



def PID_controlAUV(od_r,output):
    head = [0xaa, 0x55, 0x10]
    depth_lock_bit = [0x01]
    dir_lock_bit = [0x01]
    forword_back_bit = [0x00]
    left_right_bit = [0x00]
    up_down_bit = [0x00]
    rotation_bit = [0x00]
    power_value = [output]
    other_bit = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    start_stop_bit = [0x00]
    # \xaa\x55\x10\x02\x01\x00\x00\x01\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x01

    if od_r == 'go':
        dir_lock_bit = [0x02]
        forword_back_bit = [0x01]
        start_stop_bit = [0x01]
        print('go')
    if od_r == 'back':
        dir_lock_bit = [0x02]
        forword_back_bit = [0x02]
        start_stop_bit = [0x01]
        print('back')

    if od_r == 'left_translation':  # 左平移
        dir_lock_bit = [0x02]
        left_right_bit = [0x02]
        start_stop_bit = [0x01]
        print('left_translation')
    if od_r == 'right_translation':  # 右平移
        dir_lock_bit = [0x02]
        left_right_bit = [0x01]
        start_stop_bit = [0x01]
        print('right_translation')
    if od_r == 'left':  # 左旋转
        dir_lock_bit = [0x02]
        rotation_bit = [0x02]
        start_stop_bit = [0x01]
        print('left')
    if od_r == 'right':  # 右旋转
        dir_lock_bit = [0x02]
        rotation_bit = [0x01]
        start_stop_bit = [0x01]
        print('right')
    if od_r == 'up':
        depth_lock_bit = [0x02]
        up_down_bit = [0x02]
        start_stop_bit = [0x01]
        print('up')
    if od_r == 'down':
        depth_lock_bit = [0x02]
        up_down_bit = [0x01]
        start_stop_bit = [0x01]
        print('down')
    if od_r == 'stop':
        start_stop_bit = [0x00]
        print('stop')

    parameter = head + depth_lock_bit + dir_lock_bit + forword_back_bit + left_right_bit + up_down_bit + rotation_bit + power_value + other_bit + start_stop_bit
    check_sum = sum(parameter)
    check_sum = [check_sum & 255]

    msg = parameter + check_sum
    msg = bytearray(msg)
    try:
        ser.write(msg)
    except Exception as e:
        print("--异常--:", e)



if __name__ == "__main__":
    PID_controlAUV('go',10)
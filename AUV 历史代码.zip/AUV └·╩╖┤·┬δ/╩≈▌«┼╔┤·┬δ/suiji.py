def R_turn():
    global turn_count
    turn_count = turn_count + 1
    if turn_count == 1:
        PID_controlAUV('right', 30)
    if turn_count == 2:
        PID_controlAUV('ball_up', 34)
    if turn_count == 3:
        PID_controlAUV('left', 25)
    if turn_count == 4:
        PID_controlAUV('ball_up', 34)
        turn_count = 0
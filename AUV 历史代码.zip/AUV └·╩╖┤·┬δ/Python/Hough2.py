import cv2
import numpy as np
import math
import matplotlib.pyplot as plt

cap = cv2.VideoCapture('C:\\Users\\96317\\Desktop\\OPENCV\\print\\gopro1.mp4')
color = [([30, 30,120], [150, 130, 200])]  

KNOWN_DISTANCE = 30.0
KNOWN_WIDTH = 21.0

def classify_row(lines2):
    line_theta = []
    hor_line = []
    line_theta = lines2
    for j in range(len(lines2)):
        if line_theta[j][1] >0.79 or line_theta[j][1]<(-0.79):
            hor_line.append(line_theta[j])
    return hor_line            

def classify_column(lines2):
    line_theta = []
    ver_line = []
    line_theta = lines2
    for j in range(len(lines2)):
        if line_theta[j][1]  <0.79 and line_theta[j][1]>(-0.79):
            #ver_line[j] = line_theta[j]
            ver_line.append(line_theta[j])
    return ver_line


def bubbleSort_row(lines2):
    hor_line = classify_row(lines2)
    for i in range(len(hor_line)-1):
        for j in range(len(hor_line)-i-1):  
            if hor_line[j][0] > hor_line[j+1][0]:
                hor_line[j], hor_line[j+1] = hor_line[j+1], hor_line[j]
    return hor_line

def bubbleSort_column(lines2):
    ver_line = classify_column(lines2)
    for i in range(len(ver_line)-1):
        for j in range(len(ver_line)-i-1):  
            if ver_line[j][0] > ver_line[j+1][0]:
                ver_line[j], ver_line[j+1] = ver_line[j+1], ver_line[j]
    return ver_line

def distingish_row(lines2):
    line_hor = bubbleSort_row(lines2)
    section_line_hor = []
    if len(line_hor) == 0:
        return section_line_hor
    for i in range(len(line_hor)-1):
        if line_hor[i+1][0] - line_hor[i][0]>30:
            section_line_hor.append(line_hor[i])
    section_line_hor.append(line_hor[len(line_hor)-1])

    return section_line_hor

def distingish_column(lines2):
    line_ver = bubbleSort_column(lines2)
    section_line_ver = []
    if len(line_ver) == 0:
        return section_line_ver
    for i in range(len(line_ver)-1):
        if line_ver[i+1][0] - line_ver[i][0]>30:
            section_line_ver.append(line_ver[i])
    section_line_ver.append(line_ver[len(line_ver)-1])

    return section_line_ver

def Node():
    point = []
    lines_row = distingish_row(lines2)
    lines_column = distingish_column(lines2)
    if (len(lines_row)<1) or (len(lines_column)<1):
        return [1,1,2,2,3,3,4,4]
    rho1 = lines_row[0][0]
    theta1 = lines_row[0][1]
    rho3 = lines_column[0][0]
    theta3 = lines_column[0][1]
    k1 = -(math.tan(theta1))
    b1 = rho1*math.cos(theta1)-(math.tan(theta1)*math.sin(theta1))*rho1
    k3 = -(math.tan(theta3))
    b3 = rho3*math.cos(theta3)-(math.tan(theta3)*math.sin(theta3))*rho3
    #node_x13 = abs((b3-b1))/abs((k1-k3))
    #node_y13 = -(math.tan(theta1))*node_x13 + b1
    node_y13 = (rho3*math.cos(theta1)-rho1*math.cos(theta3))/(math.cos(theta1)*(math.sin(theta1)-math.tan(theta1)*math.cos(theta3)))
    node_x13 = (rho3*math.sin(theta1)-rho1*math.sin(theta3))/(math.sin(theta1)*(math.cos(theta3)-math.sin(theta3)/math.tan(theta1)))
    point.append(node_x13)
    point.append(node_y13)
    
    if (len(lines_row)>1):
        rho2 = lines_row[1][0]
        theta2 = lines_row[1][1]
        k2 = -(math.tan(theta2))
        b2 = rho2*math.cos(theta2)-(math.tan(theta2)*math.sin(theta2))*rho2
        #node_x23 = (b3-b2)/(k2-k3)
        #node_y23 = -(math.tan(theta2))*node_x23 + b2
        node_y23 = (rho3*math.cos(theta2)-rho2*math.cos(theta3))/(math.cos(theta2)*(0.1+math.sin(theta2)-math.tan(theta2)*math.cos(theta3)+0.1))
        node_x23 = (rho3*math.sin(theta2)-rho2*math.sin(theta3))/(math.sin(theta2)*(0.1+math.cos(theta3)-math.sin(theta3)/math.tan(theta2)+0.1))
        point.append(node_x23)
        point.append(node_y23)
        
    if (len(lines_column)>1):
        rho4 = lines_column[1][0]
        theta4 = lines_column[1][1]
        k4 = -(math.tan(theta4))
        b4 = rho4*math.cos(theta4)-(math.tan(theta4)*math.sin(theta4))*rho4
        #node_x14 = (b4-b1)/(k1-k4)
        #node_y14 = -(math.tan(theta4))*node_x14 + b4
        node_y14 = (rho4*math.cos(theta1)-rho1*math.cos(theta4))/(math.cos(theta1)*(math.sin(theta1)-math.tan(theta1)*math.cos(theta4)))
        node_x14 = (rho4*math.sin(theta1)-rho1*math.sin(theta4))/(math.sin(theta1)*(math.cos(theta4)-math.sin(theta4)/math.tan(theta1)))
        point.append(node_x14)
        point.append(node_y14)
    if (len(lines_row)>1) and (len(lines_column)>1):
        #node_x24 = (b4-b2)/(k2-k4)
        #node_y24 = -(math.tan(theta2))*node_x24 + b2
        node_y24 = (rho4*math.cos(theta2)-rho2*math.cos(theta4))/(math.cos(theta2)*(math.sin(theta2)-math.tan(theta2)*math.cos(theta4)))
        node_x24 = (rho4*math.sin(theta2)-rho1*math.sin(theta4))/(math.sin(theta2)*(math.cos(theta4)-math.sin(theta4)/math.tan(theta2)))
        point.append(node_x24)
        point.append(node_y24)
    return point

def distance_to_camera(knowWidth,forcalLength,perWidth):
    return (knowWidth*forcalLength)/perWidth



while(1):
    ret,frame = cap.read()
    for (lower,upper) in color:
        lower = np.array(lower,dtype = "uint8")
        upper = np.array(upper,dtype = "uint8")
        mask = cv2.inRange(frame,lower,upper)
        output = cv2.bitwise_and(frame,frame,mask=mask)
    gray = cv2.cvtColor(output, cv2.COLOR_BGR2GRAY)
    #gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray,50,150,apertureSize = 3)
    blurred = cv2.GaussianBlur(gray,(5,5),0)
    ret,thresh = cv2.threshold(blurred, 50, 255, cv2.THRESH_BINARY)
    edged = cv2.Canny(blurred,35,125)
    cnts = cv2.findContours(thresh.copy(),cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[1]
    c = max(cnts,key = cv2.contourArea)
    marker = cv2.minAreaRect(c)
    forcalLength = 600
    inches = distance_to_camera(KNOWN_WIDTH,forcalLength,marker[1][0])

    box = cv2.boxPoints(marker)
    box = np.int0(box)
    #cv2.drawContours(frame, [box], -1, (0, 255, 0), 2)
    cv2.putText(frame, "%.2fft" % (inches / 12),
	(frame.shape[1] - 200, frame.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX,
	2.0, (0, 255, 0), 3)
    
    tmp = 118
    lines = cv2.HoughLines(thresh,1,np.pi/180,tmp)
    while lines is None:
        tmp = tmp-1
    lines = cv2.HoughLines(thresh,1,np.pi/180,tmp)
    lines1 = lines[:,0,:]
    lines2 = lines1
    if len(lines1) < 25:
        for g in range(len(lines1)):
            if lines1[g][0]<0:
                lines2[g][0] = abs(lines1[g][0])
                lines2[g][1] = lines1[g][1]-3.14

        #y_ = distingish_row(lines1)
        #y_1 = y_[0][0]
        point_ = Node()
        lines3 = distingish_row(lines2)
        lines4 = distingish_column(lines2)
        for rho1,theta1 in lines3[:]:
            a1 = np.cos(theta1)
            b1 = np.sin(theta1)
            x01 = a1*rho1
            y01 = b1*rho1
            x__ = int(x01 + 1000*(-b1))
            y__ = int(y01 + 1000*(a1))
            x__1 = int(x01 - 1000*(-b1))
            y__1 = int(y01 - 1000*(a1))
        for rho2,theta2 in lines4[:]:
            a2 = np.cos(theta2)
            b2 = np.sin(theta2)
            x02 = a2*rho2
            y02 = b2*rho2
            x__2 = int(x02 + 1000*(-b2))
            y__2 = int(y02 + 1000*(a2))
            x__3 = int(x02 - 1000*(-b2))
            y__3 = int(y02 - 1000*(a2))
    


        
        x_ = int(point_[0])
        y_ = int(point_[1])
        if len(point_)>2:
            x_1 = int(point_[2])
            y_1 = int(point_[3])
        else:
            x_1 = 3
            y_1 = 3
        if len(point_)>4:
            x_2 = int(point_[4])
            y_2 = int(point_[5])
        else :
            x_2 = 1
            y_2 = 1
        if len(point_)>6:
            x_3 = int(point_[6])
            y_3 = int(point_[7])
        else:
            x_3 = 2
            y_3 = 2
        x_cen = int((x_+x_2)/2)
        y_cen = int((x_+x_1)/2)
        #print(point_)
        cv2.line(frame,(x__,y__),(x__1,y__1),(0,255,0),2)
        #cv2.line(frame,(x__2,y__2),(x__3,y__3),(0,255,0),2)
    #cv2.circle(frame,(x_,y_),7,(0, 0, 255), -1)
    #cv2.circle(frame,(x_1,y_1),7, (0, 0, 255), -1)
    #cv2.circle(frame,(x_2,y_2),7, (0, 0, 255), -1)
    #cv2.circle(frame,(x_3,y_3),7, (0, 0, 255), -1)
    #cv2.circle(frame,(x_cen,y_cen),7, (0, 0, 255), -1)
    cv2.imshow("capture",frame)
    if cv2.waitKey(33) & 0XFF==ord('q'):
        break
    cv2.waitKey(33)

cap.release()
cv2.destroyAllWindows()




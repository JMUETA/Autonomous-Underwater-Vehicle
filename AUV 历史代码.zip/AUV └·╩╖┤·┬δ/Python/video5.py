import cv2
import numpy as np
import math
import matplotlib.pyplot as plt

cap = cv2.VideoCapture("C:\\Users\\96317\\Desktop\\OPENCV\\print\\gopro1.mp4")
color = [([80, 68, 80], [150, 130, 140])]



rectW,rectH = 20,540



def classify_row(lines2):
    line_theta = []
    hor_line = []
    line_theta = lines2
    for j in range(len(lines2)):
        if line_theta[j][1] >0.79 or line_theta[j][1]<(-0.79):
            hor_line.append(line_theta[j])
    return hor_line  
    
def bubbleSort_row(lines2):
    hor_line = classify_row(lines2)
    for i in range(len(hor_line)-1):
        for j in range(len(hor_line)-i-1):  
            if hor_line[j][0] > hor_line[j+1][0]:
                hor_line[j], hor_line[j+1] = hor_line[j+1], hor_line[j]
    return hor_line




def distingish_row(lines2):
    line_hor = bubbleSort_row(lines2)
    section_line_hor = []
    if len(line_hor) == 0:
        return section_line_hor
    for i in range(len(line_hor)-1):
        if line_hor[i+1][0] - line_hor[i][0]>30:
            section_line_hor.append(line_hor[i])
    section_line_hor.append(line_hor[len(line_hor)-1])

    return section_line_hor



def line_segment(lines2):
    segment_point = []
    Pointdata = []
    count = 0
    cup = []
    lines3 = distingish_row(lines2)        
    for t in range(len(lines3)):
        a = np.sin(lines3[t][1])
        x0 = int(a*lines3[t][0])
        segment_point.append(x0)
    for p in range(len(segment_point)):
        for i in range(900):
            if (sum(thresh[segment_point[p]:segment_point[p]+4][i]) > 254):
                Pointdata.append([segment_point[p],i])
                count = count+1

            if (count > 100) and (thresh[segment_point[p]][i] == 0):
                cup.append(Pointdata[0])
                cup.append(Pointdata[-1])
                Pointdata = []
                count = 0
                    
                    
    return cup
        
        


def sliding_rect(thresh,stepSize,rectSize):
    for y in range(0,thresh.shape[0],stepSize):
        for x in range(0,thresh.shape[1],stepSize):
            yield (x,y,thresh[y:y+rectSize[1],x:x+rectSize[0]])


while(1):
    ret,frame = cap.read()
    for (lower,upper) in color:
        lower = np.array(lower,dtype = "uint8")
        upper = np.array(upper,dtype = "uint8")
        mask = cv2.inRange(frame,lower,upper)
        output = cv2.bitwise_and(frame,frame,mask=mask)
    gray = cv2.cvtColor(output,cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray,50,150,apertureSize = 3)
    blurred = cv2.GaussianBlur(gray,(5,5),0)
    ret,thresh = cv2.threshold(blurred,50,255,cv2.THRESH_BINARY)
    tmp = 118
    lines = cv2.HoughLines(edges,1,np.pi/180,tmp)
    lines1 = lines[:,0,:]
    lines2 = lines1
    if len(lines1)<25:
       for g in range(len(lines1)):
            if lines1[g][0]<0:
                lines2[g][0] = abs(lines1[g][0])
                lines2[g][1] = lines1[g][1]-3.14

    pointdata = line_segment(lines2)
    for rho1,theta1 in lines2[:]:
        a1 = np.cos(theta1)
        b1 = np.sin(theta1)
        x01 = a1*rho1
        y01 = b1*rho1
        x__ = int(x01 + 1000*(-b1))
        y__ = int(y01 + 1000*(a1))
        x__1 = int(x01 - 1000*(-b1))
        y__1 = int(y01 - 1000*(a1))
        cv2.line(frame,(x__,y__),(x__1,y__1),(0,255,0),2)
    print(pointdata)

    #cv2.circle(frame,(350,341),5,(0, 0, 255), -1)
    #cv2.circle(frame,(350,348),5,(0, 0, 255), -1)
    cv2.imshow("capture",frame)
    if cv2.waitKey(33) & 0XFF==ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

        
        

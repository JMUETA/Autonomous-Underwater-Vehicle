import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QFileDialog, QMessageBox, QOpenGLWidget
from PyQt5.QtCore import Qt, QDir, QRect, QTimer, QDateTime
from PyQt5.QtGui import QKeyEvent
from ui_mainwindow import Ui_MainWindow


import serial
import time

# from grabber import GLWidget

from QGLMat import QGLMat
import cv2

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()

        # Set up the user interface from Designer.
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.ui.actionOpen_O.triggered.connect(self.getConfig)
        self.ui.pushButton_openvideo.clicked.connect(self.openVideo)
        self.ui.pushButton_closevideo.clicked.connect(self.closeVideo)

        # self.ui.pushButton_forward.clicked.connect(self.goforward)
        # self.ui.pushButton_back.clicked.connect(self.gobackward)
        # self.ui.pushButton_left.clicked.connect(self.goleft)
        # self.ui.pushButton_right.clicked.connect(self.goright)

        self.ui.pushButton_record.clicked.connect(self.record)
        self.ui.pushButton_stoprecord.clicked.connect(self.stoprecord)

        self.ui.pushButton_changeport.clicked.connect(self.changeport)

        self.glmat = QGLMat(self.centralWidget())
        self.glmat.setGeometry(QRect(20, 0, 960, 540))

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.timerUpdate)

        self.vwrt = None
        self.vwrt_width = 960
        self.vwrt_height = 540

        # 打开串口

        self.ser = serial.Serial('COM3')


        if not self.ser:
            QMessageBox.information(self, "Oops", "打开串口失败", QMessageBox.Yes)



    def __del__(self):
        pass


    def getConfig(self):
        filename = QFileDialog.getOpenFileName(self, 'Open file', QDir.currentPath(), "All files (*)")
        # the return value is a tuple
        if filename[0]:
            QMessageBox.information(self, "PyQT5 message", filename[0], QMessageBox.Yes)

    def openVideo(self):
        self.cap = cv2.VideoCapture(0)
        if self.cap is None or not self.cap.isOpened():
            QMessageBox.information(self, "Oops", "Could not open video", QMessageBox.Yes)
        else:
            self.ui.statusbar.showMessage("视频已开启", 2000)
            width = int(self.ui.lineEdit_camera_width.text())
            height = int(self.ui.lineEdit_camera_height.text())
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
            #
            ret, mat = self.cap.read()
            if ret:
                self.ui.label.setText("视频已读取")
            else:
                self.ui.statusbar.showMessage("视频读取错误", 2000)


            self.timer.start(30)
            # self.ui.lineEdit.setText("Timer")

    def closeVideo(self):
        self.timer.stop()
        if self.cap and self.cap.isOpened():
            self.cap.release()
            self.glmat.setDefaultImage()
            self.ui.statusbar.showMessage("视频已关闭",2000)



    def goleft(self):
        while 1:
            ret = self.ser.write(b'\xaa\x55\x02\x01\x02')
            if ret == 5:
                break

    def goright(self):
        while 1:
            ret = self.ser.write(b'\xaa\x55\x02\x02\x02')
            if ret == 5:
                break

    def goforward(self):
        while 1:
            ret = self.ser.write(b'\xaa\x55\x02\x05\x02')
            if ret == 5:
                break

    def gobackward(self):
        while 1:
            ret = self.ser.write(b'\xaa\x55\x02\x06\x02')
            if ret == 5:
                break


    def goup(self):
        while 1:
            ret = self.ser.write(b'\xaa\x55\x02\x03\x02')
            if ret == 5:
                break

    def godown(self):
        while 1:
            ret = self.ser.write(b'\xaa\x55\x02\x04\x02')
            if ret == 5:
                break

    def stop_thruster(self):
        while 1:
            ret = self.ser.write(b'\xaa\x55\x02\x07\x02')
            if ret == 5:
                break




    def record(self):
        if self.vwrt is None:
            time = QDateTime.currentDateTime()
            timeT = time.toTime_t()
            # QMessageBox.information(self, "Oops", str(timeT), QMessageBox.Yes)
            filename = str(timeT) + '.avi'
            self.vwrt = cv2.VideoWriter(filename, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'), 30.0, (self.vwrt_width, self.vwrt_height), True)
            if self.vwrt is None or not self.vwrt.isOpened():
                self.ui.statusbar.showMessage("录制打开失败", 2000)
            else:
                self.ui.label.setText("录制中")

    def stoprecord(self):
        if not (self.vwrt is None):
            if self.vwrt.isOpened():
                self.vwrt.release()
                self.ui.label.setText("结束录制")
                self.vwrt = None




    def timerUpdate(self):
        # self.ui.label.setText("joke")
        ret, mat = self.cap.read()
        if ret:
            self.glmat.setImage(mat)

            if not (self.vwrt is None):
                simg = cv2.resize(mat, (self.vwrt_width, self.vwrt_height))
                self.vwrt.write(simg)



    def keyPressEvent(self, event):
        if type(event) == QKeyEvent and not event.isAutoRepeat():
            if event.key() == Qt.Key_W:
                self.goforward()
            elif event.key() == Qt.Key_S:
                self.gobackward()
            elif event.key() == Qt.Key_A:
                self.goleft()
            elif event.key() == Qt.Key_D:
                self.goright()
            elif event.key() == Qt.Key_K:
                self.goup()
            elif event.key() == Qt.Key_L:
                self.godown()

    def keyReleaseEvent(self, event):
        if type(event) == QKeyEvent  and not event.isAutoRepeat():
            if event.key() == Qt.Key_W:
                self.stop_thruster()
            elif event.key() == Qt.Key_S:
                self.stop_thruster()
            elif event.key() == Qt.Key_A:
                self.stop_thruster()
            elif event.key() == Qt.Key_D:
                self.stop_thruster()
            elif event.key() == Qt.Key_K:
                self.stop_thruster()
            elif event.key() == Qt.Key_L:
                self.stop_thruster()

    def changeport(self):
        if self.ser:
            self.ser.close()

        serial_port = self.ui.lineEdit_COM.text()
        self.ser = serial.Serial(serial_port)

        if not self.ser:
            QMessageBox.information(self, "Oops", "打开串口失败", QMessageBox.Yes)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainWindow()
    ex.show()
    sys.exit(app.exec_())
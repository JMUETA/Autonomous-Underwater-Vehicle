import cv2
import numpy as np
import math
import serial

cap = cv2.VideoCapture("C:\\Users\\96317\\Desktop\\OPENCV\\print\\GOPR.mp4")
cap.set(3,640)                              #设置分辨率
cap.set(4,480)
############### 参数 ###########################
color = [([84, 64, 75], [124, 104, 115])]

cX1_1 = 0
cY1_1 = 0
cX2_1 = 0
cY2_1 = 0

frame_count = 0

markerdata = [[],[],[],[],[]]

cen_x_th_value = 20                             #方差判断值（最小矩形检测是否稳定）
cen_y_th_value = 100
width_th_value = 70
higth_th_value = 140
angle_th_value = 0.2   

cen_x_th_value1 = 30                            #方差判断值（判断是否穿过框）
cen_y_th_value1 = 120
width_th_value1 = 90
higth_th_value1 = 160
angle_th_value1 = 0.5

distance = 3.6

xd,yd = 0,0

count_t=0
count_y=10
count_z=-10

key = 0

k1,k2=0,0

forcal = 600

##################################################



#############串口通信####################

#com = "COM3"                                    #串口通信口

#ser = serial.Serial(com)

###########################################



############################### 函数模块 ##########################

################# 算法函数 ###########

#kmeans聚类
def kmeans(img):
    Z = img.reshape((-1,3))
    Z = np.float32(Z)

    a = []

    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER,10,1.0)                    #

    ret,label,center = cv2.kmeans(Z,4,None,criteria,10,cv2.KMEANS_RANDOM_CENTERS)         #随机选择中心
    center = np.uint8(center)
    res = center[label.flatten()]
    res2 = res.reshape((img.shape))

    for i in range(4):
        b = center[i][0]
        g = center[i][1]
        r = center[i][2]
        r, g, b = r/255.0, g/255.0, b/255.0
        mx = max(r, g, b)
        mn = min(r, g, b)
        df = mx-mn
        if mx == mn:
            h = 0
        elif mx == b:
            h = (60 * ((g-b)/df) + 360) % 360
        elif mx == g:
            h = (60 * ((b-r)/df) + 120) % 360
        elif mx == r:
            h = (60 * ((r-g)/df) + 240) % 360
        if mx == 0:
            s = 0
        else:
            s = df/mx
        v = mx

        mask = np.zeros(img.shape[0:2],np.uint8)
        if (0<(h/2)<40) or (140<(h/2)<179):
            a.append(center[i])
            print(h/2)
            print(i)

            mask[label.reshape((540,960))==i]=255
            
    return mask


    #hsv

def get_fg_from_hue(frame, margin):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    dark = hsv[..., 2] < 32
    hsv[..., 0][dark] = 128

    mask = cv2.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
    mask2 = cv2.inRange(hsv[..., 0], np.array((180-margin)), np.array((180)))

    mask = cv2.bitwise_or(mask, mask2)

    return [mask, hsv[...,0]]



#分水岭

def get_fg_from_hue_watershed(img, margin):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    dark = hsv[..., 2] < 32
    hsv[..., 0][dark] = 128

    mask = cv2.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
    mask2 = cv2.inRange(hsv[..., 0], np.array((180-margin)), np.array((180)))

    mask = cv2.bitwise_or(mask, mask2)

    mask_bg = cv2.inRange(hsv[...,0], 60, 90)

    markers = np.zeros(mask.shape, np.int32)
    markers[mask == 255] = 1
    markers[mask_bg == 255] = 2

    cv2.watershed(img, markers)

    mask[markers == 1] = 255

    return [mask, hsv[...,0]]



def colorsection(frame):
    for (lower,upper) in color:
        lower = np.array(lower,dtype = "uint8")
        upper = np.array(upper,dtype = "uint8")
        mask = cv2.inRange(frame,lower,upper)
        output = cv2.bitwise_and(frame,frame,mask=mask)
    gray = cv2.cvtColor(output, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5,5), 0)
    edged = cv2.Canny(blurred, 40, 200,apertureSize=3)
    ret,thresh = cv2.threshold(blurred, 50, 255, cv2.THRESH_BINARY)

    return thresh

##########################################################
    
############### 命令函数 ###################
    
def control_orders(od_r):
    if od_r==1:
        ser.write(b'\xaa\x55\x02\x01\x02')
        print('left')
    if od_r==2:
        ser.write(b'\xaa\x55\x02\x02\x02')
        print('right')
    if od_r==3:
        ser.write(b'\xaa\x55\x02\x03\x02')
        print('up')
    if od_r==4:
        ser.write(b'\xaa\x55\x02\x04\x02')
        print('down')
    if od_r==5:
        ser.write(b'\xaa\x55\x02\x05\x02')
        print('go')
    if od_r==6:
        ser.write(b'\xaa\x55\x02\x06\x02')
        print('back')
    if od_r==7:
        ser.write(b'\xaa\x55\x02\x07\x02')
        print('stop')
    if od_r==8:
        ser.write(b'\xaa\x55\x02\x08\x02)
        print('continue go')
        
        
def order_remote(xd,yd):
    od = 7
    if yd > 30:
        od = 4
    if yd <(-30):
        od = 3
    if (yd<50) and (yd>(-50)):
        if xd >50:
            od=2
        if xd <(-50):
            od = 1
    if xd <40 and xd>(-40):
        od = 5

    return od
        
        
def order_accurate(xd,yd):
    od = 7
    if yd > 30:
        od = 4
    if yd <(-30):
        od = 3
    if (yd<50) and (yd>(-50)):
        if xd >50:
            od=2
        if xd <(-50):
            od = 1
    if xd <40 and xd>(-40):
        od = 8

    return od


     
        
############################################
    

############# 判断函数 ######################

def distance_to_camera(width,forcal,perwidth):              #距离计算
    return (width*forcal)/perwidth


#判断宽高比可行性
def feasibility(marker):                                    #可行性判断，当宽高比大于0.7则可行。
    if marker[1][0]/marker[1][1] >0.7:
        return 1
    else:
        return 0
    
    
def affirm_var(markerdata1):                                #过去4帧，现在1一帧的最小矩形中点位置，长度，宽度，角度的方差
    cen_x = []
    cen_y = []
    width = []
    higth = []
    angle = []
    for i in range(5):
        cen_x.append(markerdata1[i][0][0])
        cen_y.append(markerdata1[i][0][1])
        width.append(markerdata1[i][1][0])
        higth.append(markerdata1[i][1][1])
        angle.append(markerdata1[i][2])
    var_cen_x = np.var(cen_x)
    var_cen_y = np.var(cen_y)
    var_width = np.var(width)
    var_higth = np.var(higth)
    var_angle = np.var(angle)
    affirm_var = [var_cen_x,var_cen_y,var_width,var_higth,var_angle]
    #返回当前状态，x,y坐标，宽度，高度，角度方差
    return affirm_var

def stability(aff_value):
    if (aff_value[0] > cen_x_th_value1 or aff_value[1] > cen_y_th_value1 or 
        aff_value[2] > width_th_value1 or aff_value[3] > higth_th_value1 
        or aff_value[4] > angle_th_value1):
        return 1
    else:
        return 0

    if (aff_value[0] < cen_x_th_value and aff_value[1] < cen_y_th_value and 
        aff_value[2] < width_th_value and aff_value[3] < higth_th_value and
        aff_value[4] < angle_th_value and feasibility(marker)):
        return 2
    else:
        return 0


#############################################
        
    
################## 操作函数 #################
        
    
def position_row(X_center):                                #水平方向偏离中心距离
    offset_row = X_center - 320
    return offset_row

def position_column(Y_center):                          #竖直方向偏离中心距离
    offset_column = Y_center - 240
    return offset_column

def classify_column(lines2):                                #筛选竖线
    line_theta = []
    ver_line = []
    line_theta = lines2
    for j in range(len(lines2)):
        if line_theta[j][1]  <0.79 and line_theta[j][1]>(-0.79):
            #ver_line[j] = line_theta[j]
            ver_line.append(line_theta[j])
    return ver_line

def bubbleSort_column(lines2):                              
    ver_line = classify_column(lines2)
    for i in range(len(ver_line)-1):
        for j in range(len(ver_line)-i-1):  
            if ver_line[j][0] > ver_line[j+1][0]:
                ver_line[j], ver_line[j+1] = ver_line[j+1], ver_line[j]
    return ver_line


def distingish_column(lines2):                              #筛选出竖线
    line_ver = bubbleSort_column(lines2)
    section_line_ver = []
    if len(line_ver) == 0:
        return section_line_ver
    for i in range(len(line_ver)-1):
        if line_ver[i+1][0] - line_ver[i][0]>30:
            section_line_ver.append(line_ver[i])
    section_line_ver.append(line_ver[len(line_ver)-1])

    return section_line_ver


        
def circlepoint(markerdata1):                                   #计算最小矩形中心位置，距离画面中点位置距离
    cen_x,cen_y = markerdata1[0]
    dis_x = cen_x-270
    dis_y = cen_y-480
    distance = math.sqrt(dis_x*dis_x+dis_y*dis_y)
    return distance

def linepoint(lines2):
    lines = distingish_column(lines2)
    for rho1,theta1 in lines[:]:
        a1 = np.cos(theta1)
        x = a1*rho1
    return x


def modelsection(num,frame):
    if num==1:
        thresh = colorseciton(frame)
    if num==2:
        thresh = kmeans(frame)
    if num==3:
        thresh,hue = get_fg_from_hue_watershed(frame,20)
    return thresh

def cross_aim(frame):
    cv2.boxFilter(frame,-1,(5,5),frame)
    thresh,_ret = get_fg_from_hue(frame,20)
    face1 = thresh[220:260,0:640]
    frame1 = frame[220:260,0:640]
    face2 = thresh[0:480,300:340]
    frame2 = frame[0:480,300:340]
    face3 = thresh[0:239,300:340]
    frame3 = frame[0:239,300:340]
    face4 = thresh[220:260,0:319]
    frame4 = frame[220:260,0:319]
    face5 = thresh[220:480,300:340]
    frame5 = frame[220:480,300:340]
    face6 = thresh[220:260,320:640]
    frame6 = frame[220:260,320:640]
    
    cnts1 = cv2.findContours(face1.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)   
    cnts2 = cv2.findContours(face2.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)   
    cnts3 = cv2.findContours(face3.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    cnts4 = cv2.findContours(face4.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)    
    cnts5 = cv2.findContours(face5.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)   
    cnts6 = cv2.findContours(face6.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)         
    cnts1 = cnts1[1]
    cnts2 = cnts2[1]
    cnts3 = cnts3[1]
    cnts4 = cnts4[1]
    cnts5 = cnts5[1]
    cnts6 = cnts6[1]
    
    a=[]
    a=[cnts1,cnts2,cnts3,cnts4,cnts5,cnts6,frame1,frame2]
    
    return a 



#############################################################
    

################ 主程序 ########################
    

while(1):
    ret,frame = cap.read()
    thresh = modelsection(3,frame)
    
    cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[1]
    cnts0 = cv2.findContours(thresh.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    cnts0 = cnts0[1]
    if not(cnts0==[]):
        c = max(cnts0,key = cv2.contourArea)
        marker = cv2.minAreaRect(c)
        
    inches = distance_to_camera(Know_Width,forcal,marker[1][0]+1) #对象距离
        box = cv2.boxPoints(marker)                                 #获取最小外接矩形的四个顶点
        box = np.int0(box)
        cv2.drawContours(frame,[box],-1,(0,255,0),2)
        cv2.putText(frame,"%.2fft"%(inches/12),(frame.shape[1] - 200, frame.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX,
	    2.0, (0, 255, 0), 3)
            
        if not(c==[]):
            #边缘检测的轮廓中心
            for c_ in cnts:
                M = cv2.moments(c_)                                      #求图形的矩
                cX = int((M["m10"]+1) / (M["m00"]+1))
                cY = int((M["m01"] +1)/ (M["m00"]+1))
                cv2.drawContours(frame, [c_], -1, (0, 255, 0), 2)
            cv2.circle(frame, (cX, cY), 7, (255, 255, 255), -1)
            cv2.putText(frame, "center", (cX - 20, cY - 20),
            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
        
        if count_z==30:
            if cX>350:
                control_orders(1)
                print('left')
            if cX<290:
                #ser.write(b'\xaa\x55\x02\x02\x02')
                print('right')
            if cY<210:
                #ser.write(b'\xaa\x55\x02\x04\x02')
                print('down')
            if cY>270:
                #ser.write(b'\xaa\x55\x02\x03\x02')
                print('up')
     



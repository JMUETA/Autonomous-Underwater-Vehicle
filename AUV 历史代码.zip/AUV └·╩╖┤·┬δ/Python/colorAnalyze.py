#!/usr/bin/env python

'''
VideoCapture sample showcasing  some features of the Video4Linux2 backend

Sample shows how VideoCapture class can be used to control parameters
of a webcam such as focus or framerate.
Also the sample provides an example how to access raw images delivered
by the hardware to get a grayscale image in a very efficient fashion.

Keys:
    ESC    - exit
    g      - toggle optimized grayscale conversion

'''

# Python 2/3 compatibility
from __future__ import print_function

import sys
import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt

# hist_scale = 10
#
font = cv.FONT_HERSHEY_SIMPLEX
color = (255, 255, 0)

# def set_scale(val):
#     global hist_scale
#     hist_scale = val

def get_fg_from_hue(img, margin):
    hsv = cv.cvtColor(img, cv.COLOR_BGR2HSV)

    dark = hsv[..., 2] < 32
    hsv[..., 0][dark] = 128

    mask = cv.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
    mask2 = cv.inRange(hsv[..., 0], np.array((180-margin)), np.array((180)))

    mask = cv.bitwise_or(mask, mask2)

    return [mask, hsv[...,0]]


# def show_huv(event,x,y,flags,param):
#     if event == cv.EVENT_MOUSEMOVE:
#         hue = hsv[y,x,:]
#         # mask_=hsv[...,0].copy()
#         mask_=mask.copy()
#         cv.putText(mask_,str(hue[0]),(100,100),font,1.0,color)
#         cv.imshow("Video",mask_)



if __name__ == "__main__":

    # hsv_map = np.zeros((180, 256, 3), np.uint8)
    # h, s = np.indices(hsv_map.shape[:2])
    # hsv_map[:, :, 0] = h
    # hsv_map[:, :, 1] = s
    # hsv_map[:, :, 2] = 255
    # hsv_map = cv.cvtColor(hsv_map, cv.COLOR_HSV2BGR)
    # cv.imshow('hsv_map', hsv_map)
    #
    # cv.namedWindow('hist', 1)
    # cv.createTrackbar('scale', 'hist', hist_scale, 32, set_scale)

    # vfile = 'd:\AOV\gopro161.mp4'
    vfile = r"C:\\Users\\96317\\Desktop\\OPENCV\\print\\GOPR.mp4"
    # cap = cv.VideoCapture(sys.argv[1])
    cap = cv.VideoCapture(vfile)

    cv.namedWindow("Video")
    # cv.setMouseCallback('Video', show_huv)


    while True:
        status, img = cap.read()

        cv.boxFilter(img,-1,(5,5),img)
    
        mask, hue = get_fg_from_hue(img, 20)


        # hist = cv.calcHist([hsv], [0], None, [180], [0, 180])
        # h_red = np.vstack((hist[0:20],hist[-1-20:-1]))
        # plt.plot(h_red)
        #
        # h_mode  = np.argmax(h_red)

        # mean, std = cv.meanStdDev(img,None,None,mask)
        # mask3 = cv.inRange(img,mean-2*std, mean+2*std)
        # mask = cv.bitwise_or(mask,mask3)

        #
        #
        # h = cv.calcHist([hsv], [0, 1], None, [180, 256], [0, 180, 0, 256])
        #
        # h = np.clip(h * 0.005 * hist_scale, 0, 1)
        # vis = hsv_map * h[:, :, np.newaxis] / 255.0
        # cv.imshow('hist', vis)

        # cv.imshow("Video", hsv[...,0])
        cv.imshow("Video", mask)

        # plt.hist(hsv[:,:,0].flatten(), bins=180, range=(0, 180))
        # plt.title("Hue")
        # plt.show()

        # cv.imshow("Video", dark)

        k = cv.waitKey(0)

        if k == 27:
            break

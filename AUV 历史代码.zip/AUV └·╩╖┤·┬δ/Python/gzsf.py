from threading import Timer
import time

def func(msg,starttime):
    print ('aaaaaaaaaaaaaaaaaaaaaa')

Timer(5,func,('hello',time.time())).start()
while(1):
    print('s')

#!/usr/bin/env python

'''
VideoCapture sample showcasing  some features of the Video4Linux2 backend

Sample shows how VideoCapture class can be used to control parameters
of a webcam such as focus or framerate.
Also the sample provides an example how to access raw images delivered
by the hardware to get a grayscale image in a very efficient fashion.

Keys:
    ESC    - exit
    g      - toggle optimized grayscale conversion

'''

# Python 2/3 compatibility
from __future__ import print_function

import sys
import logging
import time
import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt

# hist_scale = 10
#
font = cv.FONT_HERSHEY_SIMPLEX
color = (255, 0, 255)
hue = None

def show_img(img):
    cv.imshow("temp", img)
    k = cv.waitKey(0)
    if k == 27:
        sys.exit()

def contour_info(img, area, aspect_ratio, extent, solidity, angle1, angle2, ellipse):
    color = (255,0,255)
    msg = "area %f; aspect %f; extent %f" % (area, aspect_ratio, extent)
    cv.putText(img, msg, (10, 30), font, 0.7, color)
    msg = "solidity %f; angle1 %f; angle2 %f" % (solidity, angle1, angle2)
    cv.putText(img, msg, (10, 80), font, 0.7, color)
    cv.ellipse(img, ellipse, (0, 255, 0), 2)


def get_fg_from_hue(img, margin):
    FRACTION_AS_BLANK = 0.003
    hsv = cv.cvtColor(img, cv.COLOR_BGR2HSV)

    dark = hsv[..., 2] < 32
    hsv[..., 0][dark] = 128

    dark = hsv[..., 1] < 50
    hsv[..., 0][dark] = 128

    mask = cv.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
    mask2 = cv.inRange(hsv[..., 0], np.array((180-margin)), np.array((180)))

    mask = cv.bitwise_or(mask, mask2)

    if cv.countNonZero(mask) < mask.shape[0]*mask.shape[1]*FRACTION_AS_BLANK:
        mask.fill(0)

    return [mask, hsv[...,0]]


def get_fg_from_hue_watershed(img, margin):
    mask, hue = get_fg_from_hue(img, margin)

    mask_bg = cv.inRange(hue, 60, 90)
    mask_bg = cv.bitwise_or(mask_bg, cv.inRange(hue,128,129))

    markers = np.zeros(mask.shape, np.int32)
    markers[mask == 255] = 1
    markers[mask_bg == 255] = 2

    cv.watershed(img, markers)
    mask[markers == 1] = 255

    # img2 = img.copy()
    # img2[markers == 1] = 255
    # cv.imshow("1", img2)
    #
    # img2 = img.copy()
    # img2[markers == 2] = 255
    # cv.imshow("2", img2)
    #
    # img2 = img.copy()
    # img2[markers == -1] = 255
    # cv.imshow("3", img2)

    return [mask, hue]


def guide_line_detect(img, area_th=15000, aspect_th=0.8):
    '''
    TODO：部分时候很靠近边框时，会检测到框
    :param img:
    :param area_th:
    :param aspect_th:
    :return:
    '''
    ASPECT_RATIO_MIN = 0.2 #重要参数
    MAX_CONTOUR_NUM = 6 #如果出现更多的轮廓，不进行处理。这是为了对抗白平衡

    mask, _ = get_fg_from_hue_watershed(img, 20)
    _, contours, hierarchy = cv.findContours(mask, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)

    # 目前对自动白平衡的处理，太多轮廓则直接返回
    candidates = []
    candidates_y = []
    if len(contours) < MAX_CONTOUR_NUM:
        for cnt in contours:
            area = cv.contourArea(cnt)
            if area > area_th:  # 关键参数
                (x1, y1), (w1, h1), angle1 = cv.minAreaRect(cnt)
                minAreaRect_area = w1 * h1
                aspect_ratio = float(w1) / h1
                if aspect_ratio > 1:
                    aspect_ratio = 1.0 / aspect_ratio
                    angle1 = np.mod(angle1 + 90, 180)

                extent = float(area) / minAreaRect_area

                hull = cv.convexHull(cnt)
                hull_area = cv.contourArea(hull)
                solidity = float(area) / hull_area

                (x2, y2), (MA, ma), angle2 = cv.fitEllipse(cnt)
                if angle2 > 90:
                    angle2 -= 180

                if aspect_ratio > aspect_th or aspect_ratio < ASPECT_RATIO_MIN  or extent < 0.7 or solidity < 0.7 or abs(angle1-angle2)>30:
                    break

                logging.debug('area %f,aspect_ratio %f,extent %f,solidity %f,angle1 %f,angle2 %f' % (area, aspect_ratio, extent, solidity, angle1, angle2))

                # img2 = img.copy()
                # contour_info(img2,area,aspect_ratio,extent,solidity,angle1,angle2,((x2, y2), (MA, ma), angle2))
                # cv.drawContours(img2, [cnt], 0, (0, 255, 0), 3)
                # show_img(img2)

                candidates.append((x1,y1,angle2))  #目前这个组合是比较好的。
                candidates_y.append(y1)

        nc = len(candidates)
        if nc == 0:
            return None
        elif nc == 1:
            return candidates[0]
        else:
            logging.debug('multiple')

            idx = np.argmax(np.array(candidates_y))
            return candidates[idx]

def show_huv(event,x,y,flags,param):
    if event == cv.EVENT_MOUSEMOVE:
        global mask

        mask_=mask.copy()
        cv.putText(mask_,str(hsv[y,x,1]),(100,100),font,1.0, (128, 0, 255))
        cv.imshow("Video",mask_)



if __name__ == "__main__":
    logging.basicConfig(filename='example.log', filemode='w', level=logging.DEBUG)

    # hsv_map = np.zeros((180, 256, 3), np.uint8)
    # h, s = np.indices(hsv_map.shape[:2])
    #     # hsv_map[:, :, 0] = h
    # hsv_map[:, :, 1] = s
    # hsv_map[:, :, 2] = 255
    # hsv_map = cv.cvtColor(hsv_map, cv.COLOR_HSV2BGR)
    # cv.imshow('hsv_map', hsv_map)
    #
    # cv.namedWindow('hist', 1)
    # cv.createTrackbar('scale', 'hist', hist_scale, 32, set_scale)

    # vfile = 'd:\AOV\gopro161.mp4'
    # vfile = 'd:\AOV\gopro3.mp4'
    vfile = r"d:\AOV\1531820734.avi"
    # vfile = r"d:\AOV\1531820502.avi"
    # vfile = r"d:\AOV\1531821044.avi"
    # vfile = r"d:\AOV\a6.avi"
    # cap = cv.VideoCapture(sys.argv[1])
    cap = cv.VideoCapture(vfile)

    cv.namedWindow("Video")
    cv.setMouseCallback('Video', show_huv)

    cv.namedWindow("Video2")


    while True:
        status, img = cap.read()

        cv.boxFilter(img,-1,(5,5),img)

        hsv = cv.cvtColor(img, cv.COLOR_BGR2HSV)

        mask1, hue = get_fg_from_hue(img, 20)
        t=time.clock()*1000
        mask2, hue = get_fg_from_hue_watershed(img, 20)
        print(time.clock()*1000-t)

        mask = mask1

        t=time.clock()*1000
        guide_line = guide_line_detect(img)
        print(time.clock()*1000-t)

        if guide_line:
            x, y, angle = guide_line
            angle = angle/180*np.pi
            cv.line(img, (int(x), int(y)), (int(x+100*np.sin(angle)), int(y-100*np.cos(angle))), (0, 255, 0), 2)



        cv.imshow("img",img)
        cv.imshow("Video", mask1)
        cv.imshow("Video2", mask2)


        k = cv.waitKey(15)


        if k == 32:
            cv.waitKey()
        if k == 27:
            break

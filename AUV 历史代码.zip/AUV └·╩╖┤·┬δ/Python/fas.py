b=0


def a():
    b = b+1
    print(b)
while 1:
    a()

import pandas as pd
import numpy as np

data = pd.read_csv('C:\\Users\\96317\\Desktop\\OPENCV\\data\\points_.csv')
x=0
y=0
z=0
for i in data.index:
    a = data.R.iloc[i]
    if(len(a)>3):
        a = a[1:4]
    else:
        a = a[1:3]
    b = eval(a)
    data.loc[i,'r']=b
    x = x+b

for t in data.index:
    a1 = data.G.iloc[i]
    #data.loc[t,'g']=a1
    z=z+a1



for j in data.index:
    c = data.B.iloc[j]
    if(len(c)>4):
        c = c[1:4]
    else:
        c = c[1:3]
    d = eval(c)
    data.loc[j,'b']=d
    y = y+d

print(x/400)
print(z/400)
print(y/400)

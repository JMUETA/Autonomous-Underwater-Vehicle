import numpy as np
import cv2

img = cv2.imread("C:\\Users\\96317\\Desktop\\OPENCV\\Q.png")
Z = img.reshape((-1,3))
Z = np.float32(Z)

a = []

j = 0

def bgr2hsv(center):

    b = center[3][0]
    g = center[3][1]
    r = center[3][2]
    r, g, b = r/255.0, g/255.0, b/255.0
    mx = max(r, g, b)
    mn = min(r, g, b)
    df = mx-mn
    if mx == mn:
        h = 0
    elif mx == r:
        h = (60 * ((g-b)/df) + 360) % 360
    elif mx == g:
        h = (60 * ((b-r)/df) + 120) % 360
    elif mx == b:
        h = (60 * ((r-g)/df) + 240) % 360
    if mx == 0:
        s = 0
    else:
        s = df/mx
    v = mx
    if (0<h<40) and (140<h<179):
        a.append(center[0])
    return a




criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER,10,1.0)                    #
klist = [2,4,6,8]


ret,label,center = cv2.kmeans(Z,6,None,criteria,10,cv2.KMEANS_RANDOM_CENTERS)         #随机选择中心
center = np.uint8(center)
res = center[label.flatten()]
res2 = res.reshape((img.shape))

idx = 10
for i in range(4):
    b = center[i][0]
    g = center[i][1]
    r = center[i][2]
    r, g, b = r/255.0, g/255.0, b/255.0
    mx = max(r, g, b)
    mn = min(r, g, b)
    df = mx-mn
    if mx == mn:
        h = 0
    elif mx == b:
        h = (60 * ((g-b)/df) + 360) % 360
    elif mx == g:
        h = (60 * ((b-r)/df) + 120) % 360
    elif mx == r:
        h = (60 * ((r-g)/df) + 240) % 360
    if mx == 0:
        s = 0
    else:
        s = df/mx
    v = mx
    if (0<(h/2)<40) or (140<(h/2)<179):
        a.append(center[i])
        print(h/2)
        print(i)

        mask = (label.reshape((540,960))==i)
        img[mask]=255
        cv2.imshow(str("1"),img)
        cv2.waitKey(0)



#cv2.imshow(str(("capt K=",1)),res2)




#output = cv2.bitwise_and(res2,res2)
gray = cv2.cvtColor(res2, cv2.COLOR_BGR2GRAY)
ret,thresh = cv2.threshold(gray,90,255, cv2.THRESH_BINARY)

th=cv2.bitwise_not(thresh,thresh)

cnts = cv2.findContours(th.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
cnts = cnts[0]


cnts0 = cv2.findContours(th.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
cnts0 = cnts0[1]
if not(cnts0==[]):
    c = max(cnts0,key = cv2.contourArea)
    marker = cv2.minAreaRect(c)  


box = cv2.boxPoints(marker)                                 #获取最小外接矩形的四个顶点
box = np.int0(box)
cv2.drawContours(img,[box],-1,(0,255,0),2)
#cv2.putText(img,"0",(img.shape[1] - 200, img.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX,
	   # 2.0, (0, 255, 0), 3)




for c in cnts:
    M = cv2.moments(c)                                      #求图形的矩
    cX = int((M["m10"]+1) / (M["m00"]+1))
    cY = int((M["m01"] +1)/ (M["m00"]+1))
    #cv2.drawContours(res2, [c], -1, (0, 255, 0), 2)
cv2.circle(img, (cX, cY), 7, (255, 255, 255), -1)
cv2.putText(img, "center", (cX - 20, cY - 20),
cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)



cv2.waitKey(0)

#cv2.imshow("s",img)
#cv2.imshow("b",th)


cv2.waitKey(0)
cv2.destroyAllWindows()

'''
主线程
'''
import os, time
import threading, queue
from controller import ControllerThread

# 无需修改
def get_result(q, time):
    result = None
    try:
        result = q.get(True, time)  # 等待 2ms，获取结果
    except queue.Empty:
        pass
    return result

def main(args):
    # Create a single input and a single output queue for all threads.
    cmd_q = queue.Queue()
    result_q = queue.Queue()

    controller = ControllerThread(cmd_q=cmd_q, result_q=result_q)
    controller.start()

    ####### 开始图像处理位置，或控制调试程序 ##################################

    cmd_q.put('D1')   #发送命令

    time.sleep(0.5)   #停止一段时间

    cmd_q.put('L1')

    time.sleep(0.5)

    cmd_q.put('F4')

    time.sleep(2)

    cmd_q.put('L1')

    time.sleep(1)

    cmd_q.put('F5')


    result = get_result(result_q, 0.002) # 等待 2ms，获取结果
    if result:
        print(result)

    ######## 结束图像处理位置，或控制调试程序 ###################################

    # 以下不要修改
    # Ask threads to die and wait for them to do it
    controller.join()


if __name__ == '__main__':
    import sys
    main(sys.argv[1:])
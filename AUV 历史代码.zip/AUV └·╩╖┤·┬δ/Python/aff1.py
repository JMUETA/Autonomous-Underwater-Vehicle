
import cv2
import numpy as np
import math
import imutils
import serial


Know_Distance = 30.0                              #已知距离
Know_Width = 2                                    #已知宽度
cap = cv2.VideoCapture("C:\\Users\\96317\\Desktop\\OPENCV\\print\\gopro3.mp4")
color = [([80, 68, 80], [150, 130, 140])]         
cX1_1 = 0
cY1_1 = 0
cX2_1 = 0
cY2_1 = 0
frame_count = 0
markerdata = [[],[],[],[],[]]
cen_x_th_value = 20                             #方差判断值（最小矩形检测是否稳定）
cen_y_th_value = 100
width_th_value = 70
higth_th_value = 140
angle_th_value = 0.2                        

cen_x_th_value1 = 30                            #方差判断值（判断是否穿过框）
cen_y_th_value1 = 120
width_th_value1 = 90
higth_th_value1 = 160
angle_th_value1 = 0.5


key = 0

k1,k2=0,0

com = "COM5"                                    #串口通信口

ser = serial.Serial(com,9600,timeout = 0.5)     #串口通信初始化

def distance_to_camera(width,forcal,perwidth):              #距离计算
    return (width*forcal)/perwidth

def position_row(X_center):                                #水平方向偏离中心距离
    offset_row = X_center - 540
    return offset_row

def position_column(Y_center):                             #竖直方向偏离中心距离
    offset_column = Y_center - 270
    return offset_column


def classify_column(lines2):                                #筛选竖线
    line_theta = []
    ver_line = []
    line_theta = lines2
    for j in range(len(lines2)):
        if line_theta[j][1]  <0.79 and line_theta[j][1]>(-0.79):
            #ver_line[j] = line_theta[j]
            ver_line.append(line_theta[j])
    return ver_line



def bubbleSort_column(lines2):                              
    ver_line = classify_column(lines2)
    for i in range(len(ver_line)-1):
        for j in range(len(ver_line)-i-1):  
            if ver_line[j][0] > ver_line[j+1][0]:
                ver_line[j], ver_line[j+1] = ver_line[j+1], ver_line[j]
    return ver_line


def distingish_column(lines2):                              #筛选出竖线
    line_ver = bubbleSort_column(lines2)
    section_line_ver = []
    if len(line_ver) == 0:
        return section_line_ver
    for i in range(len(line_ver)-1):
        if line_ver[i+1][0] - line_ver[i][0]>30:
            section_line_ver.append(line_ver[i])
    section_line_ver.append(line_ver[len(line_ver)-1])

    return section_line_ver

    
def affirm_var(markerdata1):                                #过去4帧，现在1一帧的最小矩形中点位置，长度，宽度，角度的方差
    cen_x = []
    cen_y = []
    width = []
    higth = []
    angle = []
    for i in range(5):
        cen_x.append(markerdata1[i][0][0])
        cen_y.append(markerdata1[i][0][1])
        width.append(markerdata1[i][1][0])
        higth.append(markerdata1[i][1][1])
        angle.append(markerdata1[i][2])
    var_cen_x = np.var(cen_x)
    var_cen_y = np.var(cen_y)
    var_width = np.var(width)
    var_higth = np.var(higth)
    var_angle = np.var(angle)
    affirm_var = [var_cen_x,var_cen_y,var_width,var_higth,var_angle]
    #返回当前状态，x,y坐标，宽度，高度，角度方差
    return affirm_var
        
def circlepoint(markerdata1):                                   #计算最小矩形中心位置，距离画面中点位置距离
    cen_x,cen_y = markerdata1[0]
    dis_x = cen_x-270
    dis_y = cen_y-480
    distance = math.sqrt(dis_x*dis_x+dis_y*dis_y)
    return distance

def linepoint(lines2):
    lines = distingish_column(lines2)
    for rho1,theta1 in lines[:]:
        a1 = np.cos(theta1)
        x = a1*rho1
    return x

def feasibility(marker):                                        #可行性判断，当宽高比大于0.7则可行。
    if marker[1][0]/marker[1][1] >0.7:
        return 1
    else:
        return 0
    
    
    
    

while(1):
    #将图像进行颜色提取，模糊，二值化
    ret,frame = cap.read()
    for (lower,upper) in color:
        lower = np.array(lower,dtype = "uint8")
        upper = np.array(upper,dtype = "uint8")
        mask = cv2.inRange(frame,lower,upper)
        output = cv2.bitwise_and(frame,frame,mask=mask)
    gray = cv2.cvtColor(output, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5,5), 0)
    edged = cv2.Canny(blurred, 40, 200,apertureSize=3)
    ret,thresh = cv2.threshold(blurred, 50, 255, cv2.THRESH_BINARY)

    #边缘检测，寻找最小外接矩形    
    cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[0] if imutils.is_cv2() else cnts[1]
    cnts0 = cv2.findContours(thresh.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    cnts0 = cnts0[1]
    c = max(cnts0,key = cv2.contourArea)
    marker = cv2.minAreaRect(c)                                 #得到最小外接矩形（中心(x,y),（宽，高），选住角度）


    #forcal = (marker[1][0]*Know_Distance)/Know_Width           #forcal（焦距）需要实际测试
    forcal = 600
    inches = distance_to_camera(Know_Width,forcal,marker[1][0]) #对象距离
    box = cv2.boxPoints(marker)                                 #获取最小外接矩形的四个顶点
    box = np.int0(box)
    cv2.drawContours(frame,[box],-1,(0,255,0),2)
    cv2.putText(frame,"%.2fft"%(inches/12),(frame.shape[1] - 200, frame.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX,
	2.0, (0, 255, 0), 3)


    #边缘检测的轮廓中心
    for c in cnts:
        M = cv2.moments(c)                                      #求图形的矩
        cX = int((M["m10"]+1) / (M["m00"]+1))
        cY = int((M["m01"] +1)/ (M["m00"]+1))
        #cv2.drawContours(frame, [c], -1, (0, 255, 0), 2)
    cv2.circle(frame, (cX, cY), 7, (255, 255, 255), -1)
    cv2.putText(frame, "center", (cX - 20, cY - 20),
    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)


    #判定操作
    markerdata[frame_count] = marker                            #将最小外接矩形数据存放到一个二维列表
    frame_count = frame_count+1                                 #计数
    if frame_count == 5:                                        #计数为5时，再次清零  
        frame_count = 0

    if not(markerdata[4]==[]):                                    #当markerdata的内容有五个数据（也就是存放了历史4帧以及现在1帧的数据）
        markerdata1 = markerdata                                #markerdata数据传递给markerdata1，用于以上affirm_var函数，circilepoint函数做形式参数
        aff_value = affirm_var(markerdata1)
        
    #通过向com1端口传最小外接矩形的中点坐标
        if aff_value[0] < cen_x_th_value and aff_value[1] < cen_y_th_value and aff_value[2] < width_th_value and aff_value[3] < higth_th_value and aff_value[4] < angle_th_value and feasibility(marker):
            if ser.isOpen():
                ser.write('\xAA \x55 \x02 \x01 \x02'.encode())
                print(int(marker[0][0]),int(marker[0][1]))

        
    #进入对准模式（当inches/小于3时）
            if (inches < 3.2):
                face1 = thresh[250:290,0:960]                       #分割画面
                frame1 = frame[250:290,0:960]
                face2 = thresh[0:540,460:500]
                frame2 = frame[0:540,460:500]
                face3 = thresh[0:269,460:500]
                frame3 = frame[0:269,460:500]
                face4 = thresh[250:290,0:479]
                frame4 = frame[250:290,0:479]
                face5 = thresh[270:540,460:500]
                frame5 = frame[270:540,460:500]
                face6 = thresh[250:290,480:960]
        

                cnts1 = cv2.findContours(face1.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)       #cnts1十字横轴
                cnts1 = cnts1[0] if imutils.is_cv2() else cnts1[1]
                cnts2 = cv2.findContours(face2.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)       #cnts2十字纵轴
                cnts2 = cnts2[0] if imutils.is_cv2() else cnts2[1]

                cnts3 = cv2.findContours(face3.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)       #cnts3纵轴上半部分
                cnts3 = cnts3[0] if imutils.is_cv2() else cnts3[1]
                cnts4 = cv2.findContours(face4.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)       #cnts4横轴左半部分
                cnts4 = cnts4[0] if imutils.is_cv2() else cnts4[1]
                cnts5 = cv2.findContours(face5.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)       #cnts5纵轴下半部分
                cnts5 = cnts5[0] if imutils.is_cv2() else cnts5[1]
                cnts6 = cv2.findContours(face6.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)       #cnts6横轴右半部分
                cnts6 = cnts6[0] if imutils.is_cv2() else cnts6[1]
        
        

                for c1 in cnts1:
                    M1 = cv2.moments(c1)
                    cX1 = int((M1["m10"]+1) / (M1["m00"]+1))
                    cY1 = int((M1["m01"] +1)/ (M1["m00"]+1))
                    cv2.drawContours(frame1, [c1], -1, (0, 255, 0), 2)          
            #cv2.circle(frame, (cX1, cY1), 7, (255, 0, 0), -1)

                    if not(cnts4==[]):
                        c44 = max(cnts4,key = cv2.contourArea)                          #对十字视野内的画面找最大（下同）
                        marker44 = cv2.minAreaRect(c44)
                        box44 = cv2.boxPoints(marker44)
                        box44 = np.int0(box44)
                        cv2.drawContours(frame,[box44],-1,(0,255,0),2)
                    if not(cnts6==[]):
                        c66 = max(cnts6,key = cv2.contourArea)
                        marker66 = cv2.minAreaRect(c66)
                        box66 = cv2.boxPoints(marker66)
                        box66 = np.int0(box66)
                        cv2.drawContours(frame,[box66],-1,(0,255,0),2)
                        
                
                    if not(cnts4==[]) and not(cnts6==[]):
                        X_center = int((marker44[0][0]+marker66[0][0]+480)/2)
                        xd = position_row(X_center)
                        k1=1
                        cv2.circle(frame,(int((marker44[0][0]+marker66[0][0]+480)/2),int((marker44[0][1]+marker66[0][1]+270)/2)),7,(0,255,0),2)
                    if cnts4==[] or cnts6==[]:
                        cv2.circle(frame, (cX1, cY1), 7, (255, 0, 0), -1)
                                

            

                for c2 in cnts2:
                    M2 = cv2.moments(c2)
                    cX2 = int((M2["m10"]+1) / (M2["m00"]+1))
                    cY2 = int((M2["m01"] +1)/ (M2["m00"]+1))
                    cv2.drawContours(frame2, [c2], -1, (0, 0, 255), 2)
            #cv2.circle(frame, (cX2, cY2), 7, (0, 0, 255), -1)            
            
                    if not(cnts3==[]):
                        c33 = max(cnts3,key = cv2.contourArea)
                        marker33 = cv2.minAreaRect(c33)
                        box33 = cv2.boxPoints(marker33)
                        box33 = np.int0(box33)
                #cv2.drawContours(frame,[box33],-1,(0,255,0),2)

                    if not(cnts5==[]):
                        c55 = max(cnts5,key = cv2.contourArea)
                        marker55 = cv2.minAreaRect(c55)
                        box55 = cv2.boxPoints(marker55)
                        box55 = np.int0(box55)
                        
                #cv2.drawContours(frame,[box55],-1,(0,255,0),2)
                    if not(cnts3==[]) and not(cnts5==[]):
                        Y_center = int((marker33[0][1]+marker55[0][1]+270)/2)
                        yd = position_column(Y_center)
                        k2=1
                        cv2.circle(frame,(int((marker33[0][0]+marker55[0][0]+480)/2),int((marker33[0][1]+marker55[0][1]+270)/2)),7,(0,0,255),2)
                        
                    if cnts3==[] or cnts5==[]:
                        cv2.circle(frame, (cX2, cY2), 7, (255, 0, 0), -1)
                        
            
                    

                    
                #print(Y_center)
        #向端口传送横纵方向的中点偏差
                #ser1 = serial.Serial(com,9600,timeout = 0.5)
                if k1 and k2:
                    if ser.isOpen():
                        #ser.write(2)
                        print(xd,yd)
                        key = 1
        #是否通过框（通过检测视野内是否还存在竖线，如果还存在就一定还没穿过）
        if (aff_value[0] > cen_x_th_value1 or aff_value[1] > cen_y_th_value1 or aff_value[2] > width_th_value1 or aff_value[3] > higth_th_value1 or aff_value[4] < angle_th_value1) and key:
            tmp = 118
            lines = cv2.HoughLines(thresh,1,np.pi/180,tmp)
            lines1 = lines[:,0,:]
            lines2 = lines1
            for g in range(len(lines1)):
                if lines1[g][0]<0:
                    lines2[g][0] = abs(lines1[g][0])
                    lines2[g][1] = lines1[g][1]-3.14


            xd1 = linepoint(lines2)
            #ser2 = serial.Serial(com,9600,time = 0.5)
            if ser.isOpen():
                #ser.write(2)
                print(int(xd1))
                key = 0
            
            
                cv2.imshow("123",frame1)
                cv2.imshow("312",frame2)
        

    cv2.imshow("capture",frame)
    if cv2.waitKey(0) & 0XFF==ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

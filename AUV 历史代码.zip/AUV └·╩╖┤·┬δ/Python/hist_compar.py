import cv2
import numpy as np
import matplotlib.pyplot as plt

img=cv2.imread("C:\\Users\\96317\\Desktop\\OPENCV\\photos\\1.jpg")
img1 = cv2.imread("C:\\Users\\96317\\Desktop\\OPENCV\\photos\\2.jpg")

# Comparing histograms
H1=cv2.calcHist([img],[1],None,[256],[0,256]) # 统计第2个波段
H1=cv2.normalize(H1,H1,0,1,cv2.NORM_MINMAX,-1) # 归一化
H2=cv2.calcHist([img1],[1],None,[256],[0,256])
H2=cv2.normalize(H2,H2,0,1,cv2.NORM_MINMAX,-1)

Similarity=cv2.compareHist(H1,H2,0) # 比较直方图
print(Similarity) # 0.55

plt.subplot(2,1,1);plt.plot(H1)
plt.subplot(2,1,2);plt.plot(H2)
plt.show()

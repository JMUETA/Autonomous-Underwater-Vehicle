import cv2
import numpy as np
import math
import matplotlib.pyplot as plt

cap = cv2.VideoCapture('COM3')
color = [([80, 68, 80], [150, 130, 140])]



rectW,rectH = 20,540


    


def classify_column(lines2):
    line_theta = []
    ver_line = []
    line_theta = lines2
    for j in range(len(lines2)):
        if line_theta[j][1]  <0.79 and line_theta[j][1]>(-0.79):
            #ver_line[j] = line_theta[j]
            ver_line.append(line_theta[j])
    return ver_line          

def bubbleSort_column(lines2):
    ver_line = classify_column(lines2)
    for i in range(len(ver_line)-1):
        for j in range(len(ver_line)-i-1):  
            if ver_line[j][0] > ver_line[j+1][0]:
                ver_line[j], ver_line[j+1] = ver_line[j+1], ver_line[j]
    return ver_line



def distingish_column(lines2):
    line_ver = bubbleSort_column(lines2)
    section_line_ver = []
    if len(line_ver) == 0:
        return section_line_ver
    for i in range(len(line_ver)-1):
        if line_ver[i+1][0] - line_ver[i][0]>30:
            section_line_ver.append(line_ver[i])
    section_line_ver.append(line_ver[len(line_ver)-1])

    return section_line_ver


def line_segment(lines2):
    segment_point = []
    Pointdata = []
    count = 0
    cup = []
    lines3 = distingish_column(lines2)        
    for t in range(len(lines3)):
        a = np.cos(lines3[t][1])
        x0 = int(a*lines3[t][0])
        segment_point.append(x0)
        x1 = int(lines3[t][0]/np.cos(lines3[t][1]))
        x2 = int((lines3[t][0]-539*np.sin(lines3[t][1]))/np.cos(lines3[t][1]))
        print(x1)
        print(x2)
    for p in range(len(segment_point)):
        for i in range(530):
            if (sum(thresh[i][segment_point[p]-4:segment_point[p]+4]) > 800):
                Pointdata.append([i,segment_point[p]])
                count = count+1

            if (count > 100) and (thresh[i,segment_point[p]] == 0):
                cup.append(Pointdata[0])
                cup.append(Pointdata[-1])
                Pointdata = []
                count = 0
                    
                    
    return cup
        
        


def sliding_rect(thresh,stepSize,rectSize):
    for y in range(0,thresh.shape[0],stepSize):
        for x in range(0,thresh.shape[1],stepSize):
            yield (x,y,thresh[y:y+rectSize[1],x:x+rectSize[0]])


while(1):
    ret,frame = cap.read()
    for (lower,upper) in color:
        lower = np.array(lower,dtype = "uint8")
        upper = np.array(upper,dtype = "uint8")
        mask = cv2.inRange(frame,lower,upper)
        output = cv2.bitwise_and(frame,frame,mask=mask)
    gray = cv2.cvtColor(output,cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray,50,150,apertureSize = 3)
    blurred = cv2.GaussianBlur(gray,(5,5),0)
    ret,thresh = cv2.threshold(blurred,50,255,cv2.THRESH_BINARY)
    tmp = 118
    lines = cv2.HoughLines(edges,1,np.pi/180,tmp)
    lines1 = lines[:,0,:]
    lines2 = lines1
    if len(lines1)<25:
       for g in range(len(lines1)):
            if lines1[g][0]<0:
                lines2[g][0] = abs(lines1[g][0])
                lines2[g][1] = lines1[g][1]-3.14
                
    pointdata = line_segment(lines2)
    pointdata1 = []
    if len(pointdata) > 2:
        pointdata1.append(pointdata[0])
        for i1 in range(len(pointdata)-1):
            if abs(pointdata[i1][1]-pointdata[i1+1][1]) > 30:
                pointdata1.append(pointdata[i1])
                pointdata1.append(pointdata[i1+1])
        pointdata1.append(pointdata[-1])
    if len(pointdata1)>3:
        X1 = pointdata1[0][1]
        Y1 = pointdata1[0][0]
        X2 = pointdata1[1][1]
        Y2 = pointdata1[1][0]
        X3 = pointdata1[2][1]
        Y3 = pointdata1[2][0]
        X4 = pointdata1[3][1]
        Y4 = pointdata1[3][0]
        cv2.line(thresh,(X1,Y1),(X2,Y2),(128,255,0),2)
        cv2.line(thresh,(X3,Y3),(X4,Y4),(128,255,0),2)
            
    #print(pointdata)   
    #pointdata = pointdata.sort()
    #print(pointdata1)
    
    for rho1,theta1 in lines2[:]:
        a1 = np.cos(theta1)
        b1 = np.sin(theta1)
        x01 = a1*rho1
        y01 = b1*rho1
        x__ = int(x01 + 1000*(-b1))
        y__ = int(y01 + 1000*(a1))
        x__1 = int(x01 - 1000*(-b1))
        y__1 = int(y01 - 1000*(a1))
        #cv2.line(frame,(x__,y__),(x__1,y__1),(0,255,0),2)

    #cv2.circle(frame,(350,341),5,(0, 0, 255), -1)
    #cv2.circle(frame,(350,348),5,(0, 0, 255), -1)
    cv2.imshow("capture",frame)
    if cv2.waitKey() & 0XFF==ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

        
        



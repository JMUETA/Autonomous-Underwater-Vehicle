import configparser

conf = configparser.ConfigParser()
conf.read(r'C:\Users\96317\Desktop\Programming\Python\Untitled Folder\Rose and Lion.txt')
print(conf.get('DEFAULT','Mainland'))
print(conf.get('DEFAULT','Era'))

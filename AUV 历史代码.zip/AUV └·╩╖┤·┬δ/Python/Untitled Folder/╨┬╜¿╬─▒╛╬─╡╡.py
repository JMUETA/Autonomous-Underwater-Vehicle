from functools import singledispatch

@singledispatch
def fun(arg,verbose=False):
    if verbose:
        print('Let me just say,',end=' ')
    print(arg)

@fun.register(int)
def _(arg,verbose=False):
    if verbose:
        print('Strength in numbers,',end=' ')
    print(arg)

@fun.register(float)
def fun_num(arg,verbpse=False):
    if verbose:
        print('Half of your number is:',end=' ')
    print(arg/2)


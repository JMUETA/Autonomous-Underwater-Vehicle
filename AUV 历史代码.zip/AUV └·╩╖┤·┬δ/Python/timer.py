import time
import threading

def func():
    print("Hello")

timer = threading.Timer(5,func)
timer.start()

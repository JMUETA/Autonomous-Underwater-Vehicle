# import the necessary packages

import argparse
import time
import cv2


def sliding_window(image, stepSize, windowSize):
    for y in range(0, image.shape[0], stepSize):
        for x in range(0, image.shape[1], stepSize):
            yield (x, y, image[y:y + windowSize[1], x:x + windowSize[0]])

 
# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-i", "--image", required=True, help="Path to the image")
args = vars(ap.parse_args(["-i",r"C:\Users\96317\Desktop\Vision\OPENCV\lena.png"]))
 
# load the image and define the window width and height
image = cv2.imread(args["image"])
(winW, winH) = (128, 540)

# loop over the image pyramid
	# loop over the sliding window for each layer of the pyramid
for (x, y, window) in sliding_window(image, stepSize=32, windowSize=(winW, winH)):
    if window.shape[0] != winH or window.shape[1] != winW:
        continue

    clone = image.copy()
    cv2.rectangle(clone, (x, y), (x + winW, y + winH), (0, 255, 0), 2)
    cv2.imshow("Window", clone)
    cv2.waitKey(1)
    time.sleep(0.025)



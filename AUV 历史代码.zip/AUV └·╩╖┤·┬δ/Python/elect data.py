import numpy as np
import matplotlib.pyplot as plt


fig = plt.figure(1)

ax1 = plt.subplot(111)
data=np.array([5,1,7,1,1,2,47,27,58])

width=0.5
x_bar=np.arange(9)

rect=ax1.bar(left=x_bar,height=data,width=width,color="lightblue")

for rec in rect:
    x=rec.get_x()
    height=rec.get_height()
    ax1.text(x+0.1,1.02*height,str(height))

ax1.set_xticks(x_bar)
ax1.set_xticklabels(('CE','PE','CS','CT','CB','CM','EE','cE','ES'))
ax1.set_ylabel("Member count")
ax1.set_title("The 2018 Electronic Technology Association's new data ")
ax1.set_xlabel('College')
ax1.grid(True)
ax1.set_ylim(0,60)
plt.show()

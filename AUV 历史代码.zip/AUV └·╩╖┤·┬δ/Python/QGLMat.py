from PyQt5.QtWidgets import QMessageBox, QOpenGLWidget
from PyQt5.QtGui import QColor
from PyQt5.QtGui import QOpenGLVersionProfile, QSurfaceFormat

import cv2
import numpy as np

class QGLMat(QOpenGLWidget):
    def __init__(self, parent=None):
        super(QGLMat, self).__init__(parent)

        self.hidden = False
        self.bgColor = QColor.fromRgb(0xe0,0xdf,0xe0)

        # self.mat = np.zeros((self.height(),self.width(),3),dtype=np.uint8)
        # self.mat[0:self.height()/2,:,0]=255
        # self.mat[self.height()/2:, :, 1] = 255
        # self.mat[:,0:self.width()/2,2]=255
        # self.mat[:,self.width()/2:self.width(), 0] = 255
        #
        # cv2.imwrite("joke.png",self.mat)

        self.default_img = np.ones((600, 800, 3), dtype=np.uint8)
        self.default_img *= 128

        self.mat = self.default_img
        # self.mat = cv2.imread('sky2.png',1)

        # format = {
        #     1:QOpenGLWidget,
        # }
        self.drawing = False
        # self.setMouseTracking(True)
        # self.initializeGL()

    def initializeGL(self):
        f = QSurfaceFormat()  # The default
        p = QOpenGLVersionProfile(f)
        self.gl = self.context().versionFunctions(p)
        self.gl.initializeOpenGLFunctions()

        # self.gl.glClearColor(128.0, 128.0, 128.0, 1.0)

        self.gl.glDisable(self.gl.GL_DEPTH_TEST)
        self.gl.glMatrixMode(self.gl.GL_PROJECTION)
        self.gl.glLoadIdentity()
        self.gl.glOrtho(0, self.width(), self.height(), 0.0, 0.0, 1.0)
        self.gl.glMatrixMode(self.gl.GL_MODELVIEW)
        self.gl.glLoadIdentity()

        self.gl.glEnable(self.gl.GL_TEXTURE_2D)
        self._texture_id = self.gl.glGenTextures(1)
        self.gl.glBindTexture(self.gl.GL_TEXTURE_2D, self._texture_id)
        self.gl.glTexParameteri(self.gl.GL_TEXTURE_2D, self.gl.GL_TEXTURE_MAG_FILTER, self.gl.GL_LINEAR)
        self.gl.glTexParameteri(self.gl.GL_TEXTURE_2D, self.gl.GL_TEXTURE_MIN_FILTER, self.gl.GL_LINEAR)
        self.gl.glTexImage2D(self.gl.GL_TEXTURE_2D, 0, self.gl.GL_RGB, self.width(), self.height(), 0, self.gl.GL_BGR, self.gl.GL_UNSIGNED_BYTE, None)
        self.gl.glDisable(self.gl.GL_TEXTURE_2D)

    def paintGL(self):
        self.gl.glClear(self.gl.GL_COLOR_BUFFER_BIT | self.gl.GL_DEPTH_BUFFER_BIT)
        self.gl.glDisable(self.gl.GL_DEPTH_TEST)
        if  not self.hidden:
            self.gl.glEnable(self.gl.GL_TEXTURE_2D)
            self.gl.glBindTexture(self.gl.GL_TEXTURE_2D, self._texture_id)

            self.gl.glTexImage2D(self.gl.GL_TEXTURE_2D, 0, self.gl.GL_RGB, self.mat.shape[1], self.mat.shape[0], 0, self.gl.GL_BGR, self.gl.GL_UNSIGNED_BYTE, self.mat.tobytes())
            self.gl.glBegin(self.gl.GL_QUADS)
            self.gl.glTexCoord2i(0, 1)
            self.gl.glVertex2i(0, self.height())
            self.gl.glTexCoord2i(0, 0)
            self.gl.glVertex2i(0, 0)
            self.gl.glTexCoord2i(1, 0)
            self.gl.glVertex2i(self.width(), 0)
            self.gl.glTexCoord2i(1, 1)
            self.gl.glVertex2i(self.width(), self.height())
            self.gl.glEnd()
            self.gl.glFlush()

    def resizeGL(self, w: int, h: int):
        self.gl.glViewport(0, 0, self.width(), self.height())
        self.gl.glMatrixMode(self.gl.GL_PROJECTION)
        self.gl.glLoadIdentity()
        self.gl.glOrtho(0.0, self.width(), self.height(), 0.0, 0.0, 1.0)
        self.gl.glMatrixMode(self.gl.GL_MODELVIEW)
        self.gl.glLoadIdentity()

    def setImage(self, mat: np.array):
        self.mat = mat
        self.update()

    def setDefaultImage(self):
        self.mat = self.default_img
        self.update()

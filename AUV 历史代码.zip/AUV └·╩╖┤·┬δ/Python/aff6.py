from __future__ import print_function
import cv2
import numpy as np
import math
import serial
import time
import sys
import logging
import matplotlib.pyplot as plt



cap1 = cv2.VideoCapture(1)

color = [([84, 64, 75], [124, 104, 115])]

Know_Distance = 30.0                                    # 已知距离
Know_Width = 25.2                                       # 已知宽度

cap1.set(3, 640)                                         # 设置分辨率
cap1.set(4, 480)

############################## 参数部分 ####################################
marker =0
aff_value = 0
cX = 0
cY = 0

cX1_1 = 0
cY1_1 = 0
cX2_1 = 0
cY2_1 = 0

frame_count = 0                                         #五帧稳定性计数

markerdata = [[], [], [], [], []]                       #存储五帧数组

cen_x_th_value = 20                                     # 方差判断值（最小矩形检测是否稳定）
cen_y_th_value = 100
width_th_value = 70
higth_th_value = 140
angle_th_value = 0.2

cen_x_th_value1 = 30                                    # 方差判断值（判断是否穿过框）
cen_y_th_value1 = 120
width_th_value1 = 90
higth_th_value1 = 160
angle_th_value1 = 0.5

distance = 5

xd, yd = 0, 0

count_t = 0
count_y = 10
count_z = -10

count_sb = 100000

count_frame = 0

key = 0

k1, k2 = 0, 0

forcal = 600
# forcal = (marker[1][0]*Know_Distance)/Know_Width           #forcal（焦距）需要实际测试

# hist_scale = 10
font = cv2.FONT_HERSHEY_SIMPLEX
color = (255, 0, 255)
hue = None

tmp = 118

#############################################################




####################### 串口通信 ############################

# com = "COM3"                                                  #串口通信口
#
# ser = serial.Serial(com)

############################################################



############################################ 函数模块 ############################################################



######################## 识别算法 ##############################



def kmeans(img):                                                # kmeans聚类
    Z = img.reshape((-1, 3))
    Z = np.float32(Z)

    a = []

    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)  #

    ret, label, center = cv2.kmeans(Z, 4, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)  # 随机选择中心
    center = np.uint8(center)
    res = center[label.flatten()]
    res2 = res.reshape((img.shape))

    for i in range(4):
        b = center[i][0]
        g = center[i][1]
        r = center[i][2]
        r, g, b = r / 255.0, g / 255.0, b / 255.0
        mx = max(r, g, b)
        mn = min(r, g, b)
        df = mx - mn
        if mx == mn:
            h = 0
        elif mx == b:
            h = (60 * ((g - b) / df) + 360) % 360
        elif mx == g:
            h = (60 * ((b - r) / df) + 120) % 360
        elif mx == r:
            h = (60 * ((r - g) / df) + 240) % 360
        if mx == 0:
            s = 0
        else:
            s = df / mx
        v = mx

        mask = np.zeros(img.shape[0:2], np.uint8)
        if (0 < (h / 2) < 40) or (140 < (h / 2) < 179):
            a.append(center[i])
            print(h / 2)
            print(i)

            mask[label.reshape((540, 960)) == i] = 255

    return mask

    # hsv


def get_fg_from_hue(frame, margin):                             #rgb转hsv
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    dark = hsv[..., 2] < 32
    hsv[..., 0][dark] = 128

    mask = cv2.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
    mask2 = cv2.inRange(hsv[..., 0], np.array((180 - margin)), np.array((180)))

    mask = cv2.bitwise_or(mask, mask2)

    return [mask, hsv[..., 0]]




def get_fg_from_hue_watershed(img, margin):                     ## 分水岭算法
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    dark = hsv[..., 2] < 32
    hsv[..., 0][dark] = 128

    mask = cv2.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
    mask2 = cv2.inRange(hsv[..., 0], np.array((180 - margin)), np.array((180)))

    mask = cv2.bitwise_or(mask, mask2)

    mask_bg = cv2.inRange(hsv[..., 0], 60, 90)

    markers = np.zeros(mask.shape, np.int32)
    markers[mask == 255] = 1
    markers[mask_bg == 255] = 2

    cv2.watershed(img, markers)

    mask[markers == 1] = 255

    return [mask, hsv[..., 0]]


def colorsection(frame):                                        #颜色阈值
    for (lower, upper) in color:
        lower = np.array(lower, dtype="uint8")
        upper = np.array(upper, dtype="uint8")
        mask = cv2.inRange(frame, lower, upper)
        output = cv2.bitwise_and(frame, frame, mask=mask)
    gray = cv2.cvtColor(output, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edged = cv2.Canny(blurred, 40, 200, apertureSize=3)
    ret, thresh = cv2.threshold(blurred, 50, 255, cv2.THRESH_BINARY)

    return thresh

########################################################################



###################### 判断函数 ######################################

def distance_to_camera(width, forcal, perwidth):                # 距离计算
    return (width * forcal) / perwidth



def feasibility(marker):                                        # 判断宽高比可行性可行性判断，当宽高比大于0.7则可行
    if marker[1][0] / (marker[1][1]+1) > 0.7:
        return 1
    else:
        return 0


def stability(aff_value):                                           #判断稳定性函数 1:不稳定,2:稳定
    if (aff_value[0] > cen_x_th_value1 or aff_value[1] > cen_y_th_value1 or
            aff_value[2] > width_th_value1 or aff_value[3] > higth_th_value1
            or aff_value[4] > angle_th_value1):
        return 1

    if (aff_value[0] < cen_x_th_value and aff_value[1] < cen_y_th_value and
            aff_value[2] < width_th_value and aff_value[3] < higth_th_value and
            aff_value[4] < angle_th_value and feasibility(marker)):
        return 2
    else:
        return 0


def affirm_var(markerdata1):                                    # 过去4帧，现在1一帧的最小矩形中点位置，长度，宽度，角度的方差
    cen_x = []
    cen_y = []
    width = []
    higth = []
    angle = []
    for i in range(5):
        cen_x.append(markerdata1[i][0][0])
        cen_y.append(markerdata1[i][0][1])
        width.append(markerdata1[i][1][0])
        higth.append(markerdata1[i][1][1])
        angle.append(markerdata1[i][2])
    var_cen_x = np.var(cen_x)
    var_cen_y = np.var(cen_y)
    var_width = np.var(width)
    var_higth = np.var(higth)
    var_angle = np.var(angle)
    affirm_var = [var_cen_x, var_cen_y, var_width, var_higth, var_angle]
    # 返回当前状态，x,y坐标，宽度，高度，角度方差
    return affirm_var


def position_row(X_center):                                     # 水平方向偏离中心距离
    offset_row = X_center - 320
    return offset_row


def position_column(Y_center):                                  # 竖直方向偏离中心距离
    offset_column = Y_center - 240
    return offset_column


############################################################################



############################ 操作函数 #######################################


def show_img(img):
    cv2.imshow("temp", img)
    k = cv.waitKey(0)
    if k == 27:
        sys.exit()

def contour_info(img, area, aspect_ratio, extent, solidity, angle1, angle2, ellipse):
    color = (255,0,255)
    msg = "area %f; aspect %f; extent %f" % (area, aspect_ratio, extent)
    cv2.putText(img, msg, (10, 30), font, 0.7, color)
    msg = "solidity %f; angle1 %f; angle2 %f" % (solidity, angle1, angle2)
    cv2.putText(img, msg, (10, 80), font, 0.7, color)
    cv2.ellipse(img, ellipse, (0, 255, 0), 2)



def guide_line_detect(img, area_th=15000, aspect_th=0.8):
    '''
    TODO：部分时候很靠近边框时，会检测到框
    :param img:
    :param area_th:
    :param aspect_th:
    :return:
    '''
    ASPECT_RATIO_MIN = 0.2 #重要参数
    MAX_CONTOUR_NUM = 6 #如果出现更多的轮廓，不进行处理。这是为了对抗白平衡

    mask, _ = get_fg_from_hue_watershed(img, 20)
    _, contours, hierarchy = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # 目前对自动白平衡的处理，太多轮廓则直接返回
    candidates = []
    candidates_y = []
    if len(contours) < MAX_CONTOUR_NUM:
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > area_th:  # 关键参数
                (x1, y1), (w1, h1), angle1 = cv2.minAreaRect(cnt)
                minAreaRect_area = w1 * h1
                aspect_ratio = float(w1) / h1
                if aspect_ratio > 1:
                    aspect_ratio = 1.0 / aspect_ratio
                    angle1 = np.mod(angle1 + 90, 180)

                extent = float(area) / minAreaRect_area

                hull = cv2.convexHull(cnt)
                hull_area = cv2.contourArea(hull)
                solidity = float(area) / hull_area

                (x2, y2), (MA, ma), angle2 = cv2.fitEllipse(cnt)
                if angle2 > 90:
                    angle2 -= 180

                if aspect_ratio > aspect_th or aspect_ratio < ASPECT_RATIO_MIN  or extent < 0.7 or solidity < 0.7 or abs(angle1-angle2)>30:
                    break

                logging.debug('area %f,aspect_ratio %f,extent %f,solidity %f,angle1 %f,angle2 %f' % (area, aspect_ratio, extent, solidity, angle1, angle2))

                # img2 = img.copy()
                # contour_info(img2,area,aspect_ratio,extent,solidity,angle1,angle2,((x2, y2), (MA, ma), angle2))
                # cv.drawContours(img2, [cnt], 0, (0, 255, 0), 3)
                # show_img(img2)

                candidates.append((x1,y1,angle2))  #目前这个组合是比较好的。
                candidates_y.append(y1)

        nc = len(candidates)
        if nc == 0:
            return None
        elif nc == 1:
            return candidates[0]
        else:
            logging.debug('multiple')

            idx = np.argmax(np.array(candidates_y))
            return candidates[idx]


def show_huv(event,x,y,flags,param):
    if event == cv2.EVENT_MOUSEMOVE:
        global mask

        mask_=mask.copy()
        cv2.putText(mask_,str(hsv[y,x,1]),(100,100),font,1.0, (128, 0, 255))
        cv2.imshow("Video",mask_)





def classify_column(lines2):                                     # 筛选竖线(扩展用)
    line_theta = []
    ver_line = []
    line_theta = lines2
    for j in range(len(lines2)):
        if line_theta[j][1] < 0.79 and line_theta[j][1] > (-0.79):
            # ver_line[j] = line_theta[j]
            ver_line.append(line_theta[j])
    return ver_line


def bubbleSort_column(lines2):                                   #直线排序（扩展）
    ver_line = classify_column(lines2)
    for i in range(len(ver_line) - 1):
        for j in range(len(ver_line) - i - 1):
            if ver_line[j][0] > ver_line[j + 1][0]:
                ver_line[j], ver_line[j + 1] = ver_line[j + 1], ver_line[j]
    return ver_line

def linepoint(lines2):
    lines = distingish_column(lines2)
    for rho1, theta1 in lines[:]:
        a1 = np.cos(theta1)
        x = a1 * rho1
    return x


def distingish_column(lines2):                                  # 筛选出竖线（扩展）
    line_ver = bubbleSort_column(lines2)
    section_line_ver = []
    if len(line_ver) == 0:
        return section_line_ver
    for i in range(len(line_ver) - 1):
        if line_ver[i + 1][0] - line_ver[i][0] > 30:
            section_line_ver.append(line_ver[i])
    section_line_ver.append(line_ver[len(line_ver) - 1])

    return section_line_ver



def Houghlines(frame):
    thresh = modelsection(3,frame)
    lines = cv2.HoughLines(thresh, 1, np.pi / 180, tmp)
    if not(lines==None):
        lines1 = lines[:, 0, :]
        line_num = len(lines1)
    # if len(lines1) < 25:
    #     for g in range(len(lines1)):
    #         if lines1[g][0]<0:
    #             lines2[g][0] = abs(lines1[g][0])
    #             lines2[g][1] = lines1[g][1]-3.14
    #
    # for rho1, theta1 in lines3[:]:
    #     a1 = np.cos(theta1)
    #     b1 = np.sin(theta1)
    #     x01 = a1 * rho1
    #     y01 = b1 * rho1
    #     x__ = int(x01 + 1000 * (-b1))
    #     y__ = int(y01 + 1000 * (a1))
    #     x__1 = int(x01 - 1000 * (-b1))
    #     y__1 = int(y01 - 1000 * (a1))
    if lines==None:
        return 2

    if line_num<4:
        return 2
    else:
        return 0





def Some_name(thresh):                                          #最大矩形中心，矩中心计算
    global frame_count
    aff_value = [count_sb,count_sb,count_sb,count_sb,count_sb]
    # 边缘检测，寻找最小外接矩形
    cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[1]
    cnts0 = cv2.findContours(thresh.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    cnts0 = cnts0[1]
    if not (cnts0 == []):
        c = max(cnts0, key=cv2.contourArea)
        marker = cv2.minAreaRect(c)  # 得到最小外接矩形（中心(x,y),（宽，高），选住角度）

        inches = distance_to_camera(Know_Width, forcal,marker[1][0] + 1)  # 对象距离
        box = cv2.boxPoints(marker)  # 获取最小外接矩形的四个顶点
        box = np.int0(box)
        cv2.drawContours(frame, [box], -1, (0, 255, 0), 2)
        cv2.putText(frame, "%.2fft" % (inches / 12), (frame.shape[1] - 200, frame.shape[0] - 20),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    2.0, (0, 255, 0), 3)

        if not (c == []):
            # 边缘检测的轮廓中心
            for c_ in cnts:
                M = cv2.moments(c_)  # 求图形的矩
                cX = int((M["m10"] + 1) / (M["m00"] + 1))
                cY = int((M["m01"] + 1) / (M["m00"] + 1))
                cv2.drawContours(frame, [c_], -1, (0, 255, 0), 2)
            cv2.circle(frame, (cX, cY), 7, (255, 255, 255), -1)
            cv2.putText(frame, "center", (cX - 20, cY - 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

        markerdata[frame_count] = marker    # 将最小外接矩形数据存放到一个二维列表
        frame_count = frame_count + 1       # 计数
        if frame_count == 5:                # 计数为5时，再次清零
            frame_count = 0

        if not (markerdata[4] == []):       # 当markerdata的内容有五个数据（也就是存放了历史4帧以及现在1帧的数据）
            markerdata1 = markerdata        # markerdata数据传递给markerdata1，用于以上affirm_var函数，circilepoint函数做形式参数
            aff_value = affirm_var(markerdata1)

        return marker ,aff_value,cX,cY



def circlepoint(markerdata1):               # 计算最小矩形中心位置，距离画面中点位置距离
    cen_x, cen_y = markerdata1[0]
    dis_x = cen_x - 270
    dis_y = cen_y - 480
    distance = math.sqrt(dis_x * dis_x + dis_y * dis_y)
    return distance


def cross_aim(frame):                       #十字法
    xd,yd=0,0
    cv2.boxFilter(frame, -1, (5, 5), frame)
    thresh,_ret = get_fg_from_hue(frame, 20)

    face1 = thresh[220:260, 0:640]
    frame1 = frame[220:260, 0:640]
    face2 = thresh[0:480, 300:340]
    frame2 = frame[0:480, 300:340]

    face3 = thresh[0:239, 300:340]
    frame3 = frame[0:239, 300:340]
    face4 = thresh[220:260, 0:319]
    frame4 = frame[220:260, 0:319]
    face5 = thresh[220:480, 300:340]
    frame5 = frame[220:480, 300:340]
    face6 = thresh[220:260, 320:640]
    frame6 = frame[220:260, 320:640]

    cnts1 = cv2.findContours(face1.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts1 = cnts1[1]
    cnts2 = cv2.findContours(face2.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts2 = cnts2[1]

    cnts3 = cv2.findContours(face3.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts3 = cnts3[1]
    cnts4 = cv2.findContours(face4.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts4 = cnts4[1]
    cnts5 = cv2.findContours(face5.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts5 = cnts5[1]
    cnts6 = cv2.findContours(face6.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts6 = cnts6[1]

    for c1 in cnts1:
        M1 = cv2.moments(c1)
        cX1 = int((M1["m10"] + 1) / (M1["m00"] + 1))
        cY1 = int((M1["m01"] + 1) / (M1["m00"] + 1))
        cv2.drawContours(frame1, [c1], -1, (0, 255, 0), 2)
        # cv2.circle(frame, (cX1, cY1), 7, (255, 0, 0), -1)

    if not (cnts4 == []):
        c44 = max(cnts4, key=cv2.contourArea)
        marker44 = cv2.minAreaRect(c44)
        box44 = cv2.boxPoints(marker44)
        box44 = np.int0(box44)
        cv2.drawContours(frame, [box44], -1, (0, 255, 0), 2)
    if not (cnts6 == []):
        c66 = max(cnts6, key=cv2.contourArea)
        marker66 = cv2.minAreaRect(c66)
        box66 = cv2.boxPoints(marker66)
        box66 = np.int0(box66)
        cv2.drawContours(frame, [box66], -1, (0, 255, 0), 2)

        if not (cnts4 == []) and not (cnts6 == []):
            X_center = int((marker44[0][0] + marker66[0][0] + 320) / 2)
            xd = position_row(X_center)
            k1 = 1
            cv2.circle(frame, (int((marker44[0][0] + marker66[0][0] + 320) / 2),
                               int((marker44[0][1] + marker66[0][1] + 240) / 2)), 7, (0, 255, 0), 2)
        if cnts4 == [] or cnts6 == []:
            cv2.circle(frame, (cX1, cY1), 7, (255, 0, 0), -1)

    for c2 in cnts2:
        M2 = cv2.moments(c2)
        cX2 = int((M2["m10"] + 1) / (M2["m00"] + 1))
        cY2 = int((M2["m01"] + 1) / (M2["m00"] + 1))
        cv2.drawContours(frame2, [c2], -1, (0, 0, 255), 2)
        # cv2.circle(frame, (cX2, cY2), 7, (0, 0, 255), -1)

        if not (cnts3 == []):
            c33 = max(cnts3, key=cv2.contourArea)
            marker33 = cv2.minAreaRect(c33)
            box33 = cv2.boxPoints(marker33)
            box33 = np.int0(box33)
        # cv2.drawContours(frame,[box33],-1,(0,255,0),2)

        if not (cnts5 == []):
            c55 = max(cnts5, key=cv2.contourArea)
            marker55 = cv2.minAreaRect(c55)
            box55 = cv2.boxPoints(marker55)
            box55 = np.int0(box55)

        # cv2.drawContours(frame,[box55],-1,(0,255,0),2)
        if not (cnts3 == []) and not (cnts5 == []):
            Y_center = int((marker33[0][1] + marker55[0][1] + 240) / 2)
            yd = position_column(Y_center)
            k2 = 1
            cv2.circle(frame, (int((marker33[0][0] + marker55[0][0] + 320) / 2),
                               int((marker33[0][1] + marker55[0][1] + 240) / 2)), 7, (0, 0, 255), 2)

        # if (cnts3 == [] or cnts5 == []) and count_t == 50:
        #     cv2.circle(frame, (cX2, cY2), 7, (255, 0, 0), -1)
        #     if cY2 < 240:
        #         control_orders(4)
        #         print('down')
        #     if cY2 > 240:
        #         control_orders(3)
        #         print('up')
        if (cnts4 == [] or cnts5 == []) and count_y == 50:
            cv2.circle(frame, (cX2, cY2), 7, (255, 0, 0), -1)
            if cX2 < 320:
                control_orders(2)
            if cX2 > 320:
                control_orders(1)

        if xd and yd:
            od = order_accurate(xd, yd)

    # ser1 = serial.Serial(com,9600,timeout = 0.5)
            if od:
                if (count_t == 40):
                    control_orders(od)
    return frame1,frame2


def modelsection(num, frame):               #选择模式（颜色提取，kmeasn聚类,分水岭）
    if num == 1:
        thresh = colorseciton(frame)
    if num == 2:
        thresh = kmeans(frame)
    if num == 3:
        thresh, hue = get_fg_from_hue_watershed(frame, 20)
    return thresh



################################################################


########################## 指令函数 ############################



def control_orders(od_r):                   #向串口发送命令
    if od_r == -1:
        ser.write(b'\xaa\x55\x02\x01\x01')
        print('left1')
    if od_r == -2:
        ser.write(b'\xaa\x55\x02\x02\x01')
        print('left2')
    # if od_r == -3:
    #     ser.write(b'\xaa\x55\x02\x03\x01')
    #     print('up1')
    # if od_r == -4:
    #     ser.write(b'\xaa\x55\x02\x04\x01')
    #     print('down1')
    if od_r == -5:
        ser.write(b'\xaa\x55\x02\x05\x01')
        print('go1')
    if od_r == -6:
        ser.write(b'\xaa\x55\x02\x06\x01')
        print('back1')
    if od_r == 1:
        ser.write(b'\xaa\x55\x02\x01\x02')
        print('left2')
    if od_r == 2:
        ser.write(b'\xaa\x55\x02\x02\x02')
        print('right2')
    # if od_r == 3:
    #     #= ser.write(b'\xaa\x55\x02\x03\x02')
    #     # print('up')
    #  if od_r==4:
    #     # ser.write(b'\xaa\x55\x02\x04\x02')
    #     print('down')
    if od_r == 5:
        ser.write(b'\xaa\x55\x02\x05\x02')
        print('go')
    if od_r == 6:
        ser.write(b'\xaa\x55\x02\x06\x02')
        print('back')
    if od_r == 7:
        ser.write(b'\xaa\x55\x02\x07\x02')
        print('stop')
    if od_r == 8:
        for r in range(10):
            ser.write(b'\xaa\x55\x02\x05\x02')
            time.sleep(0.5)
            print('continue go')


def order_accurate(xd, yd):                     #十字模式调整（较小阈值）
    # od = 7
    # if yd > 30:
    #     od = 4
    # if yd < (-30):
    #     od = 3
    # if (yd < 50) and (yd > (-50)):
    if xd > 50:
        od = -2
    if xd < (-50):
        od = -1
    if xd < 50 and xd > (-50):
        od = 5

    return od


def order_remote(xd, yd):                   #较远调整（较大阈值）
    od = 7
    # if yd > 30:
    #     od = 4
    # if yd < (-30):
    #     od = 3
    # if (yd < 50) and (yd > (-50)):
    if xd > 50:
        od = -2
    if xd < (-50):
        od = -1
    if xd < 50 and xd > (-50):
        od = 5

    return od

####################################################################


def round1(frame):
    thresh = modelsection(3,frame)
    kernel = np.ones((5, 5), np.float32) / 25
    thresh=cv2.filter2D(thresh,-1,kernel)
    thresh = cv2.GaussianBlur(thresh, (5, 5), 0)
    thresh = cv2.medianBlur(thresh, 5)
    thresh = cv2.bilateralFilter(thresh, 9, 75, 75)

def guideline_round(x,y,x1,y1):
    theta = math.atan((y1-y)/(x1-x))
    if theta<1.57:
        turn = 1
        time =  k*(1.57-theta)
    if theta>1.58:
        turn = 2
        time = k*(theta-1.57)
    if 1.57<theta<1.58:
        turn = 7
        time = None
    return turn,time






############################# 主函数 ################################

if __name__ == "__main__":
    logging.basicConfig(filename='example.log', filemode='w', level=logging.DEBUG)

    # hsv_map = np.zeros((180, 256, 3), np.uint8)
    # h, s = np.indices(hsv_map.shape[:2])
    #     # hsv_map[:, :, 0] = h
    # hsv_map[:, :, 1] = s
    # hsv_map[:, :, 2] = 255
    # hsv_map = cv.cvtColor(hsv_map, cv.COLOR_HSV2BGR)
    # cv.imshow('hsv_map', hsv_map)
    #
    # cv.namedWindow('hist', 1)
    # cv.createTrackbar('scale', 'hist', hist_scale, 32, set_scale)
    vfile = 0
    #vfile = 'C:\\Users\\96317\\Desktop\\OPENCV\\print\\yin1.avi'
    # vfile = 'd:\AOV\gopro161.mp4'
    # vfile = 'd:\AOV\gopro3.mp4'
    #vfile = r"d:\AOV\1531820734.avi"
    # vfile = r"d:\AOV\1531820502.avi"
    # vfile = r"d:\AOV\1531821044.avi"
    # vfile = r"d:\AOV\a6.avi"
    # cap = cv.VideoCapture(sys.argv[1])
    cap = cv2.VideoCapture(vfile)

    cv2.namedWindow("Video")
    cv2.setMouseCallback('Video', show_huv)

    cv2.namedWindow("Video2")





while (1):
    status, img = cap.read()
    ret, frame = cap1.read()                                             #读取视频

    cv2.boxFilter(img, -1, (5, 5), img)
    thresh = modelsection(3, frame)                                     #选择模式
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    while(Houghlines(frame)):
        control_orders(1)
        break
    if not(Some_name(thresh))==None:
        marker,aff_value,cX,cY = Some_name(thresh)                          #最大矩形参数，稳定性方法，矩中心X，矩中心Y
    inches = distance_to_camera(Know_Width, forcal, marker[1][0] + 1)   #距离检测

    mask1, hue = get_fg_from_hue(img, 20)
    t = time.clock() * 1000
    mask2, hue = get_fg_from_hue_watershed(img, 20)
    #print(time.clock() * 1000 - t)
    mask = mask1

    t = time.clock() * 1000
    guide_line = guide_line_detect(img)
    #print(time.clock() * 1000 - t)

    if guide_line:
        x, y, angle = guide_line
        angle = angle / 180 * np.pi
        cv2.line(img, (int(x), int(y)), (int(x + 100 * np.sin(angle)), int(y - 100 * np.cos(angle))), (0, 255, 0), 2)
        x1 = int(x + 100 * np.sin(angle))
        y1 = int(y - 100 * np.cos(angle))


    if stability(aff_value) == 1:                                       #不稳定状态
        if count_z == 40:
            if cX > 350:
                control_orders(-2)
            if cX < 290:
                control_orders(-1)
            # if cY < 210:
            #     control_orders(4)
            # if cY > 270:
            #     control_orders(3)

            # 通过向com1端口传最小外接矩形的中点坐标
    if stability(aff_value) == 2:                                       #稳定状态
        remote_column = position_column(marker[0][1])
        remote_row = position_row(marker[0][0])
        od_r = order_remote(remote_row, remote_column)

        if (count_t == 50):                                             #计帧发送
            control_orders(od_r)

                # 进入对准模式（当inches/小于3.6时）
        if (inches / 12 < distance):                                    #当稳定且距离小于distance，进入十字对准
            frame1,frame2 = cross_aim(frame)

            cv2.imshow("123", frame1)                                   #显示
            cv2.imshow("312", frame2)

    count_t = count_t + 1                                               #计数器
    if count_t > 50:
        count_t = 0
    count_y = count_y + 1
    if count_y > 50:
        count_y = 0
    count_z = count_z + 1
    if count_z > 50:
        count_z = 0

    count_frame = count_frame + 1

    cv2.imshow("img", img)
    cv2.imshow("Video", mask1)
    cv2.imshow("Video2", mask2)
    cv2.imshow("capture", frame)

    od = 0
    cv2.imshow("capture",thresh)
    if cv2.waitKey(10) & 0XFF == ord('q'):
        break

    k = cv2.waitKey(15)

    if k == 32:
        cv.waitKey()
    if k == 27:
        break

cap.release()
cv2.destroyAllWindows()

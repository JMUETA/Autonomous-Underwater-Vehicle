import numpy as np
import cv2
from matplotlib import pyplot as plt

cap = cv2.VideoCapture("C:\\Users\\96317\\Desktop\\OPENCV\\print\\gopro1.mp4")
color = [([80, 68, 80], [150, 130, 140])]


while(1):
    ret,frame = cap.read()
    for (lower,upper) in color:
        lower = np.array(lower,dtype = "uint8")
        upper = np.array(upper,dtype = "uint8")
        mask1 = cv2.inRange(frame,lower,upper)
        output = cv2.bitwise_and(frame,frame,mask=mask1)
    gray = cv2.cvtColor(output, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5,5), 0)
    edged = cv2.Canny(blurred, 40, 200,apertureSize=3)
    ret,thresh = cv2.threshold(blurred, 50, 255, cv2.THRESH_BINARY)



    mask = np.zeros(thresh.shape[:2],np.uint8)
    bgdModel = np.zeros((1,65),np.float64)
    fgdModel = np.zeros((1,65),np.float64)
    rect = (0,300,960,100)#划定区域
    cv2.grabCut(frame,mask,rect,bgdModel,fgdModel,2,cv2.GC_INIT_WITH_RECT)#函数返回值为mask,bgdModel,fgdModel
    mask2 = np.where((mask==2)|(mask==0),0,1).astype('uint8')#0和2做背景

    frame = frame*mask2[:,:,np.newaxis]#使用蒙板来获取前景区域



    cv2.imshow('p',frame)
    if cv2.waitKey(33) & 0XFF==ord('q'):
        break
cap.release()
cv2.destroyAllWindows()

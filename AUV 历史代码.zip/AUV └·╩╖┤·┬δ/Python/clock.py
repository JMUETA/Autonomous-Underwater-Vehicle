import requests
from bs4 import BeautifulSoup
import re
import time

def getHtmlText(url,code='utf-8'):
    try:
        r = requests.get(url)
        r.raise_for_status()
        r.encoding = code
        return r.text
    except:
        return ""

def makeSoup(html):
    soup = BeautifulSoup(html,"html.parser")
    soup1 = soup.find_all('li',attrs={'class':'on'})[1]
    

def print(soup1,html):
    print(soup1.prettify())

def main():
    url = 'http://www.weather.com.cn/weather/101190201.shtml'
    html = getHtmlText(url)

if __name__=='__main__':
    main()

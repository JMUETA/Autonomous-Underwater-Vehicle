import turtle
turtle.pensize(2)
turtle.circle(40)
turtle.circle(80)
turtle.circle(100)

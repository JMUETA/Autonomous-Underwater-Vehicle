from __future__ import print_function
import sys
import logging
import cv2
import numpy as np
import math
import time



def get_fg_from_hue_watershed(img, margin):                     ## 分水岭算法
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    dark = hsv[..., 2] < 32
    hsv[..., 0][dark] = 128

    mask = cv2.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
    mask2 = cv2.inRange(hsv[..., 0], np.array((180 - margin)), np.array((180)))

    mask = cv2.bitwise_or(mask, mask2)

    mask_bg = cv2.inRange(hsv[..., 0], 60, 90)

    markers = np.zeros(mask.shape, np.int32)
    markers[mask == 255] = 1
    markers[mask_bg == 255] = 2

    cv2.watershed(img, markers)

    mask[markers == 1] = 255

    return [mask, hsv[..., 0]]



def modelsection(num, frame):               #选择模式（颜色提取，kmeasn聚类,分水岭）
    if num == 1:
        thresh = colorsection(frame)
    if num == 2:
        thresh = kmeans(frame)
    if num == 3:
        thresh, hue = get_fg_from_hue_watershed(frame, 20)
    return thresh


def guide_line_detect(img, area_th=15000, aspect_th=0.8):
    '''
    TODO：部分时候很靠近边框时，会检测到框
    :param img:
    :param area_th:
    :param aspect_th:
    :return:
    '''
    ASPECT_RATIO_MIN = 0.2 #重要参数
    MAX_CONTOUR_NUM = 6 #如果出现更多的轮廓，不进行处理。这是为了对抗白平衡

    mask, _ = get_fg_from_hue_watershed(img, 20)
    _, contours, hierarchy = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # 目前对自动白平衡的处理，太多轮廓则直接返回
    candidates = []
    candidates_y = []
    if len(contours) < MAX_CONTOUR_NUM:
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > area_th:  # 关键参数
                (x1, y1), (w1, h1), angle1 = cv2.minAreaRect(cnt)
                minAreaRect_area = w1 * h1
                aspect_ratio = float(w1) / h1
                if aspect_ratio > 1:
                    aspect_ratio = 1.0 / aspect_ratio
                    angle1 = np.mod(angle1 + 90, 180)

                extent = float(area) / minAreaRect_area

                hull = cv2.convexHull(cnt)
                hull_area = cv2.contourArea(hull)
                solidity = float(area) / hull_area

                (x2, y2), (MA, ma), angle2 = cv2.fitEllipse(cnt)
                if angle2 > 90:
                    angle2 -= 180

                if aspect_ratio > aspect_th or aspect_ratio < ASPECT_RATIO_MIN  or extent < 0.7 or solidity < 0.7 or abs(angle1-angle2)>30:
                    break

                logging.debug('area %f,aspect_ratio %f,extent %f,solidity %f,angle1 %f,angle2 %f' % (area, aspect_ratio, extent, solidity, angle1, angle2))

                # img2 = img.copy()
                # contour_info(img2,area,aspect_ratio,extent,solidity,angle1,angle2,((x2, y2), (MA, ma), angle2))
                # cv.drawContours(img2, [cnt], 0, (0, 255, 0), 3)
                # show_img(img2)

                candidates.append((x1,y1,angle2))  #目前这个组合是比较好的。
                candidates_y.append(y1)

        nc = len(candidates)
        if nc == 0:
            return None
        elif nc == 1:
            return candidates[0]
        else:
            logging.debug('multiple')

            idx = np.argmax(np.array(candidates_y))
            return candidates[idx]




cap = cv2.VideoCapture("C:\\Users\\96317\\Desktop\\OPENCV\\print\\GOPR1.mp4")
while(1):
    ret,img = cap.read()
    thresh = modelsection(3,img)  
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray,(7,7),0)
    edged = cv2.Canny(blurred,50,150)

    mask = thresh

    #t = time.clock() * 1000
    guide_line = guide_line_detect(img)
    #print(time.clock() * 1000 - t)

    if guide_line:
        x, y, angle = guide_line
        angle = angle / 180 * np.pi
        cv2.line(img, (int(x), int(y)), (int(x + 100 * np.sin(angle)), int(y - 100 * np.cos(angle))), (0, 255, 0), 2)
        x1 = int(x + 100 * np.sin(angle))
        y1 = int(y - 100 * np.cos(angle))

        #print(angle)

    cnts = cv2.findContours(thresh.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[1]

    for c in cnts:
        (x,y,w,h) = cv2.boundingRect(c)
        rdi = w/h<0.7 and w>30 and h>40
        #print(x,y,w,h)
        if rdi:
            cv2.rectangle(img, (x,y), (x+w,y+h), (0,255,0), 2)


    
    for c in cnts:
        peri = cv2.arcLength(c,True)
        approx = cv2.approxPolyDP(c,0.01*peri,True)
        if len(approx)>=4 and len(approx)<=6:
            (x,y,w,h) = cv2.boundingRect(approx)
            aspcetRatio = w/float(h)
            area = cv2.contourArea(c)
            hullArea = cv2.contourArea(cv2.convexHull(c))
            solidity = area/float(hullArea)
            keepDims = w>20 and h>60
            keepSolidity = solidity<0.7
            #if keepDims and keepSolidity:
            cv2.drawContours(img,[approx],-1,(0,255,0),4)
            
        

    cv2.imshow("a",img)
    if cv2.waitKey(10) & 0XFF == ord('q'):
        break

cv2.destroyAllWindows()

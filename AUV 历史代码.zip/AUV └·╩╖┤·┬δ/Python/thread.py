import threading
import serial

def thread_job():
    ser = serial.Serial("COM5",9600,timeout = 0.1)
    ser.write(1)
    print("1")


def main():
    add_thread = threading.Thread(target = thread_job)
    add_thread.start()


if __name__=='__main__':
    main()


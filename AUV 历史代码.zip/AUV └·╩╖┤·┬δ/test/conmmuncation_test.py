import serial

#串口通信接口            2019版
portx = '/dev/ttyUSB0'
bps = 115200
timex = 0.01
ser = serial.Serial(portx, bps, timeout=timex)

od_r = 'stop'

head = [0xaa, 0x55, 0x10]
depth_lock_bit = [0x01]
dir_lock_bit = [0x01]
forword_back_bit = [0x00]
left_right_bit = [0x00]
up_down_bit = [0x00]
rotation_bit = [0x00]
power_value = [0x00]
other_bit = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
start_stop_bit = [0x00]

# if od_r == 'left':
#     dir_lock_bit[0] = 0x02
#     Left_control_bit[0] = 0x80
#     Right_control_bit[0] = 0xb2
#     start_stop_bit[0] = 0x01
#     dl = -0.1                              #右旋浆前进0.1m
#     dr = 0.1
#     print('left')
# if od_r == 'right':
#     dir_lock_bit[0] = 0x02
#     Right_control_bit[0] = 0x80
#     Left_control_bit[0] = 0xb2
#     start_stop_bit[0] = 0x01
#     dl = 0.1                              #左旋浆前进0.1m
#     dr = -0.1
#     print('right')
# if od_r == 'left_translation':                               # 左平移
#     dir_lock_bit[0] = 0x02
#     Right_control_bit[0] = 0x80
#     Left_control_bit[0] = 0xb2
#     start_stop_bit[0] = 0x01                              #参数待修改
#     AUV_dx = -0.2
#     print('left_translation')
# if od_r == 'right_translation':                              #右平移
#     dir_lock_bit[0] = 0x02
#     Right_control_bit[0] = 0x80
#     Left_control_bit[0] = 0xb2
#     start_stop_bit[0] = 0x01                              #参数待修改
#     AUV_dx = 0.2
#     print('right_translation')
# if od_r == 'left_rotation':                              #左旋转
#     dir_lock_bit[0] = 0x02
#     start_stop_bit[0] = 0x01                              #参数待修改
#     print('left_rotation')
# if od_r == 'right_rotation':                              #右旋转
#     dir_lock_bit[0] = 0x02
#     start_stop_bit[0] = 0x01                              #参数待修改
#     print('right_rotation')
if od_r == 'go':
    dir_lock_bit = [0x02]
    forword_back_bit = [0x01]
    start_stop_bit = [0x01]
    dl = 0.2                            #前进0.2m
    dr = 0.2
    print('go')
if od_r == 'up':
    depth_lock_bit = [0x02]
    up_down_bit = [0x02]
    start_stop_bit = [0x01]
    print('up')
# if od_r == 'down':
#     depth_lock_bit[0] = 0x02
#     depth_motion_bit[0] = 0x02
#     start_stop_bit[0] = 0x01
#     print('down')
if od_r == 'stop':
    start_stop_bit = [0x00]
    dl = 0
    dr = 0
    print('stop')
# if od_r == 'back':
#     Left_control_bit[0] = 0x4e
#     Right_control_bit[0] = 0x4e
#     start_stop_bit[0] = 0x01
#     print('back')

parameter = head + depth_lock_bit + dir_lock_bit + forword_back_bit + left_right_bit + up_down_bit + rotation_bit + power_value + other_bit + start_stop_bit
check_sum = sum(parameter)
check_sum = [check_sum & 255]



msg = parameter + check_sum
msg = bytearray(msg)
try:                                          #发送串口指令 与单片机通信
    ser.write(msg)
except Exception as e:
    print("--异常--:", e)

# return dl,dr,AUV_dx,AUV_dy
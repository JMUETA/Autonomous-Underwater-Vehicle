from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2
import logging
import sys
import numpy as np
import serial
import threading


FORCAL = 600                                            #距离函数设定的焦距，为定值
Know_Distance = 30.0                                    # 已知距离（定值）
Know_Width = 25.2

data_count = 0                      #框信任度，存储历史数据的计数器
cX_container = []
minAreax_container = []

x0 = [0]
y0 = [0]
theta0 = [1.57]
#auv_local = [x0,y0,theta0]

Rect_point = []
Line_point = []

b = 0.5     #AUV宽度
dl = 0
dr = 0

AUV_dx = 0

dx = 0
dy = 0

Count=0
Count1 = 0
K_COUNT=0
X_COUNT=0


corss_Rect_flag = 0

color = [([0, 50, 60], [255, 150, 150])]         #待调节

Trunum = None
Tarnum = 2

action_count = 0
# dx1 = [0]

# portx = '/dev/ttyUSB0'
# bps = 9600
# timex = 0.01
# ser = serial.Serial(portx, bps, timeout=timex)
#
# portx1 = '/dev/ttyUSB2'
# bps1 = 115200
# ser1 = serial.Serial(portx1, bps1, timeout=timex)

def get_fg_from_hue_watershed_saturation(img, margin):
    mask, hue = get_fg_from_hue(img, margin)

    mask_bg = cv2.inRange(hue, 60, 90)
    mask_bg = cv2.bitwise_or(mask_bg, cv2.inRange(hue,128,129))

    markers = np.zeros(mask.shape, np.int32)
    markers[mask == 255] = 1
    markers[mask_bg == 255] = 2

    cv2.watershed(img, markers)
    mask[markers == 1] = 255

    # img2 = img.copy()
    # img2[markers == 1] = 255
    # cv.imshow("1", img2)
    #
    # img2 = img.copy()
    # img2[markers == 2] = 255
    # cv.imshow("2", img2)
    #
    # img2 = img.copy()
    # img2[markers == -1] = 255
    # cv.imshow("3", img2)

    return mask


def get_fg_from_hue(img, margin):
    FRACTION_AS_BLANK = 0.003
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    dark = hsv[..., 2] < 32
    hsv[..., 0][dark] = 128

    dark = hsv[..., 1] < 50
    hsv[..., 0][dark] = 128

    mask = cv2.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
    mask2 = cv2.inRange(hsv[..., 0], np.array((180-margin)), np.array((180)))

    mask = cv2.bitwise_or(mask, mask2)

    if cv2.countNonZero(mask) < mask.shape[0]*mask.shape[1]*FRACTION_AS_BLANK:
        mask.fill(0)

    return [mask, hsv[...,0]]



def guide_line_detect(mask, area_th=5000, aspect_th=0.8):
    '''

    TODO：部分时候很靠近边框时，会检测到框
    :param img:
    :param area_th:
    :param aspect_th:
    :return:
    '''
    ASPECT_RATIO_MIN = 0.15 #重要参数
    MAX_CONTOUR_NUM = 6 #如果出现更多的轮廓，不进行处理。这是为了对抗白平衡

    _, contours, hierarchy = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # 目前对自动白平衡的处理，太多轮廓则直接返回
    candidates = []
    candidates_y = []
    if len(contours) < MAX_CONTOUR_NUM:
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > area_th:  # 关键参数
                (x1, y1), (w1, h1), angle1 = cv2.minAreaRect(cnt)
                minAreaRect_area = w1 * h1
                aspect_ratio = float(w1) / h1
                if aspect_ratio > 1:
                    aspect_ratio = 1.0 / aspect_ratio
                    angle1 = np.mod(angle1 + 90, 180)

                extent = float(area) / minAreaRect_area

                hull = cv2.convexHull(cnt)
                hull_area = cv2.contourArea(hull)
                solidity = float(area) / hull_area

                (x2, y2), (MA, ma), angle2 = cv2.fitEllipse(cnt)
                if angle2 > 90:
                    angle2 -= 180

                logging.debug('area %f,aspect_ratio %f,extent %f,solidity %f,angle1 %f,angle2 %f' % (area, aspect_ratio, extent, solidity, angle1, angle2))

                if aspect_ratio > aspect_th or aspect_ratio < ASPECT_RATIO_MIN  or extent < 0.7 or solidity < 0.7 or abs(angle1-angle2)>30:
                    break


                # img2 = img.copy()
                # contour_info(img2,area,aspect_ratio,extent,solidity,angle1,angle2,((x2, y2), (MA, ma), angle2))
                # cv.drawContours(img2, [cnt], 0, (0, 255, 0), 3)
                # show_img(img2)

                candidates.append((x1,y1,angle2))                       #目前这个组合是比较好的。
                candidates_y.append(y1)

        nc = len(candidates)
        if nc == 0:
            return None
        elif nc == 1:
            return candidates[0]
        else:
            logging.debug('multiple')

            idx = np.argmax(np.array(candidates_y))
            return candidates[idx]


def distance_to_camera(width, forcal, perwidth):                # 距离计算
    return ((width * forcal)*0.3048) / (12*perwidth)



def att_angle():
    try:
        att = ser1.read(5)
        if len(att)>5:
            return att[3]
    except Exception as e:
        print("--异常--:", e)
    return 90

def angle2rad(theta):
    w = (theta*np.pi)/180
    return w

def control_AUV(od_r,dis=1):
    global dl
    global dr
    global dtheta
    head = [0xaa,0x55,0x10]
    depth_lock_bit = [0x01]
    dir_lock_bit = [0x01]
    Left_control_bit = [0x80]
    Right_control_bit = [0x80]
    depth_motion_bit = [0x00]
    dir_motion_bit = [0x00]
    power_value = [0x00]
    other_bit = [0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00]
    start_stop_bit = [0x00]

    if od_r == '1eft':
        dir_lock_bit[0] = 0x02
        Left_control_bit[0] = 0x80
        Right_control_bit[0] = 0xb2
        start_stop_bit[0] = 0x01
        dtheta = 0.78
        print('left')
    if od_r == 'right':
        dir_lock_bit[0] = 0x02
        Right_control_bit[0] = 0x80
        Left_control_bit[0] = 0xb2
        start_stop_bit[0] = 0x01
        dtheta = -0.78
        print('right')
    if od_r == 'left_translation':                               # 左平移
        dir_lock_bit[0] = 0x02
        Right_control_bit[0] = 0x80
        Left_control_bit[0] = 0xb2
        start_stop_bit[0] = 0x01                              #参数待修改
        dl = 0
        dr = 0.1
        print('left_translation')
    if od_r == 'right_translation':                              #右平移
        dir_lock_bit[0] = 0x02
        Right_control_bit[0] = 0x80
        Left_control_bit[0] = 0xb2
        start_stop_bit[0] = 0x01                              #参数待修改
        dl = 0.1
        dr = 0
        print('right_translation')
    if od_r == 'go':
        dir_lock_bit[0] = 0x02
        Left_control_bit[0] = 0xb2
        Right_control_bit[0] = 0xb2
        start_stop_bit[0] = 0x01
        dl = 0.2                            #前进0.2m
        dr = 0.2
        print('go')
    if od_r == 'up':
        depth_lock_bit[0] = 0x02
        depth_motion_bit[0] = 0x01
        start_stop_bit[0] = 0x01
        print('up')
    if od_r == 'down':
        depth_lock_bit[0] = 0x02
        depth_motion_bit[0] = 0x02
        start_stop_bit[0] = 0x01
        print('down')
    if od_r == 'stop':
        Left_control_bit[0] = 0x80
        Right_control_bit[0] = 0x80
        start_stop_bit[0] = 0x02
        dl = 0
        dr = 0
        print('stop')
    if od_r == 'back':
        Left_control_bit[0] = 0x4e
        Right_control_bit[0] = 0x4e
        start_stop_bit[0] = 0x01
        dl = -0.1
        dr = -0.1
        print('back')

    parameter = depth_lock_bit + dir_lock_bit + Left_control_bit + Right_control_bit + depth_motion_bit\
                + dir_motion_bit + power_value + other_bit + start_stop_bit
    check_sum = sum(parameter)
    check_sum = [check_sum & 255]

    msg = head + parameter + check_sum
    msg = bytearray(msg)
    try:                                          #发送串口指令 与单片机通信
        portx = '/dev/ttyUSB0'
        bps = 9600
        timex = 0.01
        ser = serial.Serial(portx, bps, timeout=timex)
        ser.write(msg)
        ser.close()
    except Exception as e:
        print("--异常--:", e)

    return dl,dr,dtheta,AUV_dx

# def control_AUV(od_r):
#     if od_r == 'left':
#         #ser.write(b'\xaa\x55\x02\x01\x02')
#         print('left')
#     if od_r == 'right':
#         #ser.write(b'\xaa\x55\x02\x02\x02')
#         print('right')
#     if od_r == 'up':
#         #ser.write(b'\xaa\x55\x02\x03\x02')
#         print('up')
#     if od_r == 'down':
#         #ser.write(b'\xaa\x55\x02\x04\x02')
#         print('down')
#     if od_r == 'go':
#         #ser.write(b'\xaa\x55\x02\x05\x02')
#         print('go')
#     if od_r == 'back':                        #或存在问题
#         #ser.write(b'\xaa\x55\x02\x06\x02')
#         print('back')
#     if od_r == 'stop':
#         #ser.write(b'\xaa\x55\x02\x07\x02')
#         print('stop')


def guide_line_turn(angle):                                  #判断识别到引导线时转向函数
    if (-0.4 < angle) and angle < 0.4:
        control_AUV('go')
    elif angle < -0.4:
        control_AUV('left')
    elif angle > 0.4:
        control_AUV('right')

# def rect_turn(dx):                                                #信任框之后就直接进入过框模式，无需先进行转向
#     rect_dx = dx[-1]+0.5*(dx[-2]+dx[-3])
#     if dx[-1]>160:
#         control_AUV('left')
#     elif dx[-1]<-160:
#         control_AUV('right')
#     else:
#         control_AUV('go')


def add_judege(X,Y):
    now_point = [X,Y]
    itertime = len(Rect_point)
    if itertime<1:
        return True
    for i in range(itertime):
        dis = np.sqrt(np.sum(np.square(Rect_point[i] - now_point)))
        if dis<1:
            return False
    return True


def Add_Rect_point(auv_local,metre,yaw,cX,Rect_width):              #添加框的坐标，暂时还没用上
    bias = (0.6*(cX-160))/Rect_width
    X = auv_local[0] + metre*np.cos(yaw) + bias
    Y = auv_local[1] + metre*np.sin(yaw)
    flag = add_judege(X,Y)
    now_point = [X,Y]
    if flag:
        Rect_point.append(now_point)

def Add_Line_point(auv_local):                                     #添加线的坐标，暂时还没用上
    X = auv_local[-1][0]
    Y = auv_local[-1][1]
    flag = add_judege(X,Y)
    now_point = [X,Y]
    if flag:
        Line_point.append(now_point)



def Camera_switch(frame,Tarnum, Trunum):                              #摄像头切换
    global Count1
    Count1 = Count1 + 1
    if Tarnum == 0 and Trunum == True:                           #过框时保持打开前置摄像头
        frame = frame.array
        Camnum = 0
    else:                                                       #其他时候摄像头一直切换
        if Count1 <= 30:
            frame = frame.array
            Camnum = 0
        else:
            ret,frame = cap.read()
            Camnum = 1
    if Count1 > 60:                                             #1-30帧为前置摄像头，31-60为下置摄像头
        Count1 = 0
    return Camnum,frame


def Frame_Preprocess(Camnum, frame):
    for (lower,upper) in color:
        lower = np.array(lower,dtype = "uint8")
        upper = np.array(upper,dtype = "uint8")
        mask = cv2.inRange(frame,lower,upper)
        mask = cv2.bitwise_not(mask)
        output = cv2.bitwise_and(frame,frame,mask=mask)
    if Camnum == 0:
        Franum = 0
        thresh = get_fg_from_hue_watershed_saturation(output, 20)
        thresh = cv2.medianBlur(thresh, 5)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))  # 形态学开运算，简单滤除离框较远的干扰
        thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    elif Camnum == 1:
        Franum = 1
        cv2.boxFilter(frame, -1, (5, 5), frame)
        thresh = get_fg_from_hue_watershed_saturation(frame, 20)
    return Franum, thresh

def Target_recognition(Franum,thresh,frame):
    global cX
    Tarnum = 2
    data = None
    if Franum == 0:
        cnts2 = []
        _, cnts3, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)  # findContours寻找轮廓
        for cnt in cnts3:
            area = cv2.contourArea(cnt)
            if area > 15000:
                cnts2.append(cnt)
        if not (cnts2 == []):
            for c_3 in cnts2:
                M = cv2.moments(c_3)  # 求图形的矩
                cX = int((M["m10"] + 1) / (M["m00"] + 1))
                cY = int((M["m01"] + 1) / (M["m00"] + 1))

        if not (cnts2 == []):
            c = max(cnts2, key=cv2.contourArea)
            marker = cv2.minAreaRect(c)  # 得到最小外接矩形（中心(x,y),（宽，高），选住角度）
            metre = distance_to_camera(Know_Width, FORCAL, marker[1][0] + 1)  # 距离摄像头距离
            box = cv2.boxPoints(marker)  # 获取最小外接矩形的四个顶点
            box = np.int0(box)
            cv2.drawContours(frame, [box], -1, (0, 255, 0), 2)
            cv2.putText(frame, "%.2fm" % (metre), (frame.shape[1] - 200, frame.shape[0] - 20),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        2.0, (0, 255, 0), 3)
            Tarnum = 0
            data = [cX,marker,metre]
            return Tarnum,data,frame

    elif Franum == 1:
        guide_line = guide_line_detect(thresh)  # 检测下置摄像头是否读到引导线
        if guide_line:
            # 发现引导线，停一下
            x, y, angle = guide_line
            angle = angle / 180 * np.pi
            cv2.line(frame, (int(x), int(y)), (int(x + 100 * np.sin(angle)), int(y - 100 * np.cos(angle))),
                     (0, 255, 0), 2)
            x1 = int(x + 100 * np.sin(angle))
            y1 = int(y - 100 * np.cos(angle))
            Tarnum = 1
            data = [x1,y1,angle]
            return Tarnum,data,frame
    return Tarnum,data,frame


def Trust_choose(Tarnum,data):
    global Trunum
    global Count
    if Tarnum == 0:
        Trunum = Rect_Trust(data)
        if Trunum == 0:                          #不信任框，则进入无目标信任度
            Trunum = Estate(Tarnum)
    elif Tarnum == 1:
        Count = 0
        Trunum = True
    elif Tarnum == 2:
        Trunum = Estate(Tarnum)
    return Trunum


def Rect_Trust(data):
    cX = data[0]
    marker = data[1]
    minArea_x = marker[0][0]
    cX_container.append(cX)
    minAreax_container.append(marker[1][0])
    if cX-minArea_x>50:
        return 0
    if len(cX_container)>=5 and len(minAreax_container)>=5:
        var_cX = np.var(cX_container)
        var_min = np.var(minAreax_container)
        # cv2.putText(frame, "%.2f" % (var_cX), (frame.shape[1] - 200, frame.shape[0] - 20),
        #             cv2.FONT_HERSHEY_SIMPLEX,
        #             2.0, (0, 255, 0), 3)
        if var_cX<40000 and var_min<40000:                                 #方差，待测量
            return 1
        else:
            return 0
    return 2


def Estate(flag):  # 无目标信任度
    global Count
    global C_L_COUNT
    global Est
    global Tarnum
    Count = Count + 1
    if flag == 0:  # 不信任框
        Est = 1
    if flag == 2:  # 无框 无线
        Est = 2
    if flag == 1:  # 有线
        Est = 3

    if Est == 2:
        C_L_COUNT = C_L_COUNT + 1  # 无框则加一
    if Est == 1:
        C_L_COUNT = C_L_COUNT + 1

    if Count == 10:
        if C_L_COUNT >= 10:
            Tarnum = 2
            return True
        Count = 0
        C_L_COUNT = 0  # 10次后清零

    elif Count < 10:
        return 0


def Decision(Tarnum, Trunum,data,frame):
    angle = 0
    x = y0[-1]
    y = x0[-1]
    theta = theta0[-1]
    if Tarnum == 2 and Trunum:
        Order = search(theta, x, y)
        control_AUV(Order)
    if Tarnum == 0 and Trunum:  # 信任框之后的一段时间内运行过框模式
        if action_count >= 0 and action_count <= 15:
            action(AUV_dx,AUV_dtheta)
            control_AUV(od_r)
        else:
            corss_Rect(frame)
    if Tarnum == 1 and Trunum:  # 信任线之后，跟随线转头，直到打开前置摄像头，识别框
        if not (data == None):
            angle = data[2]
        guide_line_turn(angle)


def Odometer(od_r,dl,dr,dtheta):                   #里程表
    global dx
    global dy
    x = x0[-1]
    y = y0[-1]
    theta = theta0[-1]
    if od_r == 'left' or od_r == 'right':
        dx = 0
        dy = 0
    if od_r == 'go' or od_r == 'stop' or od_r == 'back':
        dx = (dr + dl) * np.cos(theta + (dr - dl) / 2 * b) / 2
        dy = (dr + dl) * np.sin(theta + (dr - dl) / 2 * b) / 2
        dtheta = (dr-dl)/b
    if od_r == 'left_translation' or od_r == 'right_translation':
        dx = (dl-dr) * np.sin(theta)
        dy = (dr-dl) * np.cos(theta)
        dtheta = 0
    x1 = x + dx
    y1 = y + dy
    theta1 = theta + dtheta
    x0.append(x1)
    y0.append(y1)
    theta0.append(theta1)
    return 0



def search(theta, x0, y0):
    global x1
    global x2
    global y1
    global y2
    global SR
    global SL
    k = np.tan(theta0[-1])
    b1 = y0[-1] - k * x0[-1]

    Wide = 3.66
    Long = 7.3

    if np.cos(theta) == 1:                      #k=0的情况
        if b1 >= 0 and b1 < Long*0.5:
            return 'left'
        if b1 >= Long*0.5 and b1 <= Long:
            return 'right'
    if np.cos(theta) == -1:
        if b1 >= 0 and b1 < Long*0.5:
            return 'right'
        if b1 >= Long*0.5 and b1 <= Long:
            return 'left'

    if x0 == 0 and y0 == 0 and theta == 0:
        return 'left'
    if (b1 >= 0 and b1 <= Long):  # 左边交点Y轴上（三种情况）
        x1 = 0
        y1 = b1
        if ((Long - b1) / k >= 0 and (Long - b1) / k <= Wide):
            x2 = (Long - b1) / k
            y2 = Long
        if ((Wide * k + b1) >= 0 and (Wide * k + b1) <= Long):
            x2 = Wide
            y2 = (Wide * k + b1)
        if (-b1 / k >= 0 and -b1 / k <= Wide):
            x2 = -b1 / k
            y2 = 0
        if np.cos(theta) > 0:  # 船头方向朝右
            SR = x1 * y1 + x2 * y2 - x1 * y2 + (x2 - x1) * (y1 - y2) / 2
            SL = Long * Wide - SR
        if np.cos(theta) <= 0:  # 船头方向朝左
            SL = x1 * y1 + x2 * y2 - x1 * y2 + (x2 - x1) * (y1 - y2) / 2
            SR = Long * Wide - SL
    if ((Wide * k + b1) >= 0 and (Wide * k + b1) <= Long):  # 右边交点在x=3.66上（三减一 种情况）
        x2 = Wide
        y2 = (Wide * k + b1)
        if ((Long - b1) / k >= 0 and (Long - b1) / k <= Wide):
            x1 = (Long - b1) / k
            y1 = Long
        if (-b1 / k >= 0 and -b1 / k <= Wide):
            x1 = -b1 / k
            y1 = 0
        if np.cos(theta) > 0:  # 船头方向朝右
            SR = x1 * y1 + x2 * y2 - x1 * y2 + (x2 - x1) * (y1 - y2) / 2
            SL = Long * Wide - SR
        if np.cos(theta) <= 0:  # 船头方向朝左
            SL = x1 * y1 + x2 * y2 - x1 * y2 + (x2 - x1) * (y1 - y2) / 2
            SR = Long * Wide - SL

    if ((Long - b1) / k >= 0 and (
            Long - b1) / k <= Wide and -b1 / k >= 0 and -b1 / k <= Wide and k >= 0):  # 两个交点在y=0和y=13上
        x1 = -b1 / k
        y1 = 0
        x2 = (Long - b1) / k
        y2 = Long
        if np.sin(theta) >= 0:  # 船头方向朝上
            SL = (x1+x2)*Long*0.5
            SR = Long * Wide - SL
        if np.sin(theta) <= 0:  # 船头方向朝下
            SR = (x1+x2)*Long*0.5
            SL = Long * Wide - SR
    if ((Long - b1) / k >= 0 and (Long - b1) / k <= Wide and -b1 / k >= 0 and -b1 / k <= Wide and k < 0):
        x1 = (Long - b1) / k
        y1 = Long
        x2 = -b1 / k
        y2 = 0
        if np.sin(theta) >= 0:  # 船头方向朝上
            SL = (x1+x2)*Long*0.5
            SR = Long * Wide - SL
        if np.sin(theta) <= 0:  # 船头方向朝下
            SR = (x1+x2)*Long*0.5
            SL = Long * Wide - SR

    if SL > SR:
        return 'left'
    if SL < SR:
        return 'right'


def corss_Rect(frame1):
    # thresh = get_fg_from_hue_watershed_saturation(frame, 20)
    # thresh = cv2.medianBlur(thresh, 5)
    # kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (9, 9))  # 形态学开运算，简单滤除离框较远的干扰
    # thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    # left_area = thresh[0:319,:]
    # right_area = thresh[320:640,:]
    # _, cntsl, hierarchy = cv2.findContours(left_area, cv2.RETR_TREE,
    #                                        cv2.CHAIN_APPROX_SIMPLE)
    # _, cntsr, hierarchy = cv2.findContours(right_area, cv2.RETR_TREE,
    #                                        cv2.CHAIN_APPROX_SIMPLE)
    # if not (cntsl == []):
    #     for c_l in cntsl:
    #         Ml = cv2.moments(c_l)  # 求图形的矩
    #         cXl = int((Ml["m10"] + 1) / (Ml["m00"] + 1))
    #         cYl = int((Ml["m01"] + 1) / (Ml["m00"] + 1))
    # if not (cntsr == []):
    #     for c_r in cntsr:
    #         Mr = cv2.moments(c_r)  # 求图形的矩
    #         cXr = int((Mr["m10"] + 1) / (Mr["m00"] + 1))
    #         cYr = int((Mr["m01"] + 1) / (Mr["m00"] + 1))
    #
    #
    # if cntsl==[] and not(cntsr==[]):
    #     control_AUV('left')
    # elif not(cntsl==[]) and cntsr==[]:
    #     control_AUV('right')
    # elif not(cntsl==[]) and not(cntsr==[]):
    #     if (cXl+cXr+320)/2 > 390:
    #         control_AUV('left')
    #     if (cXl+cXr+320)/2 < 250:
    #         control_AUV('right')
    #     if (cXl+cXr+320)/2>250 and (cXl+cXr+320)/2<390:
    #         control_AUV('go')
    # elif cntsl==[] and cntsr==[]:
    #     control_AUV('go')

    global  corss_Rect_flag
    global cYl
    global cYr
    global cXl
    global cXr
    corss_Rect_flag = 1

    cntsl = []
    cntsr = []
    framel = frame1[:, 0:319]
    framer = frame1[:, 320:640]
    thresh = get_fg_from_hue_watershed_saturation(frame1, 20)
    thresh = cv2.medianBlur(thresh,5)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (9, 9))  # 形态学开运算，简单滤除离框较远的干扰
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    left_area = thresh[:, 0:319]
    right_area = thresh[:, 320:640]
    _, cntsl0, hierarchy = cv2.findContours(left_area, cv2.RETR_TREE,
                                            cv2.CHAIN_APPROX_SIMPLE)
    _, cntsr0, hierarchy = cv2.findContours(right_area, cv2.RETR_TREE,
                                            cv2.CHAIN_APPROX_SIMPLE)

    for cnt in cntsl0:
        area = cv2.contourArea(cnt)
        if area > 5000:
            cntsl.append(cnt)

    for cnt in cntsr0:
        area = cv2.contourArea(cnt)
        if area > 5000:
            cntsr.append(cnt)

    if not (cntsl == []):
        for c_l in cntsl:
            Ml = cv2.moments(c_l)  # 求图形的矩
            cXl = int((Ml["m10"] + 1) / (Ml["m00"] + 1))
            cYl = int((Ml["m01"] + 1) / (Ml["m00"] + 1))
            cv2.circle(framel, (cXl, cYl), 7, (0, 255, 255), -1)
            cv2.drawContours(framel, [c_l], -1, (0, 255, 0), 2)
    if not (cntsr == []):
        for c_r in cntsr:
            Mr = cv2.moments(c_r)  # 求图形的矩
            cXr = int((Mr["m10"] + 1) / (Mr["m00"] + 1))
            cYr = int((Mr["m01"] + 1) / (Mr["m00"] + 1))
            cv2.circle(framer, (cXr, cYr), 7, (255, 255, 255), -1)
            cv2.drawContours(framer, [c_r], -1, (0, 255, 0), 2)


    if cntsl == [] and not (cntsr == []):
        control_AUV('left')
    elif not (cntsl == []) and cntsr == []:
        control_AUV('right')
    elif not (cntsl == []) and not (cntsr == []):
        if abs(cYl - cYr) < 40:
            Y_flag = True
        else:
            Y_flag = False

        if Y_flag:
            if (cXl + cXr + 320) / 2 > 390:
                control_AUV('left')
            if (cXl + cXr + 320) / 2 < 250:
                control_AUV('right')
            if (cXl + cXr + 320) / 2 < 390 and (cXl + cXr + 320) / 2 > 250:
                control_AUV('go')
        else:
            if cYl > cYr:
                control_AUV('left')
            elif cYl < cYr:
                control_AUV('right')

    elif cntsl == [] and cntsr == []:
        control_AUV('go')


def action(AUV_dx,AUV_dtheta):
    global action_count
    if action_count == 0:                              #先转向
        if AUV_dtheta >= 0:
            Speed1, Speed2, Speed3, Speed4 = 192, 64, 64, 192
            [Time1, Time2, Time3, Time4] = [AUV_dtheta / 1.57 * 2, AUV_dtheta / 1.57 * 2, AUV_dtheta / 1.57 * 2,
                                            AUV_dtheta / 1.57 * 2 ] # 64转速，2秒，旋转90°
        if AUV_dtheta < 0:
            Speed1, Speed2, Speed3, Speed4 = 64, 192, 192, 64
            [Time1, Time2, Time3, Time4] = [-AUV_dtheta / 1.57 * 2, -AUV_dtheta / 1.57 * 2, -AUV_dtheta / 1.57 * 2,
                                            -AUV_dtheta / 1.57 * 2]    # 64转速，2秒，旋转90°

    elif action_count == 6:                              #再平移
        if AUV_dx >= 0:
            Speed1, Speed2, Speed3, Speed4 = 64, 192, 64, 192
            [Time1, Time2, Time3, Time4] = [AUV_dx / 0.125, AUV_dx / 0.125, AUV_dx / 0.125, AUV_dx / 0.125]              # 1秒平移0.125m
        if AUV_dx < 0:
            Speed1, Speed2, Speed3, Speed4 = 192, 64, 192, 64
            [Time1, Time2, Time3, Time4] = [-AUV_dx / 0.125, -AUV_dx / 0.125, -AUV_dx / 0.125, -AUV_dx / 0.125]         # 1秒平移0.125m

    action_count = action_count + 1

    act = [[hex(Speed1,10), hex(Time1,10)], [hex(Speed2,10), hex(Time2,10)], [hex(Speed3,10), hex(Time3,10)], [hex(Speed4,10), hex(Time4,10)]]
    return act, action_count


def flag_count():
    global Tarnum
    global Trunum
    global data_count
    global action_count
    global corss_Rect_flag
    data_count = data_count + 1
    if data_count >= 5:
        data_count = 0

    if action_count >= 96:
        corss_Rect_flag = 0
        Trunum = False
    if action_count >= 1 and action_count <= 5:
        Trunum = False
        action_count = action_count + 1
    elif action_count == 6:
        Trunum = True
        Tarnum = 0
    elif action_count > 6 and action_count <= 15:
        Trunum = False
        action_count = action_count + 1
    elif action_count > 16:
        Tarnum = 0
        Trunum = True
        action_count = action_count + 1


camera = PiCamera()
camera.resolution = (640,480)
camera.framerate = 32
rawCapture = PiRGBArray(camera, size=(640,480))


cap = cv2.VideoCapture(0)
cap.set(3, 640)  # 设置分辨率
cap.set(4, 480)

if __name__ == "__main__":
    for frame0 in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
        Camnum,frame = Camera_switch(frame0, Tarnum, Trunum)
        Franum, thresh = Frame_Preprocess(Camnum, frame)
        Tarnum, data, frame = Target_recognition(Franum, thresh, frame)
        Trunum = Trust_choose(Tarnum, data)
        flag_count()
        Decision(Tarnum,Trunum,data,frame)
        Odometer(od_r,dl,dr,dtheta)

        cv2.imshow("Frame", frame)
        key = cv2.waitKey(1) & 0xFF
        rawCapture.truncate(0)
        if key == ord("q"):
            break

    cv2.destroyAllWindows()
    sys.exit()

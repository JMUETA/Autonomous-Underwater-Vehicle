import cv2
import numpy as np
import sys

Count1 = 0

cap = cv2.VideoCapture(0)
cap.set(3, 320)  # 设置分辨率
cap.set(4, 240)

cap1 = cv2.VideoCapture(2)  # 前置摄像头
cap1.set(3, 320)  # 设置分辨率
cap1.set(4, 240)


def a():
    global Count1
    Count1 = Count1 + 1
    if Count1 <= 25:
        ret, frame = cap.read()
    else:
        ret0, frame = cap1.read()
    if Count1 > 50:  # 1-100帧为前置摄像头，100-200为下置摄像头
        Count1 = 0
    return frame

while True:
    frame = a()
    cv2.imshow('frame',frame)
    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break
cv2.destroyAllWindows()
sys.exit()

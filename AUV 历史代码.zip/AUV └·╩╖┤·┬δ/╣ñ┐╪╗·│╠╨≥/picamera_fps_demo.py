# author:    Adrian Rosebrock
# website:   http://www.pyimagesearch.com

# USAGE
# BE SURE TO INSTALL 'imutils' PRIOR TO EXECUTING THIS COMMAND
# python picamera_fps_demo.py
# python picamera_fps_demo.py --display 1

# import the necessary packages
from __future__ import print_function
from imutils.video import VideoStream
from imutils.video import FPS
#from picamera.array import PiRGBArray
#from picamera import PiCamera
#import argparse
import imutils
import time
import cv2


cap = cv2.VideoCapture(0)
cap.set(3, 640)  # 设置分辨率
cap.set(4, 480)


#cap1 = cv2.VideoCapture(2)
#cap1.set(3, 640)  # 设置分辨率
#cap1.set(4, 480)


vs = VideoStream(usePiCamera=True).start()

time.sleep(2.0)
fps = FPS().start()

cnt = 0

while True:

    if cnt < 30:
        ret, frame = cap.read()
    else:
        #ret, frame = cap1.read()
        frame = vs.read()
        frame = imutils.resize(frame, width=640)

    # check to see if the frame should be displayed to our screen
    cv2.imshow("Frame", frame)
    
    cnt = (cnt+1)%90
    
    key = cv2.waitKey(1) & 0xFF
    if key==ord('q'):
        break

    # update the FPS counter
    fps.update()


fps.stop()
print("[INFO] elasped time: {:.2f}".format(fps.elapsed()))
print("[INFO] approx. FPS: {:.2f}".format(fps.fps()))

# do a bit of cleanup
cv2.destroyAllWindows()
vs.stop()

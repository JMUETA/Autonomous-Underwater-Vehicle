# title           :AUV_2_3.py
# description     :AUV巡游系统（框架版）
# author          :Fatih and Chen YiLin
# date            :2019.7.27
# version         :0.2
# notes           :树莓派版
# python_version  :3.6
# difference      :一次只开一个摄像头



import time
import cv2
import logging
import sys
import numpy as np
import serial
import threading
from collections import deque
from scipy.spatial import distance as dist
from collections import OrderedDict



#寻球可能所在的参考坐标，给予AUV一个大致的开始寻找方向
Reference_coor = (150,350)

#指令发送计数器
order_count1 = 0
order_count2 = 10
order_count3 = 20
order_count4 = 30
count_max1 = 30
count_max2 = 35
count_max3 = 40
count_max4 = 45

#框的数量
Rect_num = 5

#线计数器
line_count = 0

#记录已经过的框
crossed_count = 0

#中点两边边界
left_min = 280
right_max = 360

#引导线转动参数
guide_line_enable_lower = -0.4
guide_line_enable_higher = 0.4


#模式计数器
SEARCH_count = 0            #寻找模式
SEARCH_count_max = 400
SEARCH_count_time = 0
SEARCH_count_time_max = 4

ADJUST_count = 0            #调整模式
ADJUST_count_max = 400
ADJUST_count_time = 0
ADJUST_count_time_max = 4

CROSS_count = 0            #调整模式
CROSS_count_max = 500

#引导线转动参数
guide_line_enable_lower = -0.4
guide_line_enable_higher = 0.4

#miniArea噪声抑制程度，越大识别框的能力越低。准确性越高
cnts2_area = 15000
cntsl0_area = 50
cntsr0_area = 50

#框信任度最大方差之
var_maxvalue = 40000

# AUV测框的距离参数
FORCAL = 600                # 距离函数设定的焦距，为定值
Know_Distance = 30.0        # 已知距离（定值）
Know_Width = 25.2

data_count = 0              # 框信任度，存储历史数据的计数器
cX_container = []
minAreax_container = []

# AUV位置列表，分别记录AUV的x,y,theta最大存储400个位置数据
x0 = deque(maxlen=400)
y0 = deque(maxlen=400)
theta0 = deque(maxlen=400)
x0.appendleft(0)
y0.appendleft(0)
theta0.appendleft(0)


Rect_point = []
Line_point = []


# 差速模型接口
# 暂定的AUV结构参数
# b : AUV宽度
# dl,dr : 左右推进器一次推进器前进距离
b = 0.5
dl = 0.25
dr = 0.25
AUV_dx = 0                                  #未给出
AUV_dy = 0
AUV_dtheta = 0

# 无目标信任度计数参数
Count = 0
K_COUNT = 0
X_COUNT = 0

#摄像头切换计数器
Count1 = 0

# AUV检测球参数
buff = 64
ballLower = (29, 86, 6)
ballUpper = (64, 255, 255)
pts = deque(maxlen=buff)


#颜色抑制阈值，加一层颜色阈值提高图像分割去除噪声的能力
red_lower = 0
green_lower = 50
bule_lower = 60
red_higher = 255
green_higher = 150
bule_higher = 150
color = [([red_lower, green_lower, bule_lower], [red_higher, green_higher, bule_higher])]

red_lower_d = 0
green_lower_d = 50
bule_lower_d = 60
red_higher_d = 255
green_higher_d = 150
bule_higher_d = 150
color_d = [([red_lower_d, green_lower_d, bule_lower_d], [red_higher_d, green_higher_d, bule_higher_d])]

# AUV标志位
#Trunum信任度标志位
#Tarnum目标标志位
Trunum = None
Tarnum = 2

act = [0x00]

CROSS_count_flag = 1

Rect_Tarnum = None
Line_Tarnum = None

#串口通信接口
portx = '/dev/ttyUSB0'
bps = 115200
timex = 0.01
ser = serial.Serial(portx, bps, timeout=timex)

# portx1 = '/dev/ttyUSB2'
# bps1 = 115200
# ser1 = serial.Serial(portx1, bps1, timeout=timex)


#分水岭图像分割函数
# 用于二值化图像，分割出所需要的内容
def get_fg_from_hue_watershed_saturation(img, margin):
    mask, hue = get_fg_from_hue(img, margin)

    mask_bg = cv2.inRange(hue, 60, 90)
    mask_bg = cv2.bitwise_or(mask_bg, cv2.inRange(hue, 128, 129))

    markers = np.zeros(mask.shape, np.int32)
    markers[mask == 255] = 1
    markers[mask_bg == 255] = 2

    cv2.watershed(img, markers)
    mask[markers == 1] = 255

    # img2 = img.copy()
    # img2[markers == 1] = 255
    # cv.imshow("1", img2)
    #
    # img2 = img.copy()
    # img2[markers == 2] = 255
    # cv.imshow("2", img2)
    #
    # img2 = img.copy()
    # img2[markers == -1] = 255
    # cv.imshow("3", img2)

    return mask

#HSV处理函数
def get_fg_from_hue(img, margin):
    FRACTION_AS_BLANK = 0.003
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    dark = hsv[..., 2] < 32
    hsv[..., 0][dark] = 128

    dark = hsv[..., 1] < 50
    hsv[..., 0][dark] = 128

    mask = cv2.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
    mask2 = cv2.inRange(hsv[..., 0], np.array((180 - margin)), np.array((180)))

    mask = cv2.bitwise_or(mask, mask2)

    if cv2.countNonZero(mask) < mask.shape[0] * mask.shape[1] * FRACTION_AS_BLANK:
        mask.fill(0)

    return [mask, hsv[..., 0]]


#引导线检测函数
def guide_line_detect(mask, area_th=5000, aspect_th=0.8):
    '''

    TODO：部分时候很靠近边框时，会检测到框
    :param img:
    :param area_th:
    :param aspect_th:
    :return:
    '''
    ASPECT_RATIO_MIN = 0.15  # 重要参数
    MAX_CONTOUR_NUM = 6  # 如果出现更多的轮廓，不进行处理。这是为了对抗白平衡

    _, contours, hierarchy = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # 目前对自动白平衡的处理，太多轮廓则直接返回
    candidates = []
    candidates_y = []
    if len(contours) < MAX_CONTOUR_NUM:
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > area_th:  # 关键参数
                (x1, y1), (w1, h1), angle1 = cv2.minAreaRect(cnt)
                minAreaRect_area = w1 * h1
                aspect_ratio = float(w1) / h1
                if aspect_ratio > 1:
                    aspect_ratio = 1.0 / aspect_ratio
                    angle1 = np.mod(angle1 + 90, 180)

                extent = float(area) / minAreaRect_area

                hull = cv2.convexHull(cnt)
                hull_area = cv2.contourArea(hull)
                solidity = float(area) / hull_area

                (x2, y2), (MA, ma), angle2 = cv2.fitEllipse(cnt)
                if angle2 > 90:
                    angle2 -= 180

                logging.debug('area %f,aspect_ratio %f,extent %f,solidity %f,angle1 %f,angle2 %f' % (
                area, aspect_ratio, extent, solidity, angle1, angle2))

                if aspect_ratio > aspect_th or aspect_ratio < ASPECT_RATIO_MIN or extent < 0.7 or solidity < 0.7 or abs(
                                angle1 - angle2) > 30:
                    break

                # img2 = img.copy()
                # contour_info(img2,area,aspect_ratio,extent,solidity,angle1,angle2,((x2, y2), (MA, ma), angle2))
                # cv.drawContours(img2, [cnt], 0, (0, 255, 0), 3)
                # show_img(img2)

                candidates.append((x1, y1, angle2))  # 目前这个组合是比较好的。
                candidates_y.append(y1)

        nc = len(candidates)
        if nc == 0:
            return None
        elif nc == 1:
            return candidates[0]
        else:
            logging.debug('multiple')

            idx = np.argmax(np.array(candidates_y))
            return candidates[idx]


#检测框距离函数
def distance_to_camera(width, forcal, perwidth):  # 距离计算
    return ((width * forcal) * 0.3048) / (12 * perwidth)


#角度转弧度函数
def angle2rad(theta):
    w = (theta * np.pi) / 180
    return w


#AUV控制，通信协议（2019版）
def control_AUV(od_r,dis=1):
    global dl
    global dr
    global AUV_dx,AUV_dtheta
    head = [0xaa, 0x55, 0x10]
    depth_lock_bit = [0x01]
    dir_lock_bit = [0x01]
    forword_back_bit = [0x00]
    left_right_bit = [0x00]
    up_down_bit = [0x00]
    rotation_bit = [0x00]
    power_value = [0x00]
    other_bit = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    start_stop_bit = [0x00]

    if od_r == 'go':
        dir_lock_bit = [0x02]
        forword_back_bit = [0x01]
        start_stop_bit = [0x01]
        dl = 0.2  # 前进0.2m
        dr = 0.2
        print('go')
    if od_r == 'back':
        dir_lock_bit = [0x02]
        forword_back_bit = [0x02]
        start_stop_bit = [0x01]
        dl = -0.2  # 后退0.2m
        dr = -0.2
        print('back')
    # if od_r == 'left':
    #     dir_lock_bit[0] = 0x02
    #     Left_control_bit[0] = 0x80
    #     Right_control_bit[0] = 0xb2
    #     start_stop_bit[0] = 0x01
    #     dl = -0.1                              #右旋浆前进0.1m
    #     dr = 0.1
    #     print('left')
    # if od_r == 'right':
    #     dir_lock_bit[0] = 0x02
    #     Right_control_bit[0] = 0x80
    #     Left_control_bit[0] = 0xb2
    #     start_stop_bit[0] = 0x01
    #     dl = 0.1                              #左旋浆前进0.1m
    #     dr = -0.1
    #     print('right')
    if od_r == 'left_translation':  # 左平移
        dir_lock_bit = [0x02]
        left_right_bit = [0x02]
        start_stop_bit = [0x01]
        AUV_dx = -0.2
        print('left_translation')
    if od_r == 'right_translation':  # 右平移
        dir_lock_bit = [0x02]
        left_right_bit = [0x01]
        start_stop_bit = [0x01]
        AUV_dx = 0.2
        print('right_translation')
    if od_r == 'left_rotation':  # 左旋转
        dir_lock_bit = [0x02]
        rotation_bit = [0x02]
        start_stop_bit = [0x01]
        AUV_dtheta = 0.4
        print('left_rotation')
    if od_r == 'right_rotation':  # 右旋转
        dir_lock_bit = [0x02]
        rotation_bit = [0x01]
        start_stop_bit = [0x01]
        AUV_dtheta = -0.4
        print('right_rotation')
    if od_r == 'up':
        depth_lock_bit = [0x02]
        up_down_bit = [0x02]
        start_stop_bit = [0x01]
        print('up')
    if od_r == 'down':
        depth_lock_bit = [0x02]
        up_down_bit = [0x01]
        start_stop_bit = [0x01]
        print('down')
    if od_r == 'stop':
        start_stop_bit = [0x00]
        dl = 0
        dr = 0
        print('stop')

    parameter = head + depth_lock_bit + dir_lock_bit + forword_back_bit + left_right_bit + up_down_bit + rotation_bit + power_value + other_bit + start_stop_bit
    check_sum = sum(parameter)
    check_sum = [check_sum & 255]

    msg = parameter + check_sum
    msg = bytearray(msg)
    # try:
    #     ser.write(msg)
    # except Exception as e:
    #     print("--异常--:", e)

    return dl,dr,AUV_dx,AUV_dtheta




#通信协议（2018版）
# def control_AUV(od_r):
#     global act
#     global AUV_dx,AUV_dtheta,dl,dr
#     head_bit = [0xaa, 0x55]  # 两个字节为包头
#     length_bit = [0x03]      #数据长度
#     follow_bit = [0x08]      #用来选择三种模式
#     control_bit = [0x00]  # 控制字节有效值：0-255
#     time_level_bit = [0x00]  # 高四位为推进器动作时间，低四位为推进器推力的级数
#
#     if od_r == 1:                      #左平移
#         follow_bit = [0x08]
#         control_bit = [0x4b]
#         time_level_bit = act
#         AUV_dx = -0.2
#     elif od_r == 2:                    #右平移
#         follow_bit = [0x08]
#         control_bit = [0xa0]
#         time_level_bit = act
#         AUV_dx = 0.2
#
#     if od_r == 'left':                 #左旋转
#         follow_bit = [0x08]
#         control_bit = [0x70]
#         time_level_bit = [0x22]
#         AUV_dtheta = 0.4
#     if od_r == 'right':                 #右旋转
#         follow_bit = [0x08]
#         control_bit = [0xce]
#         time_level_bit = [0x22]
#         AUV_dtheta = -0.4
#
#     if od_r == 'go':
#         follow_bit = [0x08]
#         control_bit = [0xe6]
#         time_level_bit = [0x22]
#         dl = 0.2
#         dr = 0.2
#
#     if od_r == 'left_turn':              #左转弯
#         follow_bit = [0x07]
#         control_bit = [0x01]
#         time_level_bit = [0x22]
#         dl = 0.1
#         dr = 0.2
#     elif od_r == 'right_turn':           #右转弯
#         follow_bit = [0x07]
#         control_bit = [0x02]
#         time_level_bit = [0x22]
#         dl = 0.2
#         dr = 0.1
#
#     if od_r == 3:                #前进的同时左转（微调）
#         follow_bit = [0x09]
#         control_bit = [0x0A]
#         time_level_bit = [act]
#         dl = 0.15
#         dr = 0.2
#     elif od_r == 4:              #前进的同时右转（微调）
#         follow_bit = [0x09]
#         control_bit = [0x0B]
#         time_level_bit = [act]
#         dl = 0.2
#         dr = 0.15
#
#     parameter = head_bit + length_bit + follow_bit + control_bit + time_level_bit
#     check_sum = sum(parameter)
#     check_sum = [check_sum & 255]
#
#     msg = parameter + check_sum
#     msg = bytearray(msg)
#     try:  # 发送串口指令 与单片机通信
#         ser.write(msg)
#     except Exception as e:
#         print("--异常--:", e)
#
#     return AUV_dx,AUV_dtheta, dl, dr



#识别到引导线时的转向决策
def guide_line_turn(angle):
    if (guide_line_enable_lower < angle) and angle < guide_line_enable_higher:
        control_AUV('go')
    elif angle < guide_line_enable_lower:
        control_AUV('left_translation')
    elif angle > guide_line_enable_higher:
        control_AUV('right_translation')


#是否要往Rect_point添加参数
#若当前过框坐标已经记录，则无需重复记录
def add_judege(X, Y):
    now_point = [X, Y]
    itertime = len(Rect_point)
    if itertime < 1:
        return True
    for i in range(itertime):
        dis = np.sqrt(np.sum(np.square(Rect_point[i] - now_point)))
        if dis < 1:
            return False
    return True

#向Rect_point添加框坐标
def Add_Rect_point(auv_local, metre, yaw, cX, Rect_width):
    bias = (0.6 * (cX - 160)) / Rect_width
    X = auv_local[0] + metre * np.cos(yaw) + bias
    Y = auv_local[1] + metre * np.sin(yaw)
    flag = add_judege(X, Y)
    now_point = [X, Y]
    if flag:
        Rect_point.append(now_point)

#向Line_point添加线坐标
def Add_Line_point(auv_local):
    X = auv_local[-1][0]
    Y = auv_local[-1][1]
    flag = add_judege(X, Y)
    now_point = [X, Y]
    if flag:
        Line_point.append(now_point)

def Camera_switch():  # 摄像头切换
    global Count1
    global CROSS_count_flag
    # Count1 = Count1 + 1
    # if CROSS_count_flag == False:  # 过框时保持打开前置摄像头
    #     ret0, frame = cap1.read()  # 前置摄像头画面
    #     Camnum = 0
    # else:                         # 其他时候摄像头一直切换
    if Count1 <= 50:          # 1-50帧为前置摄像头，50-100为下置摄像头
        ret0, frame = cap.read()  # 前置摄像头画面
        Camnum = 0
    else:
        ret, frame = cap1.read()
        Camnum = 1
    if Count1 == 100:
        Count1 = 0
    return Camnum, frame



#图像预处理，将RGB图像转换成二值图像
def Frame_Preprocess(Camnum, frame):
    # for (lower, upper) in color:
    #     lower = np.array(lower, dtype="uint8")
    #     upper = np.array(upper, dtype="uint8")
    #     mask = cv2.inRange(frame, lower, upper)
    #     mask = cv2.bitwise_not(mask)
    #     output = cv2.bitwise_and(frame, frame, mask=mask)
    if Camnum == 0:
        Franum = 0
        thresh = get_fg_from_hue_watershed_saturation(frame, 20)
        thresh = cv2.medianBlur(thresh, 5)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))  # 形态学开运算，简单滤除离框较远的干扰
        thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    elif Camnum == 1:
        Franum = 1
        cv2.boxFilter(frame, -1, (5, 5), frame)
        thresh = get_fg_from_hue_watershed_saturation(frame, 20)
    return Franum, thresh



#目标识别，用于识别框线
#thresh0:前置摄像头二值化图像 frame0:前置摄像头图像
#Rect_Tarnum:是否识别到了框  data:框中点(cX,cY),外接矩形数据，框距离吗，外接矩形四点坐标
def Rect_Target_recognition(thresh,frame):
    global cX
    Rect_Tarnum = False                #未识别
    data = None
    cnts2 = []
    _, cnts3, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)  # findContours寻找轮廓
    for cnt in cnts3:
        area = cv2.contourArea(cnt)
        if area > cnts2_area:
            cnts2.append(cnt)
    if not (cnts2 == []):
        for c_3 in cnts2:
            M = cv2.moments(c_3)  # 求图形的矩
            cX = int((M["m10"] + 1) / (M["m00"] + 1))
            cY = int((M["m01"] + 1) / (M["m00"] + 1))

    if not (cnts2 == []):
        c = max(cnts2, key=cv2.contourArea)
        marker = cv2.minAreaRect(c)  # 得到最小外接矩形（中心(x,y),（宽，高），选住角度）
        metre = distance_to_camera(Know_Width, FORCAL, marker[1][0] + 1)  # 距离摄像头距离
        box = cv2.boxPoints(marker)  # 获取最小外接矩形的四个顶点
        box = np.int0(box)
        cv2.drawContours(frame, [box], -1, (0, 255, 0), 2)
        cv2.putText(frame, "%.2fm" % (metre), (frame.shape[1] - 200, frame.shape[0] - 20),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    2.0, (0, 255, 0), 3)

        Rect_Tarnum = True
        data = [cX,cY,marker, metre, box]
    return Rect_Tarnum,data,frame



#识别线目标
#thresh1:下置摄像头二值化图像，frame1:下置摄像头图像
#Line_Tarnum:是否识别到了线，data:线上的两个坐标(x1,y1),线与AUV夹角angle,先的四点坐标
def Line_Target_recognition(thresh,frame):
    data = None
    guide_line = guide_line_detect(thresh)  # 检测下置摄像头是否读到引导线
    Line_Tarnum = False
    if guide_line:
        # 发现引导线，停一下
        x, y, angle = guide_line
        angle = angle / 180 * np.pi
        cv2.line(frame, (int(x), int(y)), (int(x + 100 * np.sin(angle)), int(y - 100 * np.cos(angle))),
                 (0, 255, 0), 2)
        x1 = int(x + 100 * np.sin(angle))
        y1 = int(y - 100 * np.cos(angle))
        Line_Tarnum = True
        data = [x1, y1, angle]
        return Line_Tarnum, data, frame
    return Line_Tarnum, data, frame



#框信任度判断
def Rect_Trust(data):
    if data is not None:
        cX = data[0]
        marker = data[1]
        minArea_x = marker
        cX_container.append(cX)
        minAreax_container.append(marker)
        if cX - minArea_x > 50:
            return 0
        if len(cX_container) >= 5 and len(minAreax_container) >= 5:
            var_cX = np.var(cX_container)
            var_min = np.var(minAreax_container)
            # cv2.putText(frame, "%.2f" % (var_cX), (frame.shape[1] - 200, frame.shape[0] - 20),
            #             cv2.FONT_HERSHEY_SIMPLEX,
            #             2.0, (0, 255, 0), 3)
            if var_cX < var_maxvalue and var_min < var_maxvalue:  # 方差，待测量
                return 1
            else:
                return 0
    return 2

# 无目标信任度
def Estate(flag):
    global Count
    global C_L_COUNT
    global Est
    global Tarnum
    Count = Count + 1
    if flag == 0:  # 不信任框
        Est = 1
    if flag == 2:  # 无框 无线
        Est = 2
    if flag == 1:  # 有线
        Est = 3

    if Est == 2:
        C_L_COUNT = C_L_COUNT + 1  # 无框则加一
    if Est == 1:
        C_L_COUNT = C_L_COUNT + 1

    if Count == 10:
        if C_L_COUNT >= 10:
            Tarnum = 2
            return True
        Count = 0
        C_L_COUNT = 0  # 10次后清零

    elif Count < 10:
        return 0



#里程表记录函数
def Odometer(model,AUV_dx,AUV_dy,dl,dr):                    #里程表
    global x0
    global y0
    global theta0
    if model=='diff':                               #差速模式
        x = x0[-1]
        y = y0[-1]
        theta = theta0[-1]
        ddx = (dr+dl)*np.cos(theta+(dr-dl)/2*b)/2
        ddy = (dr+dl)*np.sin(theta+(dr-dl)/2*b)/2
        dtheta = (dr-dl)/b
        x1 = x + ddx
        y1 = y + ddy
        theta1 = theta + dtheta
        x0.appendleft(x1)
        y0.appendleft(y1)
        theta0.appendleft(theta1)
    else:                                           #平移模式
        x = x0[0]
        y = y0[0]
        theta = theta0[0]
        dx = AUV_dx * np.cos(theta)
        dy = AUV_dy * np.sin(theta)
        x1 = x + dx
        y1 = y + dy
        x0.appendleft(x1)
        y0.appendleft(y1)
        theta0.appendleft(theta)
    return 0


#无目标情况下的位置检测
def search(theta, x0, y0):
    global x1
    global x2
    global y1
    global y2
    global SR
    global SL
    k = np.tan(theta)
    b1 = y0 - k * x0

    Wide = 3.66
    Long = 7.3

    if np.cos(theta) == 1:                      #k=0的情况
        if  0 <= b1 < Long*0.5:
            return 'left_rotation'
        if Long*0.5 <= b1 <= Long:
            return 'right_rotation'
    if np.cos(theta) == -1:
        if 0 <= b1 < Long*0.5:
            return 'right_rotation'
        if Long*0.5 <= b1 <= Long:
            return 'left_rotation'

    if x0 == 0 and y0 == 0 and theta == 0:
        return 'left_rotation'
    if 0 <= b1 <= Long:  # 左边交点Y轴上（三种情况）
        x1 = 0
        y1 = b1
        if 0 <= (Long - b1) / k <= Wide:
            x2 = (Long - b1) / k
            y2 = Long
        if 0 <= (Wide * k + b1) <= Long:
            x2 = Wide
            y2 = (Wide * k + b1)
        if  0 <= (-b1 / k) <= Wide:
            x2 = -b1 / k
            y2 = 0
        if np.cos(theta) > 0:  # 船头方向朝右
            SR = x1 * y1 + x2 * y2 - x1 * y2 + (x2 - x1) * (y1 - y2) / 2
            SL = Long * Wide - SR
        if np.cos(theta) <= 0:  # 船头方向朝左
            SL = x1 * y1 + x2 * y2 - x1 * y2 + (x2 - x1) * (y1 - y2) / 2
            SR = Long * Wide - SL
    if  0 <= (Wide * k + b1) <= Long:  # 右边交点在x=3.66上（三减一 种情况）
        x2 = Wide
        y2 = (Wide * k + b1)
        if 0 <= (Long - b1) / k <= Wide:
            x1 = (Long - b1) / k
            y1 = Long
        if 0 <= -b1 / k <= Wide:
            x1 = -b1 / k
            y1 = 0
        if np.cos(theta) > 0:  # 船头方向朝右
            SR = x1 * y1 + x2 * y2 - x1 * y2 + (x2 - x1) * (y1 - y2) / 2
            SL = Long * Wide - SR
        if np.cos(theta) <= 0:  # 船头方向朝左
            SL = x1 * y1 + x2 * y2 - x1 * y2 + (x2 - x1) * (y1 - y2) / 2
            SR = Long * Wide - SL

    if 0 <= (Long - b1) / k <= Wide and 0 <= (-b1 / k) <= Wide and k >= 0:  # 两个交点在y=0和y=13上
        x1 = -b1 / k
        y1 = 0
        x2 = (Long - b1) / k
        y2 = Long
        if np.sin(theta) >= 0:  # 船头方向朝上
            SL = (x1+x2)*Long*0.5
            SR = Long * Wide - SL
        if np.sin(theta) <= 0:  # 船头方向朝下
            SR = (x1+x2)*Long*0.5
            SL = Long * Wide - SR
    if 0 <= (Long - b1) / k <= Wide and 0 <= -b1 / k <= Wide and k < 0:
        x1 = (Long - b1) / k
        y1 = Long
        x2 = -b1 / k
        y2 = 0
        if np.sin(theta) >= 0:  # 船头方向朝上
            SL = (x1+x2)*Long*0.5
            SR = Long * Wide - SL
        if np.sin(theta) <= 0:  # 船头方向朝下
            SR = (x1+x2)*Long*0.5
            SL = Long * Wide - SR

    if SL > SR:
        return 'left_rotation'
    if SL < SR:
        return 'right_rotation'

#过框模式，切换识别模式。将放行更多的噪声，以此来增加识别能力
def cross_Rect(frame):
    print('直走')                   #过框模式保持直走，再做差速调整
    global corss_Rect_flag
    global cYl
    global cYr
    global cXl
    global cXr
    global act
    corss_Rect_flag = 1

    cntsl = []
    cntsr = []
    framel = frame[:, 0:319]
    framer = frame[:, 320:640]
    thresh = get_fg_from_hue_watershed_saturation(frame, 20)
    thresh = cv2.medianBlur(thresh, 5)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (9, 9))  # 形态学开运算，简单滤除离框较远的干扰
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    left_area = thresh[:, 0:319]
    right_area = thresh[:, 320:640]
    _, cntsl0, hierarchy = cv2.findContours(left_area, cv2.RETR_TREE,
                                            cv2.CHAIN_APPROX_SIMPLE)
    _, cntsr0, hierarchy = cv2.findContours(right_area, cv2.RETR_TREE,
                                            cv2.CHAIN_APPROX_SIMPLE)

    for cnt in cntsl0:
        area = cv2.contourArea(cnt)
        if area > cntsr0_area:
            cntsl.append(cnt)

    for cnt in cntsr0:
        area = cv2.contourArea(cnt)
        if area > cntsl0_area:
            cntsr.append(cnt)

    if not (cntsl == []):
        for c_l in cntsl:
            Ml = cv2.moments(c_l)  # 求图形的矩
            cXl = int((Ml["m10"] + 1) / (Ml["m00"] + 1))
            cYl = int((Ml["m01"] + 1) / (Ml["m00"] + 1))
            cv2.circle(framel, (cXl, cYl), 7, (0, 255, 255), -1)
            cv2.drawContours(framel, [c_l], -1, (0, 255, 0), 2)
    if not (cntsr == []):
        for c_r in cntsr:
            Mr = cv2.moments(c_r)  # 求图形的矩
            cXr = int((Mr["m10"] + 1) / (Mr["m00"] + 1))
            cYr = int((Mr["m01"] + 1) / (Mr["m00"] + 1))
            cv2.circle(framer, (cXr, cYr), 7, (255, 255, 255), -1)
            cv2.drawContours(framer, [c_r], -1, (0, 255, 0), 2)

    if cntsl == [] and not (cntsr == []):
        control_AUV('left_translation')
        print('向左转')
    elif not (cntsl == []) and cntsr == []:
        control_AUV('right_translation')
        print('向右转')
    elif not (cntsl == []) and not (cntsr == []):
        if abs(cYl - cYr) < 40:
            Y_flag = True
        else:
            Y_flag = False

        if Y_flag:
            if (cXl + cXr + 320) / 2 > 390:
                control_AUV('left_translation')
                print('向左转')
            if (cXl + cXr + 320) / 2 < 250:
                control_AUV('right_translation')
                print('向右转')
            if (cXl + cXr + 320) / 2 < 390 and (cXl + cXr + 320) / 2 > 250:
                control_AUV('go')
                print('直走')
        else:
            if cYl > cYr:
                control_AUV('left_translation')
                print('向左转')
            elif cYl < cYr:
                control_AUV('right_translation')
                print('向右转')

    elif cntsl == [] and cntsr == []:
        control_AUV('go')
        print('直走')




def action():
    global act
    level = 2

    pid1.update(feedback_value=300)        # 待修改横坐标
    output = pid1.output
    speed = output             #差速由PID得到
    Time0 = speed                     #差速转推进器运动时间
    Time = 16 * int(Time0)

    bit = Time + level
    act = bit

    return act


#标志位计数函数
def flag_count():
    global data_count

    data_count = data_count + 1
    if data_count >= 5:
        data_count = 0


#AUV球求识别函数
def Auv_ball_detect(frame):
    findball_flag = False
    blurred = cv2.GaussianBlur(frame, (11, 11), 0)
    hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)

    mask = cv2.inRange(hsv, ballLower, ballUpper)
    mask = cv2.erode(mask, None, iterations=2)
    mask = cv2.dilate(mask, None, iterations=2)
    cnts = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL,
                            cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[1]
    center = None

    if len(cnts) > 0:
        c = max(cnts, key=cv2.contourArea)
        ((x, y), radius) = cv2.minEnclosingCircle(c)
        M = cv2.moments(c)
        center = (int(M["m10"] / M["m00"]), int(M["m01"] / M["m00"]))

        if radius > 10:
            cv2.circle(frame, (int(x), int(y)), int(radius),
                       (0, 255, 0), 2)
            cv2.circle(frame, center, 5, (255, 255, 255), -1)
        findball_flag = True

    pts.appendleft(center)
    for i in range(1, len(pts)):
        if pts[i - 1] is None or pts[i] is None:
            continue

        thickness = int(np.sqrt(buff / float(i + 1)) * 2.5)
        cv2.line(frame, pts[i - 1], pts[i], (255, 0, 0), thickness)

    return frame,findball_flag,center


def order_points(pts):
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]

    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]
    rect[3] = pts[np.argmax(diff)]

    return rect

#框追踪类，用于追踪已经识别到的框
class CentroidTracker():
    def __init__(self, maxDisappeared=300):
        self.nextObjectID = 0
        self.objects = OrderedDict()
        self.disappeared = OrderedDict()
        self.maxDisappeared = maxDisappeared

    def register(self, centroid):
        self.objects[self.nextObjectID] = centroid
        self.disappeared[self.nextObjectID] = 0
        self.nextObjectID += 1

    def deregister(self, objectID):
        del self.objects[objectID]
        del self.disappeared[objectID]

    def update(self, rects):
        if len(rects) == 0:
            for objectID in self.disappeared.keys():
                self.disappeared[objectID] += 1
                if self.disappeared[objectID] > self.maxDisappeared:
                    self.deregister(objectID)
            return self.objects
        inputCentroids = np.zeros((len(rects), 2), dtype="int")

        for (i, (startX, startY, endX, endY)) in enumerate(rects):
            cX = int((startX[0] + endX[0]) / 2.0)
            cY = int((startY[1] + endY[1]) / 2.0)
            inputCentroids[i] = (cX, cY)
        if len(self.objects) == 0:
            for i in range(0, len(inputCentroids)):
                self.register(inputCentroids[i])
        else:
            objectIDs = list(self.objects.keys())
            objectCentroids = list(self.objects.values())
            D = dist.cdist(np.array(objectCentroids), inputCentroids)
            rows = D.min(axis=1).argsort()
            cols = D.argmin(axis=1)[rows]
            usedRows = set()
            usedCols = set()
            for (row, col) in zip(rows, cols):
                if row in usedRows or col in usedCols:
                    continue
                objectID = objectIDs[row]
                self.objects[objectID] = inputCentroids[col]
                self.disappeared[objectID] = 0
                usedRows.add(row)
                usedCols.add(col)
            unusedRows = set(range(0, D.shape[0])).difference(usedRows)
            unusedCols = set(range(0, D.shape[1])).difference(usedCols)
            if D.shape[0] >= D.shape[1]:
                for row in unusedRows:
                    objectID = objectIDs[row]
                    self.disappeared[objectID] += 1
                    if self.disappeared[objectID] > self.maxDisappeared:
                        self.deregister(objectID)
            else:
                for col in unusedCols:
                    self.register(inputCentroids[col])
        return self.objects

#框最终函数
ct = CentroidTracker()
def Target_Tracking(frame, box):
    rects = []
    rects.append(box.astype("int"))
    objects = ct.update(rects)
    for (objectID, centroid) in objects.items():
        text = "ID {}".format(objectID)
        cv2.putText(frame, text, (centroid[0] - 10, centroid[1] - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        cv2.circle(frame, (centroid[0], centroid[1]), 4, (0, 255, 0), -1)

    return frame, objectID, centroid


#PID控制类
class PID:
    """PID Controller
    """

    def __init__(self, P=0.2, I=0.0, D=0.0):

        self.Kp = P
        self.Ki = I
        self.Kd = D

        self.sample_time = 0.00
        self.current_time = time.time()
        self.last_time = self.current_time

        self.clear()

    def clear(self):
        """Clears PID computations and coefficients"""
        self.SetPoint = 0.0

        self.PTerm = 0.0
        self.ITerm = 0.0
        self.DTerm = 0.0
        self.last_error = 0.0

        # Windup Guard
        self.int_error = 0.0
        self.windup_guard = 20.0

        self.output = 0.0

    def update(self, feedback_value):
        """Calculates PID value for given reference feedback
        .. math::
            u(t) = K_p e(t) + K_i \int_{0}^{t} e(t)dt + K_d {de}/{dt}
        .. figure:: images/pid_1.png
           :align:   center
           Test PID with Kp=1.2, Ki=1, Kd=0.001 (test_pid.py)
        """
        error = self.SetPoint - feedback_value

        self.current_time = time.time()
        delta_time = self.current_time - self.last_time
        delta_error = error - self.last_error

        if (delta_time >= self.sample_time):
            self.PTerm = self.Kp * error
            self.ITerm += error * delta_time

            if (self.ITerm < -self.windup_guard):
                self.ITerm = -self.windup_guard
            elif (self.ITerm > self.windup_guard):
                self.ITerm = self.windup_guard

            self.DTerm = 0.0
            if delta_time > 0:
                self.DTerm = delta_error / delta_time

            # Remember last time and last error for next calculation
            self.last_time = self.current_time
            self.last_error = error

            self.output = self.PTerm + (self.Ki * self.ITerm) + (self.Kd * self.DTerm)

    def setKp(self, proportional_gain):
        """Determines how aggressively the PID reacts to the current error with setting Proportional Gain"""
        self.Kp = proportional_gain

    def setKi(self, integral_gain):
        """Determines how aggressively the PID reacts to the current error with setting Integral Gain"""
        self.Ki = integral_gain

    def setKd(self, derivative_gain):
        """Determines how aggressively the PID reacts to the current error with setting Derivative Gain"""
        self.Kd = derivative_gain

    def setWindup(self, windup):
        """Integral windup, also known as integrator windup or reset windup,
        refers to the situation in a PID feedback controller where
        a large change in setpoint occurs (say a positive change)
        and the integral terms accumulates a significant error
        during the rise (windup), thus overshooting and continuing
        to increase as this accumulated error is unwound
        (offset by errors in the other direction).
        The specific problem is the excess overshooting.
        """
        self.windup_guard = windup

    def setSampleTime(self, sample_time):
        """PID that should be updated at a regular interval.
        Based on a pre-determined sampe time, the PID decides if it should compute or return immediately.
        """
        self.sample_time = sample_time

# def pid(feedback):
#     PID.update(feedback_value=300)                    #待修改
#     output = pid1.output
#     return output




#工控机摄像头读取函数
#      无
#frame0:前置摄像头画面  frame1:下置摄像头画面
# def Camera_Capture():
#     ret, frame0 = cap1.read()
#     ret, frame1 = cap.read()
#     return frame0,frame1

#改变颜色阈值函数
#    无
#    无（纯全局变量操作）
def change_colorvalue():
    global red_lower
    global green_lower
    global bule_lower
    global red_higher
    global green_higher
    global bule_higher
    if SEARCH_count >= SEARCH_count_max:
        green_lower = green_lower - 5
        bule_lower = bule_lower - 5
        red_higher = red_higher + 5
        green_higher = green_higher + 5
        bule_higher = bule_higher + 5

#用于退出整个程序
#  无
#退出标志位
def Break_flag():
    break_flag = False
    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break_flag = True
    return break_flag

#用于控制计数。识别要快，运动要慢、准
#计数器名称
#     无
def COUNT(name):
    global order_count1
    global order_count2
    global order_count3
    global order_count4
    if name=='count1':
        enable_flag = False
        order_count1 = order_count1 + 1
        if order_count1>=count_max1:
            order_count1 = 0
            enable_flag = True
        return enable_flag
    if name=='count2':
        enable_flag = False
        order_count2 = order_count2 + 1
        if order_count2 >= count_max2:
            order_count2 = 0
            enable_flag = True
        return enable_flag
    if name=='count3':
        enable_flag = False
        order_count3 = order_count3 + 1
        if order_count3 >= count_max3:
            order_count3 = 0
            enable_flag = True
        return enable_flag
    if name=='count4':
        enable_flag = False
        order_count4 = order_count4 + 1
        if order_count4 >= count_max4:
            order_count4 = 0
            enable_flag = True
        return enable_flag





#寻找模式
#frame0:前置摄像头画面 frame1:下置摄像头画面
#SEARCH_enable:Search放行标志位
def SEARCH_MODEL(Camnum,frame):
    global SEARCH_count
    global SEARCH_count_time
    global SEARCH_count_time_max
    global Rect_Tarnum, Line_Tarnum
    SEARCH_enable = False
    Franum, thresh = Frame_Preprocess(Camnum, frame)
    SEARCH_count = SEARCH_count + 1
    if Franum == 0:
        Rect_Tarnum, data0, frame = Rect_Target_recognition(thresh,frame)
        if COUNT('count1') and (not (Rect_Tarnum)):
            x = x0[0]
            y = y0[0]
            theta = theta0[0]
            od_r = search(theta, x, y)
            control_AUV(od_r)
        if Rect_Tarnum:
            SEARCH_enable = True
    if Franum == 1:
        Line_Tarnum, data1, frame = Line_Target_recognition(thresh,frame)
        if Line_Tarnum:
            SEARCH_enable = True

    if SEARCH_count >= SEARCH_count_max:
        change_colorvalue()
        SEARCH_count_time = SEARCH_count_time + 1
    if SEARCH_count_time >= SEARCH_count_time_max:
        print('特殊运动')


    return SEARCH_enable


def ADJUST_MODEL(Camnum, frame):
    global ADJUST_count
    global ADJUST_count_max
    global ADJUST_count_time
    global ADJUST_count_time_max
    global act
    Rect_Aim_flag = False
    Line_Aim_flag = False
    ADJUST_enable = False
    Franum, thresh = Frame_Preprocess(Camnum, frame)
    if Franum == 0:
        Rect_Tarnum, data0, frame = Rect_Target_recognition(thresh,frame)
        if not(data0 is None):
            box = data0[4]
            frame0, objectID, centroid = Target_Tracking(frame, box)
            if centroid[0] < left_min and COUNT('count1'):
                control_AUV('left_translation')
                print('左平移')
            if centroid[0] > right_max and COUNT('count1'):
                control_AUV('right_translation')
                print('右平移')
            if centroid[0] > left_min and centroid[0] < right_max:
                Rect_Aim_flag = True
            Trustnum = Rect_Trust(data0)
            if (Rect_Aim_flag and Trustnum):
                ADJUST_enable = True
    if Camnum == 1:
        Line_Tarnum, data1, frame = Line_Target_recognition(thresh,frame)
        if not(data1 is None):
            angle = data1[2]
            if angle < guide_line_enable_lower and COUNT('count2'):
                control_AUV('left_rotation')
                print('向左转')
            if angle > guide_line_enable_higher and COUNT('count2'):
                control_AUV('right_rotation')
                print('向右转')
            if angle > guide_line_enable_lower and angle < guide_line_enable_higher:
                Line_Aim_flag = True
            if Line_Aim_flag:
                ADJUST_enable = True


    ADJUST_count = ADJUST_count + 1
    if ADJUST_count >= ADJUST_count_max:
        print('减小调整力度')                              #待协商
        ADJUST_count_time = ADJUST_count_time + 1
    if ADJUST_count_time>=ADJUST_count_time_max:
        ADJUST_enable = True                               #如果一直都调不好，就直接过框

    return ADJUST_enable


def CROSS_MODEL(frame):
    global line_count
    global CROSS_count
    global CROSS_count_max
    global corss_Rect_flag
    CROSS_count_flag = False
    cross_Rect(frame)
    CROSS_count = CROSS_count + 1
    if CROSS_count>=CROSS_count_max:
        CROSS_count_flag = True

    return CROSS_count_flag



def SEARCHBALL_MODEL(frame1):
    frame1, findball_flag,center = Auv_ball_detect(frame1)
    if findball_flag:
        print('寻球运动')
    else:
        dx = Reference_coor[0] - x0[0]
        dy = Reference_coor[1] - y0[0]

def read_fromMCU():
    msg = ser.read(3)
    yaw = msg[2]
    return yaw




#PID控制参数
P = 0.1
I = 0.01
D = 0.005
pid1 = PID(P,I,D)
pid1.SetPoint=320
pid1.setSampleTime(0.5)



# camera = PiCamera()
# camera.resolution = (640,480)
# camera.framerate = 32
# rawCapture = PiRGBArray(camera, size=(640,480))


cap = cv2.VideoCapture(0)  # 下置摄像头
cap.set(3, 640)  # 设置分辨率
cap.set(4, 360)

cap1 = cv2.VideoCapture(2)  # 前置摄像头
cap1.set(3, 640)  # 设置分辨率
cap1.set(4, 480)

MODEL_section_flag = 'SEARCH'

if __name__ == "__main__":
    while True:
        Camnum, frame = Camera_switch()
        if MODEL_section_flag=='SEARCH':
            SEARCH_enable = SEARCH_MODEL(Camnum,frame)
            cv2.imshow("frame", frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break
            if SEARCH_enable:
                MODEL_section_flag = 'ADJUST'
        elif MODEL_section_flag=='ADJUST':
            ADJUST_enable = ADJUST_MODEL(Camnum,frame)
            cv2.imshow("frame", frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break
            if ADJUST_enable:
                MODEL_section_flag='CROSS'
        elif MODEL_section_flag=='CROSS':
            CROSS_count_flag = CROSS_MODEL(frame)
            cv2.imshow("frame", frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break
            if CROSS_count_flag:
                MODEL_section_flag = 'SEARCH'

    cv2.destroyAllWindows()
    sys.exit()
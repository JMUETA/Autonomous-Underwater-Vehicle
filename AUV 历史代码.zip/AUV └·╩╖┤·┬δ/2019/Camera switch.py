def Camera_switch(frame,Trunum):                              #摄像头切换
    global Count
    Count = Count + 1
    if Count > 60:                                             #1-30帧为前置摄像头，31-60为下置摄像头
        Count = 0
    if Trunum == True:                                          #过框时保持打开前置摄像头
        frame = frame.array
        Camnum = 0
    else:                                                       #其他时候摄像头一直切换
        if Count <= 30:
            frame = frame.array
            Camnum = 0
        else:
            ret, frame = cap.read()
            Camnum = 1
    return Camnum,frame
import scipy.io as sio
import serial
import sys
from numpy import *
import deg2rad
import time
import sim_stand as ss


#def wa():
data_l = sio.loadmat(r'C:\Users\96317\Desktop\Math\13.mat')
data_r = sio.loadmat(r'C:\Users\96317\Desktop\Math\12.mat')
foot = 1
con = 1
while(con):
    if foot == 1:
        data_th = data_l.get('data1_l')
        data_phi = data_l.get('data2_l')
        data_psi = data_l.get('data3_l')
    else:
        data_th = data_r.get('data1_r')
        data_phi = data_r.get('data2_r')
        data_psi = data_r.get('data3_r')


    head = [0xff,0xff]
    body = [0xfe,0x4f,0x83,0x2a,0x04]


    for i in range(len(data_th)):
        [ID13,ID11,ID9,ID8,ID10,ID12,ID3,no_el_l,ID2,no_el_r,no_nk] = data_th[i]
        [ID15,ID7,ID6,ID14,ID5,ID4] = data_phi[i]
        [no_hp_l,np_hp_r,ID1] = data_psi[i]

        ID1_data = int(511 + round((180/pi*ID1)*3.41))
        ID2_data = int(511 - round((180/pi*ID2)*3.41))
        ID3_data = int(511 + round((180/pi*ID3)*3.41))#
        ID4_data = int(800 - round((180/pi*ID4)*3.41))#
        ID5_data = int(250 - round((180/pi*ID5)*3.41))#
        ID6_data = int(500 - round((180/pi*ID6)*3.41))#
        ID7_data = int(500 - round((180/pi*ID7)*3.41))#
        ID8_data = int(625 + round((180/pi*ID8)*3.41))#
        ID9_data = int(390 - round((180/pi*ID9)*3.41))
        ID10_data = int(300 + round((180/pi*ID10)*3.41))#
        ID11_data = int(700 - round((180/pi*ID11)*3.41))
        ID12_data = int(500 - round((180/pi*ID12)*3.41))
        ID13_data = int(540 + round((180/pi*ID13)*3.41))#
        ID14_data = int(522 - round((180/pi*ID14*0.5)*3.41))#
        ID15_data = int(620 - round((180/pi*ID15*0.5)*3.41))#

        ID1_msg = [1,(ID1_data&65280)>>8,ID1_data&255,1,60]
        ID2_msg = [2,(ID2_data&65280)>>8,ID2_data&255,1,60]
        ID3_msg = [3, (ID3_data & 65280) >> 8, ID3_data & 255, 1, 60]
        ID4_msg = [4, (ID4_data & 65280) >> 8, ID4_data & 255, 1, 60]
        ID5_msg = [5, (ID5_data & 65280) >> 8, ID5_data & 255, 1, 60]
        ID6_msg = [6, (ID6_data & 65280) >> 8, ID6_data & 255, 1, 60]
        ID7_msg = [7, (ID7_data & 65280) >> 8, ID7_data & 255, 1, 60]
        ID8_msg = [8, (ID8_data & 65280) >> 8, ID8_data & 255, 1, 60]
        ID9_msg = [9, (ID9_data & 65280) >> 8, ID9_data & 255, 1, 60]
        ID10_msg = [10, (ID10_data & 65280) >> 8, ID10_data & 255, 1, 60]
        ID11_msg = [11, (ID11_data & 65280) >> 8, ID11_data & 255, 1, 60]
        ID12_msg = [12, (ID12_data & 65280) >> 8, ID12_data & 255, 1, 60]
        ID13_msg = [13, (ID13_data & 65280) >> 8, ID13_data & 255, 1, 60]
        ID14_msg = [14, (ID14_data & 65280) >> 8, ID14_data & 255, 1, 60]
        ID15_msg = [15, (ID15_data & 65280) >> 8, ID15_data & 255, 1, 60]

        parameter = ID1_msg + ID2_msg + ID3_msg + ID4_msg + ID5_msg + ID6_msg + ID7_msg + ID8_msg + ID9_msg + ID10_msg + ID11_msg + ID12_msg + ID13_msg + ID14_msg + ID15_msg

        check_sum = sum(body + parameter)
        if check_sum > 255:
            check_sum = ~(check_sum) & 255

        msg = head + body + parameter
        msg.append(check_sum)
        msg = bytearray(msg)

        time.sleep(0.1)

        try:
            portx = "COM11"
            bps = 115200
            timex = 0.1

            ser = serial.Serial(portx, bps, timeout=timex)
            result = ser.write(msg)
            ser.close()
            foot = not(foot)

        except Exception as e:
            print("--异常--:", e)

        







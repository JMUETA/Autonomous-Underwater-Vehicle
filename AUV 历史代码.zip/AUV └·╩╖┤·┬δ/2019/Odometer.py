
import numpy as np
import turtle as T


def LINE(x0,y0):
    x = x0
    y = y0
    for i in range(len(x0)):
        T.goto(x[i], y[i])

    T.setup(400, 700, 0, 0)
    T.pensize(5)  # 设置笔的宽度
    T.pencolor("red")  # 设置笔的颜色
    T.seth(90)  # 设置笔的起始角度


b = 0.5
x0 = [0]
y0 = [0]
angle = [1.57]
def Odometer(dl,dr):
    global x0
    global y0
    global angle
    x = x0[-1]
    y = y0[-1]
    theta = angle[-1]
    dx = (dr+dl)*np.cos(theta+(dr-dl)/2*b)/2
    dy = (dr+dl)*np.sin(theta+(dr-dl)/2*b)/2
    dtheta = (dr-dl)/b
    x1 = x + dx
    y1 = y + dy
    theta1 = theta + dtheta
    x0.append(x1)
    y0.append(y1)
    angle.append(theta1)
    return 0

while True:
    dl = input("dl:")
    dr = input("dr:")
    dl = eval(dl)
    dr = eval(dr)
    Odometer(dl, dr)
    LINE(x0, y0)
    if dl=='q':
        break



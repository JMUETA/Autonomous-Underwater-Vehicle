def control_AUV(od_r,act):
    head_bit = [0xaa, 0x55, 0x03]                 #前三个字节为包头
    follow_bit = [0x08]
    control_bit = [0x00]                          #控制字节有效值：0-255
    time_level_bit = [0x00]                        #高四位为推进器动作时间，低四位为推进器推力的级数

    if od_r == 'go':                             #前进：222-255
        control_bit = [0xec]
        time_level_bit = [0x32]
        dl = 0.1                              #前进0.1m
        dr = 0.1
        print('go')
    if od_r == 'left_translation':                             #左平移：35-90
        control_bit = [0x46]
        time_level_bit = [0x32]
        AUV_dx = -0.1
        print('left_translation')
    if od_r == 'left_rotation':                             #左旋转：91-127
        control_bit = [0x6e]
        time_level_bit = [0x32]
        dtehta = 0.4
        print('left_rotation')
    if od_r == 'right_translation':                             #右平移：128-175
        control_bit = [0xa0]
        time_level_bit = [0x32]
        AUV_dx = -0.1
        print('right_translation')
    if od_r == 'right_rotation':                             #右旋转；176-221
        control_bit = [0xd7]
        time_level_bit = [0x32]
        AUV_dx = -0.4
        print('right_rotation')
    if od_r == 'back':                             #后退：0-34
        control_bit = [0x14]
        time_level_bit = [0x32]
        dl = -0.1                              #后退0.1m
        dr = -0.1
        print('back')

    elif action_count == 1 and AUV_dtheta >= 0:
        control_bit = [0x6e]
        time_level_bit = act
    elif action_count == 1 and AUV_dtheta < 0:
        control_bit = [0xd7]
        time_level_bit = act


    elif action_count == 32 and AUV_dx >= 0:
        control_bit = [0xa0]
        time_level_bit = act
    elif action_count == 32 and AUV_dx < 0:
        control_bit = [0x46]
        time_level_bit = act



    parameter = head_bit + follow_bit + control_bit + time_level_bit
    check_sum = sum(parameter)
    check_sum = [check_sum & 255]

    msg = head_bit + parameter + check_sum
    msg = bytearray(msg)
    try:                                          #发送串口指令 与单片机通信
        ser.write(msg)
    except Exception as e:
        print("--异常--:", e)
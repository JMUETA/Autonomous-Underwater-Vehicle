import cv2
import numpy as np
import sys

cap = cv2.VideoCapture(2)
cap.set(3, 640)  # 设置分辨率
cap.set(4, 480)

while True:
    ret, frame = cap.read()
    cv2.imshow('frame',frame)
    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break
cv2.destroyAllWindows()
sys.exit()

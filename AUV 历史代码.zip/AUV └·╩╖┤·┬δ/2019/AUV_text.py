#_*_coding:utf-8_*
import sys
import cv2
import serial
import time
import threading

#cap = cv2.VideoCapture(vfile)
cap1 = cv2.VideoCapture(0)


def get_fg_from_hue(img, margin):
    FRACTION_AS_BLANK = 0.003
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    dark = hsv[..., 2] < 32
    hsv[..., 0][dark] = 128

    dark = hsv[..., 1] < 50
    hsv[..., 0][dark] = 128

    mask = cv2.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
    mask2 = cv2.inRange(hsv[..., 0], np.array((180-margin)), np.array((180)))

    mask = cv2.bitwise_or(mask, mask2)

    if cv2.countNonZero(mask) < mask.shape[0]*mask.shape[1]*FRACTION_AS_BLANK:
        mask.fill(0)

    return [mask, hsv[...,0]]


def get_fg_from_hue_watershed_saturation(img, margin):
    mask, hue = get_fg_from_hue(img, margin)

    mask_bg = cv2.inRange(hue, 60, 90)
    mask_bg = cv2.bitwise_or(mask_bg, cv2.inRange(hue,128,129))

    markers = np.zeros(mask.shape, np.int32)
    markers[mask == 255] = 1
    markers[mask_bg == 255] = 2

    cv2.watershed(img, markers)
    mask[markers == 1] = 255

    # img2 = img.copy()
    # img2[markers == 1] = 255
    # cv.imshow("1", img2)
    #
    # img2 = img.copy()
    # img2[markers == 2] = 255
    # cv.imshow("2", img2)
    #
    # img2 = img.copy()
    # img2[markers == -1] = 255
    # cv.imshow("3", img2)

    return [mask, hue]


while True:
    #status, img = cap.read()
    ret, frame = cap1.read()
    #cv2.boxFilter(img, -1, (5, 5), img)  # 块滤波器滤波
    thresh = get_fg_from_hue_watershed_saturation(frame,20)
    thresh = cv2.medianBlur(thresh, 5)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    cnts3 = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)  # findContours寻找轮廓，寻找最小外接矩形
    cnts3 = cnts3[1]
    if not (cnts3 == []):
        for c_3 in cnts3:
            M = cv2.moments(c_3)  # 求图形的矩
            cX_3 = int((M["m10"] + 1) / (M["m00"] + 1))
            cv2.drawContours(frame, [c_3], -1, (0, 255, 0), 2)

    cv2.imshow("capture1", frame)
    if cv2.waitKey(1) & 0XFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
sys.exit()
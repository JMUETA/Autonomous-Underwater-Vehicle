import time
def Time():
    a=6
    if 0 < a < 5:
        print ('Start : ', time.ctime())
        time.sleep( 5 )
        print ('End : ', time.ctime())
    else:
        time.sleep(5)
        print('123')

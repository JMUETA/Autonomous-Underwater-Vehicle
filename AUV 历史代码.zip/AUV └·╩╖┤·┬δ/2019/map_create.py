from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2
import logging
import sys
import numpy as np
import serial
import threading


FORCAL = 600                                            #距离函数设定的焦距，为定值
Know_Distance = 30.0                                    # 已知距离（定值）
Know_Width = 25.2

cX_container = []
minAreax_container = []

x0 = 0
y0 = 0
auv_local = [[x0,y0]]

Rect_point = []
Line_point = []

portx = '/dev/ttyUSB0'
bps = 9600
timex = 0.01
ser = serial.Serial(portx, bps, timeout=timex)

portx1 = '/dev/ttyUSB2'
bps1 = 115200
ser1 = serial.Serial(portx1, bps1, timeout=timex)

def get_fg_from_hue_watershed_saturation(img, margin):
    mask, hue = get_fg_from_hue(img, margin)

    mask_bg = cv2.inRange(hue, 60, 90)
    mask_bg = cv2.bitwise_or(mask_bg, cv2.inRange(hue,128,129))

    markers = np.zeros(mask.shape, np.int32)
    markers[mask == 255] = 1
    markers[mask_bg == 255] = 2

    cv2.watershed(img, markers)
    mask[markers == 1] = 255

    # img2 = img.copy()
    # img2[markers == 1] = 255
    # cv.imshow("1", img2)
    #
    # img2 = img.copy()
    # img2[markers == 2] = 255
    # cv.imshow("2", img2)
    #
    # img2 = img.copy()
    # img2[markers == -1] = 255
    # cv.imshow("3", img2)

    return mask


def get_fg_from_hue(img, margin):
    FRACTION_AS_BLANK = 0.003
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    dark = hsv[..., 2] < 32
    hsv[..., 0][dark] = 128

    dark = hsv[..., 1] < 50
    hsv[..., 0][dark] = 128

    mask = cv2.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
    mask2 = cv2.inRange(hsv[..., 0], np.array((180-margin)), np.array((180)))

    mask = cv2.bitwise_or(mask, mask2)

    if cv2.countNonZero(mask) < mask.shape[0]*mask.shape[1]*FRACTION_AS_BLANK:
        mask.fill(0)

    return [mask, hsv[...,0]]



def guide_line_detect(img, area_th=5000, aspect_th=0.8):
    '''

    TODO：部分时候很靠近边框时，会检测到框
    :param img:
    :param area_th:
    :param aspect_th:
    :return:
    '''
    ASPECT_RATIO_MIN = 0.15 #重要参数
    MAX_CONTOUR_NUM = 6 #如果出现更多的轮廓，不进行处理。这是为了对抗白平衡

    mask = get_fg_from_hue_watershed_saturation(img, 20)
    _, contours, hierarchy = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # 目前对自动白平衡的处理，太多轮廓则直接返回
    candidates = []
    candidates_y = []
    if len(contours) < MAX_CONTOUR_NUM:
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > area_th:  # 关键参数
                (x1, y1), (w1, h1), angle1 = cv2.minAreaRect(cnt)
                minAreaRect_area = w1 * h1
                aspect_ratio = float(w1) / h1
                if aspect_ratio > 1:
                    aspect_ratio = 1.0 / aspect_ratio
                    angle1 = np.mod(angle1 + 90, 180)

                extent = float(area) / minAreaRect_area

                hull = cv2.convexHull(cnt)
                hull_area = cv2.contourArea(hull)
                solidity = float(area) / hull_area

                (x2, y2), (MA, ma), angle2 = cv2.fitEllipse(cnt)
                if angle2 > 90:
                    angle2 -= 180

                logging.debug('area %f,aspect_ratio %f,extent %f,solidity %f,angle1 %f,angle2 %f' % (area, aspect_ratio, extent, solidity, angle1, angle2))

                if aspect_ratio > aspect_th or aspect_ratio < ASPECT_RATIO_MIN  or extent < 0.7 or solidity < 0.7 or abs(angle1-angle2)>30:
                    break


                # img2 = img.copy()
                # contour_info(img2,area,aspect_ratio,extent,solidity,angle1,angle2,((x2, y2), (MA, ma), angle2))
                # cv.drawContours(img2, [cnt], 0, (0, 255, 0), 3)
                # show_img(img2)

                candidates.append((x1,y1,angle2))                       #目前这个组合是比较好的。
                candidates_y.append(y1)

        nc = len(candidates)
        if nc == 0:
            return None
        elif nc == 1:
            return candidates[0]
        else:
            logging.debug('multiple')

            idx = np.argmax(np.array(candidates_y))
            return candidates[idx]


def distance_to_camera(width, forcal, perwidth):                # 距离计算
    return ((width * forcal)*0.3048) / (12*perwidth)



def att_angle():
    try:
        att = ser1.read(5)
        if len(att)>5:
            return att[3]
    except Exception as e:
        print("--异常--:", e)
    return 90

def angle2rad(theta):
    w = (theta*np.pi)/180
    return w


def control_AUV(od_r):
    if od_r == 'left':
        ser.write(b'\xaa\x55\x02\x01\x02')
        #print('left')
    if od_r == 'right':
        ser.write(b'\xaa\x55\x02\x02\x02')
        #print('right')
    if od_r == 'up':
        ser.write(b'\xaa\x55\x02\x03\x02')
        #print('up')
    if od_r == 'down':
        ser.write(b'\xaa\x55\x02\x04\x02')
        #print('down')
    if od_r == 'go':
        ser.write(b'\xaa\x55\x02\x05\x02')
        #print('go')
    if od_r == 'back':                        #或存在问题
        ser.write(b'\xaa\x55\x02\x06\x02')
        #print('back')
    if od_r == 'stop':
        ser.write(b'\xaa\x55\x02\x07\x02')
        #print('stop')


def guide_line_turn(angle,yaw):                                             #判断识别到引导线时转向函数
    if (-0.4<angle) and angle<0.4:
        x = np.cos(yaw)
        y = np.sin(yaw)
        [x1,y1] = [x+auv_local[-1][0],y+auv_local[-1][1]]
        now_point = [x1,y1]
        auv_local.append(now_point)
        return 'go'
    elif angle<-0.4:
        return 'left'
    elif angle>0.4:
        return 'right'

def rect_turn(X,yaw):
    if X<280:
        x = np.cos(yaw)
        y = np.sin(yaw)
        [x1, y1] = [x + auv_local[-1][0], y + auv_local[-1][1]]
        now_point = [x1, y1]
        auv_local.append(now_point)
        control_AUV('left')
    elif X>360:
        control_AUV('right')
    else:
        control_AUV('go')


def AUV_local(yaw,rank):
    auv_local[0] = auv_local[0]+rank*np.cos(yaw)
    auv_local[1] = auv_local[1]+rank*yaw*np.sin(yaw)
    return auv_local

def add_judege(X,Y):
    now_point = [X,Y]
    itertime = len(Rect_point)
    if itertime<1:
        return True
    for i in range(itertime):
        dis = np.sqrt(np.sum(np.square(Rect_point[i] - now_point)))
        if dis<1:                             #待调
            return False
    return True




def Add_Rect_point(auv_local,metre,yaw,cX,Rect_width):
    bias = (0.6*(cX-160))/Rect_width                      #偏差
    X = auv_local[0] + metre*np.cos(yaw) + bias
    Y = auv_local[1] + metre*np.sin(yaw)
    flag = add_judege(X,Y)
    now_point = [X,Y]
    if flag:
        Rect_point.append(now_point)              #全局变量，存储框的坐标

def Add_Line_point(auv_local):
    X = auv_local[-1][0]
    Y = auv_local[-1][1]
    flag = add_judege(X,Y)
    now_point = [X,Y]
    if flag:
        Line_point.append(now_point)              #全局变量，存储线的坐标


def Rect_Trust(cX,minArea_x):
    if cX-minArea_x>100:
        return False
    if len(cX_container)>5 and len(minAreax_container)>5:
        var_cX = np.var(cX_container)
        var_min = np.var(minAreax_container)
        if var_cX<4 and var_min<4:                            #方差，待测量
            return True
    return False

def corss_Rect(flag,cX):
    while flag:
        for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
            frame1 = frame.array
            thresh = get_fg_from_hue_watershed_saturation(frame1, 20)
            thresh = cv2.medianBlur(thresh, 5)
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (9, 9))  # 形态学开运算，简单滤除离框较远的干扰
            thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
            left_area = thresh[0:159,:]
            right_area = thresh[160:320,:]
            _, cntsl, hierarchy = cv2.findContours(left_area, cv2.RETR_TREE,
                                                   cv2.CHAIN_APPROX_SIMPLE)
            _, cntsr, hierarchy = cv2.findContours(right_area, cv2.RETR_TREE,
                                                   cv2.CHAIN_APPROX_SIMPLE)
            if not (cntsl == []):
                for c_l in cntsl:
                    Ml = cv2.moments(c_l)  # 求图形的矩
                    cXl = int((Ml["m10"] + 1) / (Ml["m00"] + 1))
            if not (cntsr == []):
                for c_r in cntsr:
                    Mr = cv2.moments(c_r)  # 求图形的矩
                    cXr = int((Mr["m10"] + 1) / (Mr["m00"] + 1))
            if cntsl==[] and not(cntsr==[]):
                control_AUV('left')
            elif not(cntsl==[]) and cntsr==[]:
                control_AUV('right')
            elif not(cntsl==[]) and not(cntsr==[]):
                if (cXl+cXr+159)/2 > 200:
                    control_AUV('left')
                if (cXl+cXr+159)/2 < 120:
                    control_AUV('right')










camera = PiCamera()
camera.resolution = (320,240)
camera.framerate = 32
rawCapture = PiRGBArray(camera, size=(320,240))


cap = cv2.VideoCapture(0)
cap.set(3, 320)  # 设置分辨率
cap.set(4, 240)
ret, frame = cap.read()
count = 0

if __name__ == "__main__":
    for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
        cnts2 = []
        theta = att_angle()
        yaw = angle2rad(theta)
        if count<30:
            #ret, frame1 = cap.read()
            frame1 = frame.array
            thresh = get_fg_from_hue_watershed_saturation(frame1, 20)
            thresh = cv2.medianBlur(thresh, 5)
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))  # 形态学开运算，简单滤除离框较远的干扰
            thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
            _, cnts3, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE,
                                                   cv2.CHAIN_APPROX_SIMPLE)  # findContours寻找轮廓，寻找最小外接矩形
            for cnt in cnts3:
                area = cv2.contourArea(cnt)
                if area > 20000:
                    cnts2.append(cnt)

            # print(len(cnts3))
            if not (cnts2 == []):
                for c_3 in cnts2:
                    M = cv2.moments(c_3)  # 求图形的矩
                    cX = int((M["m10"] + 1) / (M["m00"] + 1))
                    cY = int((M["m01"] + 1) / (M["m00"] + 1))
                    #cv2.circle(frame, (cX, cY), 7, (255, 255, 255), -1)
                    #cv2.drawContours(frame, [c_3], -1, (0, 255, 0), 2)
                    auv_local = AUV_local(yaw,1)

            if not (cnts2 == []):
                c = max(cnts2, key=cv2.contourArea)
                marker = cv2.minAreaRect(c)  # 得到最小外接矩形（中心(x,y),（宽，高），选住角度）
                metre = distance_to_camera(Know_Width, FORCAL, marker[1][0] + 1)
                Rect_width = marker[1][0]
                box = cv2.boxPoints(marker)  # 获取最小外接矩形的四个顶点
                box = np.int0(box)
                #cv2.drawContours(frame, [box], -1, (0, 255, 0), 2)
                #cv2.putText(frame, "%.2fm" % (metre), (frame.shape[1] - 200, frame.shape[0] - 20),
                #            cv2.FONT_HERSHEY_SIMPLEX,
                #            2.0, (0, 255, 0), 3)
                
                
                
                Add_Rect_point(auv_local,metre,yaw,cX,Rect_width)
                motion_flag = Rect_Trust(cX,marker[0][0])                      #数据信任度



            cv2.imshow("Frame", frame1)
            key = cv2.waitKey(1) & 0xFF
            # clear the stream in preparation for the next frame
            rawCapture.truncate(0)
            # if the `q` key was pressed, break from the loop
            if key == ord("q"):
                break
        else:
            #img = frame.array
            ret,img = cap.read()
            cv2.boxFilter(img, -1, (5, 5), img)

            guide_line = guide_line_detect(img)  # 检测下置摄像头是否读到引导线
            if guide_line:
                # 发现引导线，停一下
                x, y, angle = guide_line
                angle = angle / 180 * np.pi
                cv2.line(img, (int(x), int(y)), (int(x + 100 * np.sin(angle)), int(y - 100 * np.cos(angle))),
                         (0, 255, 0), 2)
                x1 = int(x + 100 * np.sin(angle))
                y1 = int(y - 100 * np.cos(angle))
                
                Add_Line_point(auv_local)        
                control_AUV(order_guide)


            # show the frame
            cv2.imshow("Frame", img)
            key = cv2.waitKey(1) & 0xFF

            # clear the stream in preparation for the next frame
            rawCapture.truncate(0)

            # if the `q` key was pressed, break from the loop
            if key == ord("q"):
                break

        count = count + 1
        if count > 120:
            count = 0

    cv2.destroyAllWindows()
    sys.exit()

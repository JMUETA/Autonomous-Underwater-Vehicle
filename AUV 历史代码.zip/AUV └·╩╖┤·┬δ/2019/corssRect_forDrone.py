import cv2
import numpy as np

portx = '/dev/ttyUSB0'
bps = 115200
timex = 0.01
ser = serial.Serial(portx, bps, timeout=timex)

def Communication_forDrone(model,data):
    if model=='Rect':
        metre = data[0]
        cX = data[1]
        cY = data[2]
        Rect_flag = [3]
        head = [0xaa,0x55,0x21,0x06]
        dis_bit = [metre*100]
        X_Hbit = [cX & 65280]
        X_Lbit = [cX & 255]
        Y_Hbit = [cY & 65280]
        Y_Lbit = [cY & 255]
        flag_bit = [Rect_flag]
        parament = dis_bit+X_Hbit+X_Lbit+Y_Hbit+Y_Lbit+flag_bit
        check_bit = sum(parament)&255
        msg = head + parament + check_bit
    if model=='Num':
        head = [0xaa,0x55,0x22,0x02]
        num_bit = [data[0]]
        flag_bit = [data[1]]
        parament = num_bit + flag_bit
        check_bit = sum(parament)&255
        msg = head + parament + check_bit

    ser.write(msg)


def Raspberry_read():
    package = ser.read(6)
    if package[0]==170 and package[1]==85:
        order = package[4]
        return order
    return 0


def get_fg_from_hue_watershed_saturation(img, margin):
    mask, hue = get_fg_from_hue(img, margin)

    mask_bg = cv2.inRange(hue, 60, 90)
    mask_bg = cv2.bitwise_or(mask_bg, cv2.inRange(hue,128,129))

    markers = np.zeros(mask.shape, np.int32)
    markers[mask == 255] = 1
    markers[mask_bg == 255] = 2

    cv2.watershed(img, markers)
    mask[markers == 1] = 255

    # img2 = img.copy()
    # img2[markers == 1] = 255
    # cv.imshow("1", img2)
    #
    # img2 = img.copy()
    # img2[markers == 2] = 255
    # cv.imshow("2", img2)
    #
    # img2 = img.copy()
    # img2[markers == -1] = 255
    # cv.imshow("3", img2)

    return mask


def get_fg_from_hue(img, margin):
    FRACTION_AS_BLANK = 0.003
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    dark = hsv[..., 2] < 32
    hsv[..., 0][dark] = 128

    dark = hsv[..., 1] < 50
    hsv[..., 0][dark] = 128

    mask = cv2.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
    mask2 = cv2.inRange(hsv[..., 0], np.array((180-margin)), np.array((180)))

    mask = cv2.bitwise_or(mask, mask2)

    if cv2.countNonZero(mask) < mask.shape[0]*mask.shape[1]*FRACTION_AS_BLANK:
        mask.fill(0)

    return [mask, hsv[...,0]]


def distance_to_camera(width, forcal, perwidth):                # 距离计算
    return ((width * forcal)*0.3048) / (12*perwidth)


def model_selection(order,frame):
    if order==0:
        return 0
    if order==1:
        data = Rect_Distinguish(frame)

    return data



def Rect_Distinguish(frame):
    data = [None,None,None,0]                                      #识别框所需要的数据.距离，cX,cY,识别标志位
    thresh, hue = get_fg_from_hue_watershed_saturation(frame, 20)
    thresh = cv2.medianBlur(thresh, 5)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))  # 形态学开运算，简单滤除离框较远的干扰
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    _, cnts3, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE,
                                           cv2.CHAIN_APPROX_SIMPLE)  # findContours寻找轮廓，寻找最小外接矩形
    for cnt in cnts3:
        area = cv2.contourArea(cnt)
        if area > 15000:
            cnts2.append(cnt)

    # print(len(cnts3))
    if not (cnts2 == []):
        for c_3 in cnts2:
            M = cv2.moments(c_3)  # 求图形的矩
            cX = int((M["m10"] + 1) / (M["m00"] + 1))
            cY = int((M["m01"] + 1) / (M["m00"] + 1))
            cv2.circle(frame, (cX, cY), 7, (255, 255, 255), -1)
            cv2.drawContours(frame, [c_3], -1, (0, 255, 0), 2)

    if not (cnts2 == []):
        c = max(cnts2, key=cv2.contourArea)
        marker = cv2.minAreaRect(c)  # 得到最小外接矩形（中心(x,y),（宽，高），选住角度）
        metre = distance_to_camera(Know_Width, FORCAL, marker[1][0] + 1)
        box = cv2.boxPoints(marker)  # 获取最小外接矩形的四个顶点
        box = np.int0(box)
        cv2.drawContours(frame, [box], -1, (0, 255, 0), 2)
        cv2.circle(frame, (int(cen_x), int(cen_y)), 7, (255, 0, 255), -1)
        if trust == 1 or trust == 0:
            cv2.putText(frame, "%.2fm" % (metre), (frame.shape[1] - 200, frame.shape[0] - 20),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        2.0, (0, 255, 0), 3)

        data[0] = metre
        data[1] = cX
        data[2] = cY
        data[3] = 1
    return data



if __name__=="__main__":
    for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
        cnts2 = []
        order = Raspberry_read()
        frame = frame.array
        data = model_selection(order, frame)
        Communication_forDrone('Rect',data)

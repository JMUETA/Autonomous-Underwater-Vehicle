'''
控制线程：控制深度，让机器平稳水平运动，不要晃动
'''

import os, time
import threading, queue
import serial
import logging

class ControllerThread(threading.Thread):
    """ A worker thread that takes directory names from a queue, finds all
        files in them recursively and reports the result.

        Input is done by placing directory names (as strings) into the
        Queue passed in dir_q.

        Output is done by placing tuples into the Queue passed in result_q.
        Each tuple is (thread name, dirname, [list of files]).

        Ask the thread to stop by calling its join() method.
    """

    # 部分参数可修改
    def __init__(self, cmd_q, result_q):
        super(ControllerThread, self).__init__()
        self.cmd_q = cmd_q
        self.result_q = result_q
        self.stoprequest = threading.Event()

        # 打开串口，AOV 修改为 COM3
        self.ser = serial.Serial('COM3')

        # 定义命令字典
        self.switch = {
            'D': self.godepth,
            'L': self.goleft,
            'R': self.goright,
            'F': self.goforward,
            'B': self.gobackward,
            'S': self.stop_thruster
        }

        # 定时器时隙
        self.timer_interval = 0.5

        # 定时器资源，可使用，修改函数 timer_func
        self.timer = threading.Timer(self.timer_interval, self.timer_func)



    def run(self):
        # As long as we weren't asked to stop, try to take new tasks from the
        # queue. The tasks are taken with a blocking 'get', so no CPU
        # cycles are wasted while waiting.
        # Also, 'get' is given a timeout, so stoprequest is always checked,
        # even if there's nothing in the queue.
        while not self.stoprequest.isSet():
            try:
                command = self.cmd_q.get(True, 0.1)  # 等待 0.1s，获取命令

                self.switch[command[0]](command[1])

                # result = 'Some result'
                # self.result_q.put(result)
            except queue.Empty:
                continue
    # 不要修改
    def join(self, timeout=None):
        self.stoprequest.set()
        self.timer.cancel()
        super(ControllerThread, self).join(timeout)

    ###############  以下需要调试修改 ##############
    # 定深
    def godepth(self, level):
        if level == '1':
            logging.debug('go depth 1')
            self.ser.write(b'\xaa\x55\x03\x0c\x08\x02')
        elif level == '2':
            logging.debug('go depth 2')
            self.ser.write(b'\xaa\x55\x03\x0c\x28\x02')
        elif level == '3':
            logging.debug('go depth 3')
            self.ser.write(b'\xaa\x55\x03\x0c\x38\x02')


    # 左转
    def goleft(self, level):
        if level == '1':
            logging.debug('go left 1')
            self.ser.write(b'\xaa\x55\x02\x01\x02')
        elif level == '2':
            logging.debug('go left 2')
            self.ser.write(b'\xaa\x55\x03\x08\x6f\x71')
        elif level == '3':
            logging.debug('go left 3')
            self.ser.write(b'\xaa\x55\x03\x08\x6f\x72')


    # 右转
    def goright(self, level):
        if level == '1':
            logging.debug('go right 1')
            self.ser.write(b'\xaa\x55\x02\x02\x02')
        elif level == '2':
            logging.debug('go right 2')
            self.ser.write(b'\xaa\x55\x03\x08\xcf\x71')
        elif level == '3':
            logging.debug('go right 3')
            self.ser.write(b'\xaa\x55\x03\x08\xcf\x72')
    # 前进
    def goforward(self, level):
        if level == '1':
            logging.debug('go forward 1')
            self.ser.write(b'\xaa\x55\x02\x05\x02')
        elif level == '2':
            pass
        elif level == '3':
            pass
        elif level == '4':
            logging.debug('go forward 4')
            self.ser.write(b'\xaa\x55\x03\x09\x7f\x81')
        elif level == '5':
            pass

    # 后退
    def gobackward(self, level):
        if level == '1':
            logging.debug('go backward 1')
            self.ser.write(b'\xaa\x55\x03\x08\x19\xf2')
        elif level == '2':
            logging.debug('go backward 2')
            self.ser.write(b'\xaa\x55\x03\x08\x19\xf3')
        elif level == '3':
            pass

        # self.ser.write(b'\xaa\x55\x02\x06\x02')

    # 上升
    def goup(self, level):
        while 1:
            ret = self.ser.write(b'\xaa\x55\x02\x03\x02')
            if ret == 5:
                break

    # 下降
    def godown(self, level):
        while 1:
            ret = self.ser.write(b'\xaa\x55\x02\x04\x02')
            if ret == 5:
                break

    # 停止
    def stop_thruster(self, level):
        logging.debug('stop thruster')
        self.ser.write(b'\xaa\x55\x02\x07\x02')

    # 定时器执行函数
    def timer_func(self):
        #### 修改部分
        while 1:
            ret = self.ser.write(b'\xaa\x55\x02\x03\x02')
            if ret == 5:
                break


        #### 以下不要修改
        self.timer = threading.Timer(self.timer_interval, self.timer_func)
        self.timer.start()
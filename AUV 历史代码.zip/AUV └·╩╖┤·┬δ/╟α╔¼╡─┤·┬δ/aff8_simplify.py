import cv2
import numpy as np
import serial
import time
import logging


deepkey = 1

font = cv2.FONT_HERSHEY_SIMPLEX
color = (255, 0, 255)
hue = None

guide_stop_key = 1
gd_count = 0

com = "COM3"                                                  #串口通信口

ser = serial.Serial(com)


def guide_line_detect(img, area_th=5000, aspect_th=0.8):
    '''
    TODO：部分时候很靠近边框时，会检测到框
    :param img:
    :param area_th:
    :param aspect_th:
    :return:
    '''
    ASPECT_RATIO_MIN = 0.2 #重要参数
    MAX_CONTOUR_NUM = 6 #如果出现更多的轮廓，不进行处理。这是为了对抗白平衡

    mask, _ = get_fg_from_hue_watershed(img, 20)
    _, contours, hierarchy = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # 目前对自动白平衡的处理，太多轮廓则直接返回
    candidates = []
    candidates_y = []
    if len(contours) < MAX_CONTOUR_NUM:
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > area_th:  # 关键参数
                (x1, y1), (w1, h1), angle1 = cv2.minAreaRect(cnt)
                minAreaRect_area = w1 * h1
                aspect_ratio = float(w1) / h1
                if aspect_ratio > 1:
                    aspect_ratio = 1.0 / aspect_ratio
                    angle1 = np.mod(angle1 + 90, 180)

                extent = float(area) / minAreaRect_area

                hull = cv2.convexHull(cnt)
                hull_area = cv2.contourArea(hull)
                solidity = float(area) / hull_area

                (x2, y2), (MA, ma), angle2 = cv2.fitEllipse(cnt)
                if angle2 > 90:
                    angle2 -= 180

                logging.debug('area %f,aspect_ratio %f,extent %f,solidity %f,angle1 %f,angle2 %f' % (area, aspect_ratio, extent, solidity, angle1, angle2))

                if aspect_ratio > aspect_th or aspect_ratio < ASPECT_RATIO_MIN  or extent < 0.7 or solidity < 0.7 or abs(angle1-angle2)>30:
                    break


                # img2 = img.copy()
                # contour_info(img2,area,aspect_ratio,extent,solidity,angle1,angle2,((x2, y2), (MA, ma), angle2))
                # cv.drawContours(img2, [cnt], 0, (0, 255, 0), 3)
                # show_img(img2)

                candidates.append((x1,y1,angle2))  #目前这个组合是比较好的。
                candidates_y.append(y1)

        nc = len(candidates)
        if nc == 0:
            return None
        elif nc == 1:
            return candidates[0]
        else:
            logging.debug('multiple')

            idx = np.argmax(np.array(candidates_y))
            return candidates[idx]

def show_huv(event,x,y,flags,param):
    if event == cv2.EVENT_MOUSEMOVE:
        global mask

        mask_=mask.copy()
        cv2.putText(mask_,str(hsv[y,x,1]),(100,100),font,1.0, (128, 0, 255))
        cv2.imshow("Video",mask_)



def control_orders(od_r):                   #向串口发送命令
    global com_key
    if od_r == 1:
        ser.write(b'\xaa\x55\x02\x01\x02')
        print('left')
        com_key = 1
    if od_r == 2:
        ser.write(b'\xaa\x55\x02\x02\x02')
        print('right')
        com_key = 1
    # if od_r == 3:
    #     ser.write(b'\xaa\x55\x02\x03\x02')
    #     print('up')
    # if od_r==4:
    #     ser.write(b'\xaa\x55\x02\x04\x02')
    #     print('down')
    if od_r == 5:
        ser.write(b'\xaa\x55\x02\x05\x03')
        print('go')
    if od_r == 6:
        ser.write(b'\xaa\x55\x03\x08\x20\x32')
        print('back')
    if od_r == 7:
        ser.write(b'\xaa\x55\x02\x07\x02')
        print('stop')
    if od_r == 8:
        ser.write(b'\xaa\x55\x03\x09\x7f\xf2')
        print('continue go')

    if od_r == 9:
        ser.write(b'\xaa\x55\x03\x09\x51\x31')
        print('rush')



    if od_r == 11:
        ser.write(b'\xaa\x55\x02\x01\x01')
        #print('left2')
    if od_r == 21:
        ser.write(b'\xaa\x55\x02\x02\x01')
        #print('right2')
    if od_r == 13:
        ser.write(b'\xaa\x55\x02\x01\x03')
        #print('left3')
    if od_r == 23:
        ser.write(b'\xaa\x55\x02\x02\x03')
        #print('right3')
    if od_r == 51:
        ser.write(b'\xaa\x55\x03\x08\x40\x51')
        #print('go_left')
    if od_r == 52:
        ser.write(b'\xaa\x55\x03\x08\x94\x51')
        #print('go_right')

    if od_r == -1:
        ser.write(b'\xaa\x55\x03\x08\x7a\x12')
        #print('turn left'
    if od_r == -2:
        ser.write(b'\xaa\x55\x03\x08\xcf\x12')
        #print('turn right')

    if od_r == 'bind2':
        ser.write(b'\xaa\x55\x03\x08\xaf\xf3')
        #time.sleep(2)
        #print('bind_right')
        com_key = 1
    if od_r == 'bind1':
        ser.write(b'\xaa\x55\x03\x08\x5a\xf3')
        #time.sleep(2)
        #print('bind_left')
        com_key = 1
    if od_r == 'ka':
        ser.write(b'\xaa\x55\x03\x08\x73\x53')



def guide_line_turn(angle):
    if (-0.4<angle) and angle<0.4:
        return 'g'
    elif angle<-0.4:
        return 'l'
    elif angle>0.4:
        return 'r'

def get_fg_from_hue(img, margin):
    FRACTION_AS_BLANK = 0.003
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    dark = hsv[..., 2] < 32
    hsv[..., 0][dark] = 128

    dark = hsv[..., 1] < 50
    hsv[..., 0][dark] = 128

    mask = cv2.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
    mask2 = cv2.inRange(hsv[..., 0], np.array((180-margin)), np.array((180)))

    mask = cv2.bitwise_or(mask, mask2)

    if cv2.countNonZero(mask) < mask.shape[0]*mask.shape[1]*FRACTION_AS_BLANK:
        mask.fill(0)

    return [mask, hsv[...,0]]



def get_fg_from_hue_watershed(img, margin):
    mask, hue = get_fg_from_hue(img, margin)

    mask_bg = cv2.inRange(hue, 60, 90)
    mask_bg = cv2.bitwise_or(mask_bg, cv2.inRange(hue,128,129))

    markers = np.zeros(mask.shape, np.int32)
    markers[mask == 255] = 1
    markers[mask_bg == 255] = 2

    cv2.watershed(img, markers)
    mask[markers == 1] = 255

    # img2 = img.copy()
    # img2[markers == 1] = 255
    # cv.imshow("1", img2)
    #
    # img2 = img.copy()
    # img2[markers == 2] = 255
    # cv.imshow("2", img2)
    #
    # img2 = img.copy()
    # img2[markers == -1] = 255
    # cv.imshow("3", img2)

    return [mask, hue]


def guid_order(od):
    if od=='l':
        control_orders(51)
        print('l')
    if od=='r':
        control_orders(52)
        print('r')
    if od=='g':
        control_orders(5)
        print('g')

def Deepvalue(deepkey):
    if deepkey == 1:
        ser.write(b'\xaa\x55\x03\x0c\x10\x02')
        deep_statue = 1
        #print('deep1')
    if deepkey == 2:
        ser.write(b'\xaa\x55\x03\x0c\x28\x02')
        deep_statue= 2
        #print('deep2')
    return deep_statue




if __name__ == "__main__":
    logging.basicConfig(filename='example.log', filemode='w', level=logging.DEBUG)

    vfile = 0
    #vfile = 'C:\\Users\\96317\\Desktop\\OPENCV\\print\\yin2.avi'

    cap = cv2.VideoCapture(vfile)

    #cv2.namedWindow("Video")
    cv2.setMouseCallback('Video', show_huv)

    #cv2.namedWindow("Video2")


    while(1):
        deep_value = Deepvalue(deepkey)

        status, img = cap.read()

        cv2.boxFilter(img, -1, (5, 5), img)

        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

        mask1, hue = get_fg_from_hue(img, 20)
        t = time.clock() * 1000
        mask2, hue = get_fg_from_hue_watershed(img, 20)
        # print(time.clock() * 1000 - t)
        mask = mask1

        guide_line = guide_line_detect(img)

        if guide_line:
            if guide_stop_key:
                control_orders(7)
                guide_stop_key = 0
            x, y, angle = guide_line
            angle = angle / 180 * np.pi
            cv2.line(img, (int(x), int(y)), (int(x + 100 * np.sin(angle)), int(y - 100 * np.cos(angle))), (0, 255, 0), 2)
            x1 = int(x + 100 * np.sin(angle))
            y1 = int(y - 100 * np.cos(angle))
            order_guide = guide_line_turn(angle)
            deepkey = 2
            if gd_count == 2:
                guid_order(order_guide)

        gd_count = gd_count + 1
        if gd_count > 2:
            gd_count = 0


        cv2.imshow("img",img)
        cv2.imshow("mask",mask2)
        if cv2.waitKey(10) & 0XFF == ord('q'):
            break


cap.release()
cv2.destroyAllWindows()





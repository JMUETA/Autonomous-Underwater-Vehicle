
from __future__ import print_function
import sys
import logging
import cv2
import numpy as np
import math
import serial
import time
import threading

cap1 = cv2.VideoCapture(1)

a="C:\\Users\\96317\\Desktop\\OPENCV\\print\\GOPR.mp4"

color_d = [([84, 64, 75], [124, 104, 115])]

cap1.set(3, 640)                                         # 设置分辨率
cap1.set(4, 480)

############################## 参数部分 ####################################
guide_line_position = 320                               #引导线位置初值，当无引导线与无框时作为初值用

frame_count = 0                                         #五帧稳定性计数

markerdata = [[], [], [], [], []]                       #存储五帧数组

cen_x_th_value = 20                                     # 方差判断值（最小矩形检测是否稳定）
cen_y_th_value = 100
width_th_value = 70
higth_th_value = 140
angle_th_value = 0.2

cen_x_th_value1 = 30                                    # 稳定性阈值，情况1
cen_y_th_value1 = 120
width_th_value1 = 90
higth_th_value1 = 160
angle_th_value1 = 0.5

distance = 4.4                                          #启用十字法的距离，小于distance时启用

break_key = 1

# FORCAL = (marker[1][0]*Know_Distance)/Know_Width      #FORCAL（焦距）需要实际测试
FORCAL = 600                                            #距离函数设定的焦距，为定值
Know_Distance = 30.0                                    # 已知距离（定值）
Know_Width = 25.2                                       # 已知宽度（定值）

font = cv2.FONT_HERSHEY_SIMPLEX
color = (255, 0, 255)
hue = None

tmp = 90                                              #霍夫变换检测直线设定的值，值遇到越难检测到直线

guideline_orders = []                                   #用于存储检测到引导线时，发出的指令

MAX_TIME = 20

############# 置位参数 ###########################
go_key = 0                                              #十字法发出冲刺时，go_key置1。用于调用冲刺时转向的函数

deepkey = 1                                             #深度

guide_stop_key = 1                                      #停止置位，每当检测到引导线时停止一次，随后guide_stop_key置0
                                                        #直到丢失引导线后再次寻找到引导线，再次置1

com_key = 0                                             #卡住的flag, 对比直方图 0:  1: 卡住

cal_key = 1                                             #对比直方图 flag, 1：

open_key = 0                                            #当检测到引导线后，open_key置1，随后每帧OPEN运算都开启,每当过一个框
                                                        #open_key再次置0

bind_key = 1                                            #判断有没有检测到框,若没有置0

############## 计数参数 ###########################

go_key_count = 0                                        #冲刺计数

go_key_count2=0                                         #冲刺发送指令计数，冲刺时有左右转的指令，每十帧发送一次

count_t = 0                                             #发送指令时的计数，设置初值不同，以免一帧内发送太多指令而造成混淆
count_y = 10
count_z = -10

gd_count = 0

con = 0

compare_count = 0

cntrm1 = 0
cntrm2 = 0
cntrm_base = 3

cmd_list = [-2, -2, -2, -2, -2, -2, 5, 5, 5, 5]
cntcmd = 0

#############################################################
debug = True



####################### 串口通信 ############################

com = "COM3"                                                  #串口通信口

ser = serial.Serial(com)

############################################################



############################################ 函数模块 ############################################################


######################## 识别算法 ##############################



def kmeans(img):                                                # kmeans聚类
    Z = img.reshape((-1, 3))
    Z = np.float32(Z)

    a = []

    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)  #

    ret, label, center = cv2.kmeans(Z, 4, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)  # 随机选择中心
    center = np.uint8(center)
    res = center[label.flatten()]
    res2 = res.reshape((img.shape))

    for i in range(4):
        b = center[i][0]
        g = center[i][1]
        r = center[i][2]
        r, g, b = r / 255.0, g / 255.0, b / 255.0
        mx = max(r, g, b)
        mn = min(r, g, b)
        df = mx - mn
        if mx == mn:
            h = 0
        elif mx == b:
            h = (60 * ((g - b) / df) + 360) % 360
        elif mx == g:
            h = (60 * ((b - r) / df) + 120) % 360
        elif mx == r:
            h = (60 * ((r - g) / df) + 240) % 360
        if mx == 0:
            s = 0
        else:
            s = df / mx
        v = mx

        mask = np.zeros(img.shape[0:2], np.uint8)
        if (0 < (h / 2) < 40) or (140 < (h / 2) < 179):
            a.append(center[i])
            # print(h / 2)
            # print(i)

            mask[label.reshape((540, 960)) == i] = 255

    return mask

    # hsv


# def get_fg_from_hue(frame, margin):                             #rgb转hsv，此函数无法抑制白平衡
#     hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
#
#     dark = hsv[..., 2] < 32
#     hsv[..., 0][dark] = 128
#
#     mask = cv2.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
#     mask2 = cv2.inRange(hsv[..., 0], np.array((180 - margin)), np.array((180)))
#
#     mask = cv2.bitwise_or(mask, mask2)
#
#     return [mask, hsv[..., 0]]
#

def get_fg_from_hue_watershed(img, margin):                     ## 分水岭算法
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    dark = hsv[..., 2] < 32
    hsv[..., 0][dark] = 128

    mask = cv2.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
    mask2 = cv2.inRange(hsv[..., 0], np.array((180 - margin)), np.array((180)))

    mask = cv2.bitwise_or(mask, mask2)

    mask_bg = cv2.inRange(hsv[..., 0], 60, 90)

    markers = np.zeros(mask.shape, np.int32)
    markers[mask == 255] = 1
    markers[mask_bg == 255] = 2

    cv2.watershed(img, markers)

    mask[markers == 1] = 255

    return [mask, hsv[..., 0]]




def get_fg_from_hue(img, margin):
    FRACTION_AS_BLANK = 0.003
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    dark = hsv[..., 2] < 32
    hsv[..., 0][dark] = 128

    dark = hsv[..., 1] < 50
    hsv[..., 0][dark] = 128

    mask = cv2.inRange(hsv[..., 0], np.array((0)), np.array((margin)))
    mask2 = cv2.inRange(hsv[..., 0], np.array((180-margin)), np.array((180)))

    mask = cv2.bitwise_or(mask, mask2)

    if cv2.countNonZero(mask) < mask.shape[0]*mask.shape[1]*FRACTION_AS_BLANK:
        mask.fill(0)

    return [mask, hsv[...,0]]


def get_fg_from_hue_watershed_saturation(img, margin):
    mask, hue = get_fg_from_hue(img, margin)

    mask_bg = cv2.inRange(hue, 60, 90)
    mask_bg = cv2.bitwise_or(mask_bg, cv2.inRange(hue,128,129))

    markers = np.zeros(mask.shape, np.int32)
    markers[mask == 255] = 1
    markers[mask_bg == 255] = 2

    cv2.watershed(img, markers)
    mask[markers == 1] = 255

    # img2 = img.copy()
    # img2[markers == 1] = 255
    # cv.imshow("1", img2)
    #
    # img2 = img.copy()
    # img2[markers == 2] = 255
    # cv.imshow("2", img2)
    #
    # img2 = img.copy()
    # img2[markers == -1] = 255
    # cv.imshow("3", img2)

    return [mask, hue]





def colorsection(frame):                                        #颜色阈值
    for (lower, upper) in color_d:
        lower = np.array(lower, dtype="uint8")
        upper = np.array(upper, dtype="uint8")
        mask = cv2.inRange(frame, lower, upper)
        output = cv2.bitwise_and(frame, frame, mask=mask)
    gray = cv2.cvtColor(output, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edged = cv2.Canny(blurred, 40, 200, apertureSize=3)
    ret, thresh = cv2.threshold(blurred, 50, 255, cv2.THRESH_BINARY)

    return thresh

########################################################################



###################### 判断函数 ######################################

def distance_to_camera(width, forcal, perwidth):                # 距离计算
    return (width * forcal) / perwidth



def feasibility(marker):                                        # 判断宽高比可行性可行性判断，当宽高比大于0.7则可行
    if marker[1][0] / (marker[1][1]+1) > 0.7:
        return 1
    else:
        return 0


def stability(aff_value):                                           #判断稳定性函数 1:不稳定,2:稳定
    if (aff_value[0] > cen_x_th_value1 or aff_value[1] > cen_y_th_value1 or
            aff_value[2] > width_th_value1 or aff_value[3] > higth_th_value1
            or aff_value[4] > angle_th_value1):
        return 1

    if (aff_value[0] < cen_x_th_value and aff_value[1] < cen_y_th_value and
            aff_value[2] < width_th_value and aff_value[3] < higth_th_value and
            aff_value[4] < angle_th_value and feasibility(marker)):
        return 2
    else:
        return 0


def affirm_var(markerdata1):                                    # 过去4帧，现在1一帧的最小矩形中点位置，长度，宽度，角度的方差
    cen_x = []
    cen_y = []
    width = []
    higth = []
    angle = []
    for i in range(5):
        cen_x.append(markerdata1[i][0][0])
        cen_y.append(markerdata1[i][0][1])
        width.append(markerdata1[i][1][0])
        higth.append(markerdata1[i][1][1])
        angle.append(markerdata1[i][2])
    var_cen_x = np.var(cen_x)
    var_cen_y = np.var(cen_y)
    var_width = np.var(width)
    var_higth = np.var(higth)
    var_angle = np.var(angle)
    affirm_var = [var_cen_x, var_cen_y, var_width, var_higth, var_angle]
    # 返回当前状态，x,y坐标，宽度，高度，角度方差
    return affirm_var


def position_row(X_center):                                     # 水平方向偏离中心距离
    offset_row = X_center - 320
    return offset_row


def position_column(Y_center):                                  # 竖直方向偏离中心距离
    offset_column = Y_center - 240
    return offset_column


############################################################################



############################ 操作函数 #######################################


def maxAreaRect_momentCenter(thresh):                                          #最大矩形中心，矩中心计算
    global frame_count

    cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)       # findContours寻找轮廓，寻找最小外接矩形
    cnts = cnts[1]
    cnts0 = cv2.findContours(thresh.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    cnts0 = cnts0[1]

    if not (cnts0 == []):
        c = max(cnts0, key=cv2.contourArea)
        marker = cv2.minAreaRect(c)         # 得到最小外接矩形（中心(x,y),（宽，高），选住角度）
        markerdata[frame_count] = marker    # 将最小外接矩形数据存放到一个二维列表
        frame_count = frame_count + 1       # 计数
        if frame_count == 5:                # 计数为5时，再次清零
            frame_count = 0

        inches = distance_to_camera(Know_Width, FORCAL,marker[1][0] + 1)  # 对象距离

        box = cv2.boxPoints(marker)  # 获取最小外接矩形的四个顶点
        box = np.int0(box)
        cv2.drawContours(frame, [box], -1, (0, 255, 0), 2)
        cv2.putText(frame, "%.2fft" % (inches / 12), (frame.shape[1] - 200, frame.shape[0] - 20),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    2.0, (0, 255, 0), 3)

    if not (cnts == []):
        for c_ in cnts:
            M = cv2.moments(c_)                             # 求图形的矩
            cX = int((M["m10"] + 1) / (M["m00"] + 1))
            cY = int((M["m01"] + 1) / (M["m00"] + 1))
            cv2.drawContours(frame, [c_], -1, (0, 255, 0), 2)
            cv2.circle(frame, (cX, cY), 7, (255, 255, 255), -1)
            cv2.putText(frame, "center", (cX - 20, cY - 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

            if not (markerdata[4] == []) and not(marker is None):                       # 当markerdata的内容有五个数据（也就是存放了历史4帧以及现在1帧的数据）
                aff_value = affirm_var(markerdata)              # markerdata数据传递给markerdata1，用于以上affirm_var函数，circilepoint函数做形式参数
                if marker or aff_value or cX or cY:
                    return marker,aff_value,cX,cY

    return None,None,None,None


def circlepoint(markerdata1):               # 计算最小矩形中心位置，距离画面中点位置距离
    cen_x, cen_y = markerdata1[0]
    dis_x = cen_x - 240
    dis_y = cen_y - 320
    distance = math.sqrt(dis_x * dis_x + dis_y * dis_y)
    return distance


def cross_aim(frame,thresh):                       #十字法
    xd,yd=0,0
    cv2.boxFilter(frame, -1, (5, 5), frame)
    #thresh,_ret = get_fg_from_hue(frame, 20)

    face1 = thresh[220:260, 0:640]
    frame1 = frame[220:260, 0:640]
    face2 = thresh[0:480, 300:340]
    frame2 = frame[0:480, 300:340]

    face3 = thresh[0:239, 300:340]
    frame3 = frame[0:239, 300:340]
    face4 = thresh[220:260, 0:319]
    frame4 = frame[220:260, 0:319]
    face5 = thresh[220:480, 300:340]
    frame5 = frame[220:480, 300:340]
    face6 = thresh[220:260, 320:640]
    frame6 = frame[220:260, 320:640]

    cnts1 = cv2.findContours(face1.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts1 = cnts1[1]
    cnts2 = cv2.findContours(face2.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts2 = cnts2[1]

    cnts3 = cv2.findContours(face3.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts3 = cnts3[1]
    cnts4 = cv2.findContours(face4.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts4 = cnts4[1]
    cnts5 = cv2.findContours(face5.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts5 = cnts5[1]
    cnts6 = cv2.findContours(face6.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts6 = cnts6[1]

    if not (cnts4 == []):
        c44 = max(cnts4, key=cv2.contourArea)
        marker44 = cv2.minAreaRect(c44)
        box44 = cv2.boxPoints(marker44)
        box44 = np.int0(box44)
        cv2.drawContours(frame, [box44], -1, (0, 255, 0), 2)
    if not (cnts6 == []):
        c66 = max(cnts6, key=cv2.contourArea)
        marker66 = cv2.minAreaRect(c66)
        box66 = cv2.boxPoints(marker66)
        box66 = np.int0(box66)
        cv2.drawContours(frame, [box66], -1, (0, 255, 0), 2)

    if not(cnts4 == []) and not(cnts6 == []):
        X_center = int((marker44[0][0] + marker66[0][0] + 320) / 2)
        xd = position_row(X_center)
        cv2.circle(frame, (int((marker44[0][0] + marker66[0][0] + 320) / 2),
                            int((marker44[0][1] + marker66[0][1] +440) / 2)), 7, (0, 255, 0), 2)

    if not(cnts1==[]):
        for c1 in cnts1:
            M1 = cv2.moments(c1)
            cX1 = int((M1["m10"] + 1) / (M1["m00"] + 1))
            cY1 = int((M1["m01"] + 1) / (M1["m00"] + 1))
            cv2.drawContours(frame1, [c1], -1, (0, 255, 0), 2)
            cv2.circle(frame, (cX1, cY1), 7, (255, 0, 0), -1)

            if cnts4 == [] or cnts6 == []:
                cv2.circle(frame, (cX1, cY1), 7, (255, 0, 0), -1)
            if (cnts4 == [] or cnts6 == []) and count_y == 30:
                if cX1 > 350:
                    control_orders(2)
                if cX1 < 290:
                    control_orders(1)

    if not (cnts3 == []):
        c33 = max(cnts3, key=cv2.contourArea)
        marker33 = cv2.minAreaRect(c33)
        box33 = cv2.boxPoints(marker33)
        box33 = np.int0(box33)
        cv2.drawContours(frame,[box33],-1,(0,255,0),2)

    if not (cnts5 == []):
        c55 = max(cnts5, key=cv2.contourArea)
        marker55 = cv2.minAreaRect(c55)
        box55 = cv2.boxPoints(marker55)
        box55 = np.int0(box55)

        cv2.drawContours(frame,[box55],-1,(0,255,0),2)
    if not (cnts3 == []) and not (cnts5 == []):
        Y_center = int((marker33[0][1] + marker55[0][1] + 240) / 2)
        yd = position_column(Y_center)
        cv2.circle(frame, (int((marker33[0][0] + marker55[0][0] + 600) / 2),
                            int((marker33[0][1] + marker55[0][1] + 240) / 2)), 7, (0, 0, 255), 2)


    if not(cnts2==[]):
        for c2 in cnts2:
            M2 = cv2.moments(c2)
            cX2 = int((M2["m10"] + 1) / (M2["m00"] + 1))
            cY2 = int((M2["m01"] + 1) / (M2["m00"] + 1))
            cv2.drawContours(frame2, [c2], -1, (0, 0, 255), 2)
            cv2.circle(frame, (cX2, cY2), 7, (0, 0, 255), -1)

            if (cnts3 == [] or cnts5 == []) and count_t == 50:
                cv2.circle(frame, (cX2, cY2), 7, (255, 0, 0), -1)
                if cY2 < 210 or cY2 > 270:
                    control_orders(6)

    if not(cnts3==[]) and not(cnts4==[]) and not(cnts5==[]) and not(cnts6==[]):
        c1 = int((marker44[0][0] + marker66[0][0] + 320) / 2)
        c2 = int((marker44[0][1] + marker66[0][1] +440) / 2)
        c3 = int((marker33[0][0] + marker55[0][0] + 600) / 2)
        c4 = int((marker33[0][1] + marker55[0][1] + 240) / 2)

        dis = math.sqrt((c1-c3)*(c1-c3)+(c2-c4)*(c2-c4))

        if dis<50 and math.fabs((c1-320))<50 and math.fabs((c3-320))<50:
            control_orders(8)

        if xd and yd:
            od = order_accurate(xd, yd)
            #if (count_t == 40):
            control_orders(od)
            return frame1,frame2,od
    return frame1,frame2,None


def modelsection(num, frame):               #选择模式（颜色提取，kmeasn聚类,分水岭）
    if num == 1:
        thresh = colorsection(frame)
    if num == 2:
        thresh = kmeans(frame)
    if num == 3:
        thresh, hue = get_fg_from_hue_watershed_saturation(frame, 20)
    return thresh



################################################################


########################## 指令函数 ############################


def control_orders(od_r):                   #向串口发送命令
    global com_key
    if od_r == 1:
        ser.write(b'\xaa\x55\x02\x01\x01')
        #print('left')
        com_key = 1
    if od_r == 2:
        ser.write(b'\xaa\x55\x02\x02\x01')
        #print('right')
        com_key = 1
    # if od_r == 3:
    #     ser.write(b'\xaa\x55\x02\x03\x02')
    #     print('up')
    # if od_r==4:
    #     ser.write(b'\xaa\x55\x02\x04\x02')
    #     print('down')
    if od_r == 5:
        ser.write(b'\xaa\x55\x02\x05\x02')
        #print('go')
    if od_r == 6:
        ser.write(b'\xaa\x55\x03\x08\x20\x32')
        #print('back')
    if od_r == 7:
        ser.write(b'\xaa\x55\x02\x07\x02')
        #print('stop')
    if od_r == 8:
        ser.write(b'\xaa\x55\x03\x09\x54\x53')
        #print('continue go')

    if od_r == 9:
        ser.write(b'\xaa\x55\x03\x09\x50\x52')
        #print('rush')



    if od_r == 11:
        ser.write(b'\xaa\x55\x02\x01\x01')
        #print('left2')
    if od_r == 21:
        ser.write(b'\xaa\x55\x02\x02\x01')
        #print('right2')
    if od_r == '21':
        ser.write(b'\xaa\x55\x02\x01\x02')
        #print('left3')
    if od_r == '22':
        ser.write(b'\xaa\x55\x02\x02\x02')
        #print('right3')
    if od_r == 51:
        ser.write(b'\xaa\x55\x03\x08\x40\xe2')                  #40
        #print('go_left')
        com_key = 1
    if od_r == 52:
        ser.write(b'\xaa\x55\x03\x08\x94\xe2')  #94
        cal_key = 1
        com_key = 1

    if od_r == -1:
        #ser.write(b'\xaa\x55\x03\x08\x69\x33')
        ser.write(b'\xaa\x55\x03\x08\x66\x33')
        #print('turn left'
    if od_r == -2:
        #ser.write(b'\xaa\x55\x03\x08\xbe\x33')
        ser.write(b'\xaa\x55\x03\x08\xbb\x33')
        #print('turn right')

    if od_r == 'bind2':
        ser.write(b'\xaa\x55\x03\x08\xaf\xf3')
        #time.sleep(2)
        #print('bind_right')
        com_key = 1
    if od_r == 'bind1':
        ser.write(b'\xaa\x55\x03\x08\x5a\xf3')
        #time.sleep(2)
        #print('bind_left')
        com_key = 1
    if od_r == 'ka':
        ser.write(b'\xaa\x55\x03\x08\x73\x53')

    if od_r == 'b':
        ser.write(b'\xaa\x55\x03\x08\x66\x32')
        #print('turn left'
    if od_r == 'a':
        ser.write(b'\xaa\x55\x03\x08\xbb\x32')
        #print('turn right')

    if od_r == '0l':
        ser.write(b'\xaa\x55\x03\x08\x69\x33')
        #print('turn left'
    if od_r == '0r':
        ser.write(b'\xaa\x55\x03\x08\xbe\x33')
        #print('turn right')



def order_accurate(xd, yd):                     #十字模式调整（较小阈值）
    od = 7
    # if yd > 30:
    #     od = 4
    # if yd < (-30):
    #     od = 3
    # if (yd < 50) and (yd > (-50)):
    if xd > 80:
        od = 2
    if xd < (-80):
        od = 1
    if xd < 80 and xd > (-80):
        od = 'p'

    return od


def order_remote(xd, yd):                   #较远调整（较大阈值）
    od = 7
    # if yd > 30:
    #     od = 4
    # if yd < (-30):
    #     od = 3
    # if (yd < 50) and (yd > (-50)):
    if xd > 100:
        od = 2
    if xd < (-100):
        od = 1
    if xd < 100 and xd > (-100):
        od = 5

    return od



def contour_info(img, area, aspect_ratio, extent, solidity, angle1, angle2, ellipse):
    color = (255,0,255)
    msg = "area %f; aspect %f; extent %f" % (area, aspect_ratio, extent)
    cv2.putText(img, msg, (10, 30), font, 0.7, color)
    msg = "solidity %f; angle1 %f; angle2 %f" % (solidity, angle1, angle2)
    cv2.putText(img, msg, (10, 80), font, 0.7, color)
    cv2.ellipse(img, ellipse, (0, 255, 0), 2)



def guide_line_detect(img, area_th=5000, aspect_th=0.8):
    '''

    TODO：部分时候很靠近边框时，会检测到框
    :param img:
    :param area_th:
    :param aspect_th:
    :return:
    '''
    ASPECT_RATIO_MIN = 0.15 #重要参数
    MAX_CONTOUR_NUM = 6 #如果出现更多的轮廓，不进行处理。这是为了对抗白平衡

    mask, _ = get_fg_from_hue_watershed_saturation(img, 20)
    _, contours, hierarchy = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # 目前对自动白平衡的处理，太多轮廓则直接返回
    candidates = []
    candidates_y = []
    if len(contours) < MAX_CONTOUR_NUM:
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > area_th:  # 关键参数
                (x1, y1), (w1, h1), angle1 = cv2.minAreaRect(cnt)
                minAreaRect_area = w1 * h1
                aspect_ratio = float(w1) / h1
                if aspect_ratio > 1:
                    aspect_ratio = 1.0 / aspect_ratio
                    angle1 = np.mod(angle1 + 90, 180)

                extent = float(area) / minAreaRect_area

                hull = cv2.convexHull(cnt)
                hull_area = cv2.contourArea(hull)
                solidity = float(area) / hull_area

                (x2, y2), (MA, ma), angle2 = cv2.fitEllipse(cnt)
                if angle2 > 90:
                    angle2 -= 180

                logging.debug('area %f,aspect_ratio %f,extent %f,solidity %f,angle1 %f,angle2 %f' % (area, aspect_ratio, extent, solidity, angle1, angle2))

                if aspect_ratio > aspect_th or aspect_ratio < ASPECT_RATIO_MIN  or extent < 0.7 or solidity < 0.7 or abs(angle1-angle2)>30:
                    break


                # img2 = img.copy()
                # contour_info(img2,area,aspect_ratio,extent,solidity,angle1,angle2,((x2, y2), (MA, ma), angle2))
                # cv.drawContours(img2, [cnt], 0, (0, 255, 0), 3)
                # show_img(img2)

                candidates.append((x1,y1,angle2))                       #目前这个组合是比较好的。
                candidates_y.append(y1)

        nc = len(candidates)
        if nc == 0:
            return None
        elif nc == 1:
            return candidates[0]
        else:
            logging.debug('multiple')

            idx = np.argmax(np.array(candidates_y))
            return candidates[idx]



def show_huv(event,x,y,flags,param):
    if event == cv2.EVENT_MOUSEMOVE:
        global mask

        mask_=mask.copy()
        #cv2.putText(mask_,str(hsv[y,x,1]),(100,100),font,1.0, (128, 0, 255))
        # cv2.imshow("Video",mask_)


def Houghlines(thresh):                                              #检测直线，上面摄像头有看到框，就有直线返回0，否则返回1
    lines = cv2.HoughLines(thresh, 1, np.pi / 180, tmp)
    if lines is None:
        return 1
    if not(lines is None):
        lines1 = lines[:, 0, :]
        line_num = len(lines1)
        if line_num<4:
            return 1
        else:
            return 0


def fd_trun(thresh):                                                      #冲刺时转向函数
    cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[1]
    if not(cnts==[]):
        for c_ in cnts:
            M = cv2.moments(c_)  # 求图形的矩
            cX = int((M["m10"] + 1) / (M["m00"] + 1))
            if cX < 270:
                # print('q')
                return '0r'
            if cX > 370:
                # print('w')
                return '0l'
            else:
                # print('e')
                return 8
    else:
        return 8



def guide_line_turn(angle):                                             #判断识别到引导线时转向函数
    if (-0.4<angle) and angle<0.4:
        return 'g'
    elif angle<-0.4:
        return 'l'
    elif angle>0.4:
        return 'r'

def guid_order(od):                                                     #如何沿着引导线走
    if od=='l':
        control_orders(51)
        #print('l')
    if od=='r':
        control_orders(52)
        #print('r')
    if od=='g':
        control_orders(5)
        #print('g')



def find_guideline(thresh):                                          #若前置摄像头检测到引导线，则向着引导线前景。已停用
    cnts = cv2.findContours(thresh.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[1]
    if not(cnts==[]):
        for c in cnts:
            (x,y,w,h) = cv2.boundingRect(c)
            keepDims = w/h<0.65 and 0.2<w/h and w>40 and h>60 and w<80 and h<150
            if keepDims:
                cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)
                cv2.circle(frame,(int(x+w/2),int(y+h/2)),4,(0,255,255),3)
                cv2.putText(frame,"guide",(int(x+w/2),int(y+h/2)),cv2.FONT_HERSHEY_SIMPLEX,1.0, (0, 255, 0), 3)
                return x,y,w,h
    return None,None,None,None




############################## 模式函数 ##############################

####################### 分割线 ##############################

#分割线内都为筛选霍夫变换检测出的直线的功能函数
def classify_row(lines2):
    line_theta = []
    hor_line = []
    line_theta = lines2
    for j in range(len(lines2)):
        if line_theta[j][1] >0.79 or line_theta[j][1]<(-0.79):
            hor_line.append(line_theta[j])
    return hor_line

def classify_column(lines2):
    line_theta = []
    ver_line = []
    line_theta = lines2
    for j in range(len(lines2)):
        if line_theta[j][1]  <0.79 and line_theta[j][1]>(-0.79):
            #ver_line[j] = line_theta[j]
            ver_line.append(line_theta[j])
    return ver_line


def bubbleSort_row(lines2):
    hor_line = classify_row(lines2)
    for i in range(len(hor_line)-1):
        for j in range(len(hor_line)-i-1):
            if hor_line[j][0] > hor_line[j+1][0]:
                hor_line[j], hor_line[j+1] = hor_line[j+1], hor_line[j]
    return hor_line

def bubbleSort_column(lines2):
    ver_line = classify_column(lines2)
    for i in range(len(ver_line)-1):
        for j in range(len(ver_line)-i-1):
            if ver_line[j][0] > ver_line[j+1][0]:
                ver_line[j], ver_line[j+1] = ver_line[j+1], ver_line[j]
    return ver_line

def distingish_row(lines2):
    line_hor = bubbleSort_row(lines2)
    section_line_hor = []
    if len(line_hor) == 0:
        return section_line_hor
    for i in range(len(line_hor)-1):
        if line_hor[i+1][0] - line_hor[i][0]>50:
            section_line_hor.append(line_hor[i])
    section_line_hor.append(line_hor[len(line_hor)-1])

    return section_line_hor

def distingish_column(lines2):
    line_ver = bubbleSort_column(lines2)
    section_line_ver = []
    if len(line_ver) == 0:
        return section_line_ver
    for i in range(len(line_ver)-1):
        if line_ver[i+1][0] - line_ver[i][0]>50:
            section_line_ver.append(line_ver[i])
    section_line_ver.append(line_ver[len(line_ver)-1])

    return section_line_ver


########################## 分割线 #################################

def Houghvary(thresh):                                         #检测直线，画出识别到的直线
    edged = cv2.Canny(thresh, 40, 200, apertureSize=3)
    lines = cv2.HoughLines(edged,1,np.pi/180,100)
    if (lines is None):
        return None
    lines1 = lines[:,0,:]
    lines2 = lines1
    if len(lines1) < 25:
        for g in range(len(lines1)):
            if lines1[g][0]<0:
                lines2[g][0] = abs(lines1[g][0])
                lines2[g][1] = lines1[g][1]-3.14

    for rho1, theta1 in lines2[:]:
        a1 = np.cos(theta1)
        b1 = np.sin(theta1)
        x01 = a1 * rho1
        y01 = b1 * rho1
        x__ = int(x01 + 1000 * (-b1))
        y__ = int(y01 + 1000 * (a1))
        x__1 = int(x01 - 1000 * (-b1))
        y__1 = int(y01 - 1000 * (a1))
        cv2.line(frame, (x__, y__), (x__1, y__1), (0, 255, 0), 2)
    return lines2

def Node_decetion(thresh):                                            #求直线交点。返回值分别为：交点个数，交点X坐标列表
    lines2 = Houghvary(thresh)                                        #交点X坐标列表
    if lines2 is None:
        return None,None,None
    line_row = distingish_row(lines2)
    line_cloum = distingish_column(lines2)
    node_x = []
    node_y = []
    points_num = len(line_row)*len(line_cloum)

    for i in range(len(line_row)):
        for j in range(len(line_cloum)):
            cosxi = math.cos(line_row[i][1])
            sinxi = math.sin(line_row[i][1])
            cosxj = math.cos(line_cloum[j][1])
            sinxj = math.sin(line_cloum[j][1])
            rhoi = line_row[i][0]
            rhoj = line_cloum[j][0]
            aX = int((rhoi*sinxj - rhoj*sinxi)/(cosxi*sinxj - cosxj*sinxi))
            aY = int((rhoj*cosxi - rhoi*cosxj)/(sinxj*cosxi - sinxi*cosxj))
            node_x.append(aX)
            node_y.append(aY)
            cv2.circle(frame,(aX,aY),7,(255,255,0),-1)
    return points_num,node_x,node_y

def decetion_status(thresh,deep_value):                               #根据交点，判断当前处于什么状态
    points_num,node_x,node_y = Node_decetion(thresh)
    # 交点返回为None,说明没有检测到直线
    if points_num is None:
        return  'strage'
    #一个交点，说明现在处于较为角落的位置
    if points_num == 1:
        status = 'corner'
        #print("Corner")
    #有两到三个交点，说明处于框的边缘
    if 1<points_num and points_num<4:
        status = 'edges'
        #print('Edges')
    #大于四个交点，视野内有超过一个框的存在。
    if points_num > 4:
        status = 'multiple'
        #print("Multiple")
    if points_num==0:
        status = 'coincide'
        #print('Coincide')
    #有四个交点
    if points_num == 4:
        s = bias(thresh)
        if s == 'left':
            status = 'side_left'
            #print('at left')
        elif s == 'right':
            status = 'side_right'
            #print('at right')
        elif s is None:
            return 'strage'
        else:
            status = 'normal'
            #print('Normal')
    if deep_value==1 and points_num>=2:
        status = 'shallow'

    return status

def bias(thresh):                                           #如果处于框的侧面，判断是处于左边还是右边
    points_num,node_x,node_y = Node_decetion(thresh)
    if points_num is None:
        return None
    y1 = node_y[0]
    y2 = node_y[1]
    y3 = node_y[2]
    y4 = node_y[3]

    me1 = y1-y2
    me2 = y3-y4
    if me1>10 and me2>30:
        return 'left'
    elif me1<-10 and me2<-30:
        return 'right'
    else:
        return 'front'


def Running_Status(status,thresh,marker,cX,frame,mask2,aff_value):         #根据状态选择执行函数
    if status=='normal':
        Normal(thresh,frame,marker,aff_value)
    if status=='corner':
        Corner(cX)
    if status=='edges':
        Edges(cX)
    if status=='multiple':
        Multiple(thresh)
    if status=='coincide':
        Coincide(thresh,mask2)
    if status=='side_left' or status=='side_right':
        Side(thresh)
    if status=='shallow':
        points_num, node_x, node_y = Node_decetion(thresh)
        Shallow_decetion(node_x)




################## 状态动作 ################


def Normal(thresh,frame,marker,aff_value):
    global  go_key
    global deepkey
    if stability(aff_value) == 2:                                       #稳定状态
        remote_column = position_column(marker[0][1])
        remote_row = position_row(marker[0][0])
        od_r = order_remote(remote_row, remote_column)
        #keys = keys + 1

        if (count_t == 30) :                                             #计帧发送
            control_orders(od_r)

        # 进入对准模式（当inches/小于4.5时）
        if (inches / 12 < distance):                                    #当稳定且距离小于distance，进入十字对准
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (9, 9))  #数值待定
            thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
            frame1,frame2,od = cross_aim(frame,thresh)

            if debug:
                cv2.imshow("123", frame1)                                   #显示
                cv2.imshow("312", frame2)

            if od == 'p':
                go_key = 1
                deepkey = 1
    else:
        points_num, node_x, node_y = Node_decetion(thresh)
        if not(points_num is None):
            y1 = node_y[0]
            y3 = node_y[2]
            x1 = node_x[0]
            x2 = node_y[1]
            cen_X = int((x1+x2)/2)
            cen_Y = int((y1+y3)/2)
            remote_column = position_column(cen_Y)
            remote_row = position_row(cen_X)
            od_r = order_remote(remote_row, remote_column)

            if (count_t == 30):  # 计帧发送
                control_orders(od_r)

def Corner(cX):
    if count_z == 30:
        if cX > 350:
            #print('cr')
            control_orders('a')
        if cX < 290:
            #print('cl')
            control_orders('b')

def Edges(cX):
    if count_z == 30:
        if cX > 350:
            #print('er')
            control_orders(2)
        if cX < 290:
            #print('el')
            control_orders(1)

def Multiple(thresh):
    global go_key
    global deepkey
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (11, 11))     #数值待定
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    frame1, frame2, od = cross_aim(frame, thresh)
    #if not (od is None):

    if debug:
        cv2.imshow("row", frame1)  # 显示
        cv2.imshow("column", frame2)
    #cv2.imshow("open",thresh)
    if od == 'p':
        go_key = 1
        deepkey = 1

def Coincide(thresh,mask2):

    global deepkey
    global guide_stop_key
    global con
    global open_key
    con = con + 1
    cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)      # findContours寻找轮廓，寻找最小外接矩形
    cnts = cnts[1]
    cnts0 = cv2.findContours(thresh.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    cnts0 = cnts0[1]
    if not (cnts0 == []):
        c = max(cnts0, key=cv2.contourArea)
        marker = cv2.minAreaRect(c)                             # 得到最小外接矩形（中心(x,y),（宽，高），选住角度）
        Dims = marker[1][0]>10 and marker[1][1]>100
    if not (cnts == []):                                        #求Coinside矩中心cX位置
        for c_ in cnts:
            M = cv2.moments(c_)
            cX = int((M["m10"] + 1) / (M["m00"] + 1))

    left_fg_count = cv2.countNonZero(mask2[0:240,0:320])
    right_fg_count = cv2.countNonZero(mask2[0:240,320:])
    #print("left %d right %d"%(left_fg_count,right_fg_count))

    if left_fg_count<=1000 and right_fg_count<=1000 and marker[1][0]>80 and con%63==0:
        control_orders(5)

    if cX>370 and Dims and con%20==0 and left_fg_count<=1000 and right_fg_count>=5000:
        control_orders(6)
        time.sleep(1)
        control_orders(-2)
        time.sleep(2)
        control_orders(9)
        time.sleep(1)
        deepkey = 1
        open_key = 0
        guide_stop_key = 1
    if cX>370 and Dims and con%21==0 and (1000<left_fg_count) and left_fg_count< right_fg_count:
        control_orders(6)
        time.sleep(1)
        control_orders(-1)
        time.sleep(2)
        control_orders(9)
        time.sleep(1)
        deepkey = 1
        open_key = 0
        guide_stop_key = 1
    if cX<270 and Dims and con%20==0 and left_fg_count>=5000 and right_fg_count<=1000:
        control_orders(6)
        time.sleep(1)
        control_orders(-1)
        time.sleep(2)
        control_orders(9)
        time.sleep(1)
        deepkey = 1
        open_key = 0
        guide_stop_key = 1
    if cX <270 and Dims and con % 21 == 0 and left_fg_count > right_fg_count and right_fg_count>1000:
        control_orders(6)
        time.sleep(1)
        control_orders(-2)
        time.sleep(2)
        control_orders(9)
        time.sleep(1)
        deepkey = 1
        open_key = 0
        guide_stop_key = 1


def Side(thresh):
    find_guideline(thresh)


def Shallow_decetion(node_x):
    sum = 0
    for i in range(len(node_x)):
        sum = node_x[i] + sum
    ave_center = int(sum/len(node_x))
    if ave_center<270:
        control_orders(51)
        print('go_left')
    if ave_center>370:
        control_orders(52)
        print('go_right')
    if 270<ave_center and ave_center>370:
        control_orders(5)
        print('go')



def Downner(thresh):
    #是否要开启OPEN

    num = cv2.countNonZero(thresh[400:480,:])
    if num>500:
        return 2
    else:
        return 0

    # up_side = cv2.countNonZero(thresh[0:240,:])
    # down_side = cv2.countNonZero(thresh[240:480,:])
    # if up_side>down_side:
    #     return 0
    # if down_side>up_side:
    #     return 2



def Deepvalue(deepkey):
    if deepkey == 0:                                    #定深0，用于上浮至高框位置
        ser.write(b'\xaa\x55\x03\x0c\x01\x02')
        deep_statue = 0
    if deepkey == 1:                                    #定深1，检测引导线的定深
        ser.write(b'\xaa\x55\x03\x0c\x0c\x02')
        deep_statue = 1
        #print('deep1')
    if deepkey == 2:                                    #定深3，穿过矮框的定深
        ser.write(b'\xaa\x55\x03\x0c\x24\x02')
        deep_statue= 2
        #print('deep2')
    if deepkey == 3:
        ser.write(b'\xaa\x55\x03\x0c\x18\x02')
        deep_statue = 3
    return deep_statue

################################################


def CompareHist(thresh):                                    #对比直方图函数，判断是否卡住了
    global cal_key
    global compare_count
    global hist1
    if cal_key:
        hist1 = cv2.calcHist([thresh],[0],None,[256],[0,256])
        cal_key = 0
    hist2 = cv2.calcHist([thresh],[0],None,[256],[0,256])
    compare_num = cv2.compareHist(hist1,hist2,cv2.HISTCMP_BHATTACHARYYA)
    if compare_num >= 0.7:
        compare_count = compare_count + 1

    if compare_count > 50:
        control_orders(6)
        time.sleep(1)
        compare_count = 0
        cal_key = 1


# def Ball_Dection():                               #检测球
#     global break_key
#     break_key = 0
#     while(1):
#         Deepvalue(1)
#         ret, frame = cap1.read()                # 读取视频
#         thresh = modelsection(1,frame)
#         edges = cv2.Canny(thresh, 50, 150)
#         x,y,radius = cv2.HoughCircles(edges, cv2.HOUGH_GRADIENT, 1, 100, param1=100, param2=30, minRadius=5, maxRadius=300)
#         if x == None:
#             control_orders(52)
#         else:
#             cv2.circle(frame,(x,y),radius,(0,255,0),-1)
#             if x<270:
#                 control_orders(1)
#             if x>370:
#                 control_orders(2)
#             if 270<x<370:
#                 control_orders(5)


def Rowlines(mask2):
    edged = cv2.Canny(mask2, 40, 200, apertureSize=3)
    lines = cv2.HoughLines(edged, 1, np.pi / 180, 100)
    if (lines is None):
        return None
    lines1 = lines[:, 0, :]
    lines2 = lines1
    if len(lines1) < 25:
        for g in range(len(lines1)):
            if lines1[g][0] < 0:
                lines2[g][0] = abs(lines1[g][0])
                lines2[g][1] = lines1[g][1] - 3.14
        line_row = distingish_row(lines2)
        #print(line_row[0][1])
        if len(line_row) >=2:
            if line_row[0][1] > 1.4 and line_row[0][1] < 1.8:
                print('row')
                control_orders(5)



def get_ball(img, low, high, ws_flag=True, sv_flag=True):
    '''

    :param img:
    :param low:
    :param high:
    :param ws_flag: 分水岭标志
    :param sv_flag: SV 标志
    :return:
    '''

    global break_key
    break_key = 0
    fraction_as_blank = 0.003
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    # 若 sv_flag 有效，根据饱和度和亮度排除前景
    if sv_flag:
        dark = hsv[..., 2] < 32
        hsv[..., 0][dark] = 128

        dark = hsv[..., 1] < 50
        hsv[..., 0][dark] = 128

    mask = cv2.inRange(hsv[..., 0], np.array((low)), np.array((high)))
    # mask2 = cv.inRange(hsv[..., 0], np.array((180-margin)), np.array((180)))
    # mask = cv.bitwise_or(mask, mask2)

    if cv2.countNonZero(mask) < mask.shape[0]*mask.shape[1]*fraction_as_blank:
        mask.fill(0)

    if ws_flag:
        mask_bg = cv2.inRange(hsv[...,0], 0, 20)
        mask_bg = cv2.bitwise_or(mask_bg, cv2.inRange(hsv[...,0], 128, 255))

        markers = np.zeros(mask.shape, np.int32)
        markers[mask == 255] = 1
        markers[mask_bg == 255] = 2

        cv2.watershed(img, markers)
        mask[markers == 1] = 255


    return [mask, hsv[...,0]]


BALL_STATE = False
def to_ball_state():
    #### 修改部分
    global BALL_STATE
    BALL_STATE = True



####################################################################



############################# 主函数 ################################


if __name__ == "__main__":
    # logging.basicConfig(filename='example.log', filemode='w', level=logging.DEBUG)
    logging.basicConfig(level=logging.INFO)



    vfile = 0
    #vfile = 'C:\\Users\\96317\\Desktop\\OPENCV\\print\\yin2.avi'

    cap = cv2.VideoCapture(vfile)

    to_ball_state_time = 2  # 进入寻球状态的时间，单位是分钟
    timer = threading.Timer(60 * to_ball_state_time, to_ball_state)  # 设置时钟。根据 BALL_STATE 变量以判断是否进入撞球部分
    timer.start()

    #cv2.namedWindow("Video")
    # cv2.setMouseCallback('Video', show_huv)

    #cv2.namedWindow("Video2")
    #Timer()

    #print('message')
    #logging.debug('message')


    while(1):

        if BALL_STATE:
            ser.write(b'\xaa\x55\x03\x0c\x24\x01')

            # 球深度

            status, imgb = cap1.read()

            cv2.boxFilter(imgb, -1, (5, 5), imgb)

            hsv = cv2.cvtColor(imgb, cv2.COLOR_BGR2HSV)

            maskb, hue = get_ball(imgb, 45, 65, ws_flag=False, sv_flag=True)

            cnts_ball = cv2.findContours(maskb.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
            cnts_ball = cnts_ball[1]

            if cnts_ball == []:
                if cntrm2 == 0:
                    # print(cmd_list[cntcmd])
                    control_orders(cmd_list[cntcmd])
                    cntcmd = (cntcmd + 1) % len(cmd_list)
                cntrm1 = (cntrm1 + 1) % cntrm_base

            cntrm2 = (cntrm2 + 1) % cntrm_base

            if cntrm1 != cntrm2:
                cntrm1 = 0
                cntrm2 = 0
                cntcmd = 0
            if com_key:
                CompareHist(imgb)
                com_key = 0

            if not (cnts_ball == []):
                for c_ball in cnts_ball:
                    c = max(cnts_ball, key=cv2.contourArea)
                    marker_ball = cv2.minAreaRect(c)
                    box = cv2.boxPoints(marker_ball)  # 获取最小外接矩形的四个顶点
                    box = np.int0(box)
                    cv2.drawContours(imgb, [box], -1, (0, 255, 0), 2)

                if marker_ball[0][0]<270:
                    control_orders(1)
                elif marker_ball[0][1]>370:
                    control_orders(2)
                else:
                    control_orders(5)


                #     M = cv2.moments(c_ball)  # 求图形的矩
                #     cX_b = int((M["m10"] + 1) / (M["m00"] + 1))
                #     cY_b = int((M["m01"] + 1) / (M["m00"] + 1))
                #     cv2.drawContours(maskb, [c_ball], -1, (0, 255, 0), 2)
                #     cv2.circle(maskb, (cX_b, cY_b), 7, (255, 255, 255), -1)
                #     cv2.putText(maskb, "ball_center", (cX_b - 20, cY_b - 20),
                #                 cv2.FONT_HERSHEY_SIMPLEX, 0.5, (127, 255, 127), 2)
                #
                # if count_z==30:
                #     if cX_b<270:
                #         control_orders(1)
                #     elif cX_b>370:
                #         control_orders(2)
                #     else:
                #         control_orders(5)



            # for mouse callback
            mask = maskb

            if debug:
                cv2.imshow("img", imgb)
                cv2.imshow("Video", maskb)
                # cv.imshow("Video2", mask2)

                k = cv2.waitKey(15)

                if k == 32:
                    cv2.waitKey()
                if k == 27:
                    break
            continue


        deep_value = Deepvalue(deepkey)                                     #设定深度，分两种。第一种检测引导线，第二段检测框

        status, img = cap.read()
        ret, frame = cap1.read()                                             #读取视频

        cv2.boxFilter(img, -1, (5, 5), img)                                  #块滤波器滤波

        thresh = modelsection(3, frame)                                      #选择模式

        # hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)                           #BGR转HSV

        # mask1, hue = get_fg_from_hue(img, 20)
        mask2, hue = get_fg_from_hue_watershed_saturation(img, 20)            #下面摄像头的前景
        # mask = mask1

        if open_key:
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5,5))           #形态学开运算，简单滤除离框较远的干扰
            #thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)

        if go_key:                                                              #冲刺时转弯
            control_orders(8)
            od1 = fd_trun(thresh)
            if go_key_count2 == 30:
                control_orders(od1)
            go_key_count = go_key_count + 1
            if go_key_count > 50:
                go_key = 0
                go_key_count = 0
                #冲刺完以后关闭开运算
                open_key = 0

        if com_key:
            CompareHist(frame)
            com_key = 0

        bind_key = 1                                                            #如果有框，if Houghlines就不会执行
        if Houghlines(thresh):                                                  #霍夫变换检查直线
            bind_key = 0

        guide_line = guide_line_detect(img)                                 #检测下置摄像头是否读到引导线

        # 没有引导线，也没有框
        if not(guide_line) and bind_key==0:
            #print('a0')
            #丢失引导线，guide_stop_key置1
            guide_stop_key = 1
            #guideline_orders里面有存储数据
            if len(guideline_orders)>5:
                zs = guideline_orders[-1]
                if zs=='l'and count_y==30:
                    #print('a1')
                    control_orders(1)
                elif zs=='r' and count_y==30:
                    #print('a2')
                    control_orders(2)
                else:
                    #print('a6')
                    control_orders(2)

            else:
                if guide_line_position < 270:
                    #print('a3')
                    control_orders(1)
                if guide_line_position > 370:
                    #print('a4')
                    control_orders(2)
                else:
                    #print('a5')
                    #改成随机游走
                    if cntrm2 == 0:
                        #print(cmd_list[cntcmd])
                        control_orders(cmd_list[cntcmd])
                        cntcmd = (cntcmd + 1) % len(cmd_list)
                    cntrm1 = (cntrm1 + 1) % cntrm_base

        cntrm2 = (cntrm2 + 1) % cntrm_base

        if cntrm1 != cntrm2:
            cntrm1 = 0
            cntrm2 = 0
            cntcmd = 0
        #有框，没有引导线，定深在1.在找框过程丢失了引导线
        if bind_key==1 and not(guide_line) and deep_value==1:
            #随机游走
            control_orders(2)
            guide_stop_key = 1

        #有引导线时
        if guide_line:
            #发现引导线，停一下
            if guide_stop_key:
                #control_orders(7)
                guide_stop_key = 0
            open_key = 1
            x, y, angle = guide_line
            angle = angle / 180 * np.pi
            cv2.line(img, (int(x), int(y)), (int(x + 100 * np.sin(angle)), int(y - 100 * np.cos(angle))), (0, 255, 0), 2)
            x1 = int(x + 100 * np.sin(angle))
            y1 = int(y - 100 * np.cos(angle))
            order_guide = guide_line_turn(angle)
            #如何沿着引导线走，没两帧发一次指令
            if gd_count == 2:
                guid_order(order_guide)
                #把跟着引导线走的指令存储
                guideline_orders.append(order_guide)
                guide_line_position = x
                print(guideline_orders[-1])
            #当angle在范围内，并且前方有框。下降
            if angle<=0.8 and angle>=-0.8 and bind_key:
                deepkey = Downner(thresh)
                guide_stop_key = 1

        #计数，之所以放在这里如果没有框，接下来的部分会被cotinue，沿着引导线走的指令就没办法计数发送
        gd_count = gd_count + 1
        if gd_count > 2:
            gd_count = 0


        row_line = Rowlines(mask2)

        if Houghvary(thresh) is None:                                          #霍夫变换检测，如果没检测到直线,状态就无法判断，直接跳帧
            continue

        marker,aff_value,cX,cY = maxAreaRect_momentCenter(thresh)                          #最大矩形参数，稳定性方法，矩中心X，矩中心Y
        if marker is None:
            continue

        inches = distance_to_camera(Know_Width, FORCAL, marker[1][0] + 1)                  #距离检测

        status = decetion_status(thresh,deep_value)
        Running_Status(status,thresh,marker,cX,frame,mask2,aff_value)


        count_t = count_t + 1                                               #xd yd 计数
        if count_t > 30:
            count_t = 0
        count_y = count_y + 1                                               #十字法横轴计数
        if count_y > 30:
            count_y = 0
        count_z = count_z + 1                                               #矩中心计数
        if count_z > 30:
            count_z = 0
        go_key_count2 = go_key_count2 + 1
        if go_key_count2 > 10:
            go_key_count2 = 0

        #cv2.imshow("temp",frame[240-int(240*20/49):,:])
        od = 0

        if debug:
            cv2.imshow("camera0", img)
            # cv2.imshow("Video", mask1)
            cv2.imshow("Video2", mask2)

            cv2.imshow("camera1", frame)
            cv2.imshow("capture1", thresh)

            if cv2.waitKey(1) & 0XFF == ord('q'):
                ser.write(b'\xaa\x55\x03\x0c\x10\x01')
                break


        # k = cv2.waitKey(1)

        # if k == 32:
        #     cv2.waitKey()
        # if k == 27:
        #     break

    cap.release()
    cv2.destroyAllWindows()
    sys.exit()
